# minibunker

App Android nativa (Kotlin + Jetpack Compose, Android 8.0 o superior) para organizar el curso, preparar exámenes y decidir cómo usar el móvil mientras estudias. Une **MIBUNKER** (agenda, horario, exámenes, planes, Pomodoro, notas y hábitos, con tu cuenta de siempre) y **thinktwice** (pausa consciente, bloqueos, rutinas, retos y estadísticas de uso).

Recorrido principal: abres la tarea de hoy → **Empezar a estudiar** → eliges si proteger esos minutos → **Empezar**.

## Compilar e instalar

**Requisitos:** Android Studio Ladybug (2024.2) o posterior, JDK 17 (el que trae Android Studio), un móvil con Android 8.0 (API 26) o superior y un cable USB.

1. Descomprime el ZIP. En Android Studio: **File › Open** y elige la carpeta `minibunker`.
2. Espera a que termine la sincronización de Gradle. La primera vez descarga Gradle 8.14.3, AGP 8.7.3, Kotlin 2.0.21 y las librerías de Compose, y necesita internet.
3. En el móvil: **Ajustes › Información del teléfono** › pulsa 7 veces *Número de compilación*. Luego, en **Opciones de desarrollador**, activa **Depuración USB**.
4. Conecta el móvil, acepta la huella del ordenador y pulsa **Run ▶** (configuración `app`).

Desde terminal: `./gradlew installDebug` (`gradlew.bat installDebug` en Windows). El APK queda en `app/build/outputs/apk/debug/app-debug.apk`.

Pruebas de la lógica (motor de reglas, sincronización, temporizador, copias): `./gradlew testDebugUnitTest`.

> minibunker se instala como app nueva (`app.minibunker`): convive con thinktwice y con la web de MIBUNKER. Si tenías thinktwice, desactiva su servicio de accesibilidad para no ver dos pausas, e importa su copia desde **Perfil › Datos › Importar copia**.

## Configuración

### Cuenta (MIBUNKER)
minibunker usa **la misma cuenta de Firebase** que la web de MIBUNKER (proyecto `mibunker-8783e`, correo y contraseña). Lee y escribe los mismos documentos (`users/{uid}/data/{events|notes|grades|timetable|sessions|plans|habits|subjects|jornada}`, más `meta` y `prefs`) con el mismo formato, así que una cuenta ya poblada recupera su horario, exámenes, notas, hábitos y sesiones, y la web sigue leyendo lo que escribe el móvil.

- No hay que añadir `google-services.json`: se usa la API REST, como la web.
- Si en Google Cloud la clave de API tiene restricción por *referentes HTTP*, las llamadas desde Android se rechazarán: añade una restricción de app Android (paquete `app.minibunker` y huella SHA-1 de tu firma) o quita esa restricción. En la web abierta como archivo local la clave ya funciona sin referente, así que lo normal es que no haga falta tocar nada.
- Sin conexión puedes seguir usando la agenda. Los cambios se guardan en una cola en el móvil y se envían al volver la red, fusionados por elemento con lo que haya en la cuenta. Más detalles en `docs/DATOS.md`.
- **Usar sin cuenta:** la agenda se queda solo en el móvil. Al iniciar sesión más tarde se añade a la cuenta sin borrar nada.

### Permisos (thinktwice)
Se explican al activar la función que los necesita. Puedes estudiar y usar la agenda sin concederlos.

| Función | Permiso | Dónde se concede |
|---|---|---|
| Pausas, bloqueos y estudio protegido | Servicio de accesibilidad de **minibunker** | Ajustes › Accesibilidad › Apps instaladas › minibunker |
| Estadísticas y retos de uso | Acceso a datos de uso | Ajustes › Apps › Acceso especial › Acceso a datos de uso |
| Aviso de fin de bloque, sesiones y recordatorios | Notificaciones (Android 13+) | Diálogo del sistema |
| Fin de bloque puntual con la pantalla bloqueada | Alarmas exactas (Android 12+) | Perfil › Permisos › Alarmas exactas |

En Android 13+ las apps instaladas fuera de Google Play tienen **ajustes restringidos**: si el interruptor de accesibilidad aparece gris, ve a **Ajustes › Apps › minibunker › ⋮ › Permitir ajustes restringidos**.

Recomendado: excluir minibunker de la optimización de batería (**Perfil › Permisos › Diagnóstico completo**), sobre todo en Xiaomi, Huawei, Oppo/Realme, Vivo y Samsung.

## Qué hay dentro

```
app/src/main/java/
├── app/minibunker/
│   ├── academic/   Modelos con el formato de MIBUNKER, cálculos (medias, «¿Qué nota necesito?», planes,
│   │               jornada), cambios puros, cola sin conexión (SyncCore) y repositorio con Firestore
│   ├── cloud/      Firebase Auth y Firestore por REST (mismas llamadas que la web)
│   ├── study/      Temporizador por marcas de tiempo, protección vinculada, alarma y notificación
│   ├── link/       «Vincular protección»: reglas de thinktwice que siguen a clases y eventos
│   ├── json/       JSON propio (sin Android) para poder probar la sincronización en la JVM
│   └── ui/         Tema (oscuro de thinktwice, claro y acento de MIBUNKER), superficie translúcida
│                   compartida (cápsula, hojas, menús), pantallas Hoy, Agenda, Estudio, Notas, thinktwice
└── app/thinktwice/ Motor, almacenamiento, servicio de accesibilidad, intervención, uso y notificaciones
                    (reutilizados de thinktwice con las ampliaciones descritas en docs/ANDROID.md)
```

- Icono de la app: el de MIBUNKER. Nombre en el lanzador, la cabecera y las notificaciones: «minibunker». Dentro de su pestaña, thinktwice conserva su nombre y su logotipo.
- Fuente: Inter (OFL, local en `res/font`; licencia en `FONT_LICENSE_Inter.txt`).
- Sin IA: todas las decisiones son reglas explícitas.

## Documentación
- `docs/PRUEBAS.md`: qué se ha verificado, cómo y qué queda pendiente en un móvil real, con los cinco recorridos del encargo.
- `docs/DATOS.md`: compatibilidad con la cuenta de MIBUNKER, cola sin conexión y copias de thinktwice.
- `docs/ANDROID.md`: mecanismo de intervención, estudio protegido, reglas vinculadas y limitaciones.
