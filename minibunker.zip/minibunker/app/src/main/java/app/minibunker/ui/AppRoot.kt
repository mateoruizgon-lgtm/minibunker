package app.minibunker.ui

import androidx.activity.compose.BackHandler
import androidx.compose.animation.*
import androidx.compose.animation.core.animateDpAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.outlined.*
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveableStateHolder
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import app.minibunker.academic.AcadState
import app.minibunker.academic.AcademicRepo
import app.minibunker.study.StudyController
import app.minibunker.ui.components.pressable
import app.minibunker.ui.frost.*
import app.minibunker.ui.screens.*
import app.minibunker.ui.tt.*
import app.minibunker.ui.theme.*
import app.thinktwice.core.AppState
import kotlinx.coroutines.delay

@Composable
fun AppRoot(tt: AppState, ac: AcadState) {
    val nav = remember { Nav() }
    val overlay = remember { OverlayHost() }
    val backdrop = rememberBackdrop()
    var resumeTick by remember { mutableIntStateOf(0) }
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e ->
            when (e) {
                Lifecycle.Event.ON_RESUME -> { resumeTick++; StudyController.tick(); AcademicRepo.startPolling() }
                Lifecycle.Event.ON_PAUSE -> AcademicRepo.stopPolling()
                else -> Unit
            }
        }
        owner.lifecycle.addObserver(o)
        onDispose { owner.lifecycle.removeObserver(o) }
    }

    CompositionLocalProvider(LocalNav provides nav, LocalOverlay provides overlay, LocalBackdrop provides backdrop, LocalResumeTick provides resumeTick) {
        val main = !ac.needsAuth && tt.settings.onboardingDone
        BackHandler(enabled = main && !overlay.hasModal && (nav.depth > 0 || nav.tab != Tab.HOY)) { nav.back() }
        Box(Modifier.fillMaxSize().background(TT.Bg)) {
            // 1) Pantalla de fondo, grabada para que las superficies translúcidas la desenfoquen.
            //    Con una hoja modal abierta, TalkBack solo recorre la hoja.
            Box(
                Modifier.fillMaxSize().backdropSource(backdrop)
                    .then(if (overlay.hasModal) Modifier.clearAndSetSemantics { } else Modifier),
            ) {
                when {
                    // Cuenta de MIBUNKER (o seguir sin cuenta: la agenda queda solo en este móvil).
                    ac.needsAuth -> AuthScreen(ac)
                    // Introducción de thinktwice, que se puede omitir: la agenda y el temporizador no dependen de ella.
                    !tt.settings.onboardingDone -> OnboardingScreen(tt, ac)
                    else -> Screens(tt, ac, nav)
                }
            }
            if (main) {
                // 2) Cápsula flotante: desenfoque del contenido que pasa por detrás + iconos nítidos encima.
                val density = LocalDensity.current
                val imeOpen = WindowInsets.ime.getBottom(density) > 0
                AnimatedVisibility(
                    visible = !imeOpen, modifier = Modifier.align(Alignment.BottomCenter),
                    enter = fadeIn(tween(Motion.tab)), exit = fadeOut(tween(Motion.tab)),
                ) { Capsule(nav) }
                Toast(nav)
                GlobalSheets(tt, ac, nav)
            }
            // 3) Hojas y menús translúcidos, por encima de todo.
            OverlayLayer(overlay)
        }
    }
}

@Composable
private fun Screens(tt: AppState, ac: AcadState, nav: Nav) {
    val holder = rememberSaveableStateHolder()
    val reduce = LocalReduceMotion.current
    AnimatedContent(
        targetState = Triple(nav.tab, nav.depth, nav.top),
        transitionSpec = {
            when {
                reduce -> EnterTransition.None togetherWith ExitTransition.None
                nav.tabChange -> fadeIn(tween(Motion.tab)) togetherWith fadeOut(tween(Motion.tab))
                nav.forward -> (slideInHorizontally(tween(Motion.detail)) { it / 3 } + fadeIn(tween(Motion.detail))) togetherWith fadeOut(tween(Motion.detail / 2))
                else -> fadeIn(tween(Motion.detail / 2)) togetherWith (slideOutHorizontally(tween(Motion.detail)) { it / 3 } + fadeOut(tween(Motion.detail)))
            }
        },
        contentKey = { "${it.first}:${it.second}" }, label = "screens",
    ) { (tab, depth, dest) ->
        // Cada pantalla conserva su estado (día elegido, filtros, posición de lectura) al volver.
        holder.SaveableStateProvider("$tab:$depth:$dest") {
            Box(Modifier.fillMaxSize().background(TT.Bg)) {
                if (dest == null) when (tab) {
                    Tab.HOY -> HoyScreen(tt, ac)
                    Tab.AGENDA -> AgendaScreen(tt, ac)
                    Tab.ESTUDIO -> EstudioScreen(tt, ac)
                    Tab.NOTAS -> NotasScreen(ac)
                    Tab.TT -> ThinktwiceScreen(tt)
                } else DetailHost(dest, tt, ac)
            }
        }
    }
}

@Composable
private fun DetailHost(dest: Dest, tt: AppState, ac: AcadState) {
    when (dest) {
        Dest.StudySession -> StudySessionScreen(tt, ac)
        is Dest.SubjectHistory -> SubjectHistoryScreen(ac, dest.subject)
        is Dest.SubjectGrades -> SubjectGradesScreen(ac, dest.subject)
        is Dest.NoteEditor -> NoteEditorScreen(ac, dest.id, dest.asList)
        Dest.Routines -> RoutinesScreen(tt)
        Dest.Challenges -> ChallengesScreen(tt)
        Dest.Stats -> StatsScreen(tt)
        Dest.Diagnostics -> DiagnosticsScreen(tt)
        Dest.Messages -> MessagesScreen(tt)
        Dest.Templates -> TemplatesScreen(tt)
        Dest.Classify -> ClassifyScreen(tt)
        Dest.Sessions -> SessionsScreen(tt)
        Dest.About -> AboutScreen()
        is Dest.RoutineEdit -> RoutineEditorScreen(tt, ac, dest)
        is Dest.ChallengeDetail -> ChallengeDetailScreen(tt, dest.id)
    }
}

@Composable
private fun GlobalSheets(tt: AppState, ac: AcadState, nav: Nav) {
    val opener = nav.lastOpener
    nav.studyRequest?.let { req -> StartStudySheet(tt, ac, req, opener) { nav.studyRequest = null } }
    if (nav.profileOpen) ProfileSheet(tt, ac, opener) { nav.profileOpen = false }
    nav.add?.let { k -> AddSheet(ac, k, opener) { nav.add = null } }
    when (nav.sheet) {
        SheetKind.Block -> BlockSheet(tt) { nav.sheet = null }
        SheetKind.Pause -> PauseSheet(tt) { nav.sheet = null }
        SheetKind.NewChallenge -> NewChallengeSheet(tt) { nav.sheet = null }
        null -> Unit
    }
    nav.openEvent?.let { id -> EventSheet(tt, ac, id, null) { nav.openEvent = null } }
    nav.openExam?.let { id -> ExamSheet(ac, id) { nav.openExam = null } }
    val summary by StudyController.summary.collectAsState()
    summary?.let { StudySummarySheet(it) { StudyController.dismissSummary() } }
}

private data class CapsuleItem(val tab: Tab, val on: ImageVector, val off: ImageVector)

/**
 * Cápsula inferior flotante con cinco destinos. Extremos redondos, márgenes laterales, espacio sobre
 * la navegación del sistema. El color de lo que pasa por detrás se percibe suavemente a través del
 * desenfoque; iconos y etiquetas se dibujan encima, nítidos.
 */
@Composable
private fun Capsule(nav: Nav) {
    val items = listOf(
        CapsuleItem(Tab.HOY, Icons.Rounded.Today, Icons.Outlined.Today),
        CapsuleItem(Tab.AGENDA, Icons.Rounded.CalendarMonth, Icons.Outlined.CalendarMonth),
        CapsuleItem(Tab.ESTUDIO, Icons.Rounded.MenuBook, Icons.Outlined.MenuBook),
        CapsuleItem(Tab.NOTAS, Icons.Rounded.StickyNote2, Icons.Outlined.StickyNote2),
        CapsuleItem(Tab.TT, Icons.Rounded.HourglassTop, Icons.Outlined.HourglassEmpty),
    )
    val shape = CircleShape
    val density = LocalDensity.current
    BoxWithConstraints(
        Modifier.fillMaxWidth().navigationBarsPadding()
            .padding(start = Dim.capsuleSide, end = Dim.capsuleSide, bottom = Dim.capsuleGap)
            .height(Dim.capsuleH)
            .shadow(14.dp, shape, ambientColor = Color.Black.copy(alpha = 0.18f), spotColor = Color.Black.copy(alpha = 0.22f))
            .frosted(shape, blur = 24.dp)
            .clip(shape)
            .padding(5.dp)
            .semantics { isTraversalGroup = true; contentDescription = "Navegación principal" },
    ) {
        val itemW = maxWidth / items.size
        // Etiquetas legibles con texto grande, sin desbordar en pantallas pequeñas («thinktwice» es la más larga).
        val base = if (itemW < 60.dp) 10f else 11f
        val labelSp = (base / density.fontScale * minOf(density.fontScale, 1.25f)).sp
        val sel = items.indexOfFirst { it.tab == nav.tab }.coerceAtLeast(0)
        val x by animateDpAsState(itemW * sel, ttTween(Motion.tab), label = "pill")
        // Pastilla interior suave que marca el destino activo.
        Box(Modifier.offset(x = x).width(itemW).fillMaxHeight().clip(shape).background(TT.Accent.copy(alpha = if (TT.isDark) 0.18f else 0.14f)))
        Row(Modifier.fillMaxSize()) {
            items.forEach { it ->
                val active = it.tab == nav.tab
                Column(
                    Modifier.weight(1f).fillMaxHeight().clip(shape)
                        .pressable(role = Role.Tab, scaleDown = false) { nav.select(it.tab) }
                        .semantics { selected = active; contentDescription = it.tab.label },
                    horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center,
                ) {
                    Icon(if (active) it.on else it.off, null, tint = if (active) TT.AccentText else TT.Text.copy(alpha = 0.78f), modifier = Modifier.size(22.dp))
                    Spacer(Modifier.height(2.dp))
                    Text(
                        it.tab.label, maxLines = 1, softWrap = false, overflow = TextOverflow.Clip,
                        style = Type.label.copy(fontSize = labelSp, lineHeight = labelSp * 1.2f, color = if (active) TT.AccentText else TT.Text.copy(alpha = 0.78f),
                            fontWeight = if (active) FontWeight.SemiBold else FontWeight.Medium),
                    )
                }
            }
        }
    }
}

@Composable
private fun BoxScope.Toast(nav: Nav) {
    val msg = nav.toast
    LaunchedEffect(msg) { if (msg != null) { delay(2600); nav.toast = null } }
    AnimatedVisibility(
        visible = msg != null, enter = fadeIn(tween(160)) + slideInVertically(tween(200)) { it / 2 }, exit = fadeOut(tween(160)),
        modifier = Modifier.align(Alignment.BottomCenter).navigationBarsPadding().padding(bottom = Dim.capsuleH + Dim.capsuleGap + 12.dp, start = 20.dp, end = 20.dp),
    ) {
        var last by remember { mutableStateOf("") }
        if (msg != null) last = msg
        Row(
            Modifier.clip(CircleShape).background(TT.Control).padding(horizontal = 16.dp, vertical = 12.dp)
                .semantics { liveRegion = LiveRegionMode.Polite },
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Icon(Icons.Rounded.CheckCircle, null, tint = TT.Positive, modifier = Modifier.size(18.dp))
            Spacer(Modifier.width(8.dp))
            Text(last, style = Type.bodyMedium)
        }
    }
}
