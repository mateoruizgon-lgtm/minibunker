package app.minibunker.json

/**
 * JSON mínimo y sin dependencias para los datos académicos y la API REST de Firebase.
 * Se usa en lugar de org.json para que la lógica de sincronización pueda probarse en la JVM
 * y para conservar el orden de las claves (los objetos son LinkedHashMap).
 *
 * Tipos: null, Boolean, Long, Double, String, List<Any?>, Map<String, Any?>.
 */
object Json {

    fun parse(text: String): Any? = Parser(text).run {
        val v = value(); ws(); if (i != s.length) err("datos sobrantes"); v
    }

    fun obj(text: String): Map<String, Any?> =
        parse(text) as? Map<String, Any?> ?: throw IllegalArgumentException("Se esperaba un objeto JSON.")

    fun write(v: Any?): String = StringBuilder().also { w(it, v) }.toString()

    private fun w(b: StringBuilder, v: Any?) {
        when (v) {
            null -> b.append("null")
            is Boolean -> b.append(v)
            is Int, is Long, is Short, is Byte -> b.append(v.toString())
            is Double, is Float -> {
                val d = (v as Number).toDouble()
                if (d.isNaN() || d.isInfinite()) b.append("null")
                else if (d == Math.floor(d) && Math.abs(d) < 1e15) b.append(d.toLong()) else b.append(d.toString())
            }
            is Number -> b.append(v.toString())
            is String -> str(b, v)
            is Map<*, *> -> {
                b.append('{'); var first = true
                for ((k, x) in v) { if (!first) b.append(','); first = false; str(b, k.toString()); b.append(':'); w(b, x) }
                b.append('}')
            }
            is Iterable<*> -> {
                b.append('['); var first = true
                for (x in v) { if (!first) b.append(','); first = false; w(b, x) }
                b.append(']')
            }
            is Array<*> -> w(b, v.toList())
            else -> str(b, v.toString())
        }
    }

    private fun str(b: StringBuilder, s: String) {
        b.append('"')
        for (c in s) when (c) {
            '"' -> b.append("\\\""); '\\' -> b.append("\\\\")
            '\n' -> b.append("\\n"); '\r' -> b.append("\\r"); '\t' -> b.append("\\t")
            '\b' -> b.append("\\b"); '\u000C' -> b.append("\\f")
            else -> if (c < ' ' || c == ' ' || c == ' ') b.append("\\u%04x".format(c.code)) else b.append(c)
        }
        b.append('"')
    }

    private class Parser(val s: String) {
        var i = 0
        fun err(m: String): Nothing = throw IllegalArgumentException("JSON no válido ($m, posición $i).")
        fun ws() { while (i < s.length && s[i].isWhitespace()) i++ }
        fun value(): Any? {
            ws(); if (i >= s.length) err("fin inesperado")
            return when (val c = s[i]) {
                '{' -> objectV()
                '[' -> arrayV()
                '"' -> stringV()
                't' -> lit("true", true)
                'f' -> lit("false", false)
                'n' -> lit("null", null)
                else -> if (c == '-' || c.isDigit()) number() else err("carácter '$c'")
            }
        }
        fun lit(t: String, v: Any?): Any? { if (!s.startsWith(t, i)) err("literal"); i += t.length; return v }
        fun objectV(): Map<String, Any?> {
            val m = LinkedHashMap<String, Any?>(); i++; ws()
            if (i < s.length && s[i] == '}') { i++; return m }
            while (true) {
                ws(); if (i >= s.length || s[i] != '"') err("clave")
                val k = stringV(); ws(); if (i >= s.length || s[i] != ':') err("':'"); i++
                m[k] = value(); ws()
                if (i >= s.length) err("fin inesperado")
                when (s[i]) { ',' -> i++; '}' -> { i++; return m }; else -> err("',' o '}'") }
            }
        }
        fun arrayV(): List<Any?> {
            val l = ArrayList<Any?>(); i++; ws()
            if (i < s.length && s[i] == ']') { i++; return l }
            while (true) {
                l += value(); ws()
                if (i >= s.length) err("fin inesperado")
                when (s[i]) { ',' -> i++; ']' -> { i++; return l }; else -> err("',' o ']'") }
            }
        }
        fun stringV(): String {
            val b = StringBuilder(); i++
            while (true) {
                if (i >= s.length) err("cadena sin cerrar")
                val c = s[i++]
                when (c) {
                    '"' -> return b.toString()
                    '\\' -> {
                        if (i >= s.length) err("escape")
                        when (val e = s[i++]) {
                            '"' -> b.append('"'); '\\' -> b.append('\\'); '/' -> b.append('/')
                            'b' -> b.append('\b'); 'f' -> b.append('\u000C'); 'n' -> b.append('\n')
                            'r' -> b.append('\r'); 't' -> b.append('\t')
                            'u' -> { if (i + 4 > s.length) err("escape u"); b.append(s.substring(i, i + 4).toInt(16).toChar()); i += 4 }
                            else -> err("escape \\$e")
                        }
                    }
                    else -> b.append(c)
                }
            }
        }
        fun number(): Any {
            val st = i
            if (s[i] == '-') i++
            while (i < s.length && (s[i].isDigit() || s[i] in ".eE+-")) i++
            val t = s.substring(st, i)
            return if (t.any { it in ".eE" }) t.toDoubleOrNull() ?: err("número") else t.toLongOrNull() ?: t.toDoubleOrNull() ?: err("número")
        }
    }
}

/* ───── Accesores tolerantes (los datos de la web pueden traer tipos mezclados) ───── */

typealias JObj = Map<String, Any?>

fun JObj.str(k: String, def: String = ""): String = when (val v = this[k]) {
    null -> def; is String -> v; is Number -> Json.write(v); is Boolean -> v.toString(); else -> def
}
fun JObj.strOrNull(k: String): String? = (this[k] as? String)
fun JObj.num(k: String): Double? = when (val v = this[k]) {
    is Number -> v.toDouble(); is String -> v.replace(',', '.').trim().toDoubleOrNull(); else -> null
}
fun JObj.long(k: String, def: Long = 0): Long = num(k)?.toLong() ?: def
fun JObj.int(k: String, def: Int = 0): Int = num(k)?.toInt() ?: def
fun JObj.bool(k: String, def: Boolean = false): Boolean = when (val v = this[k]) {
    is Boolean -> v; is Number -> v.toDouble() != 0.0; is String -> v.isNotEmpty() && v != "false" && v != "0"; else -> def
}
@Suppress("UNCHECKED_CAST")
fun JObj.list(k: String): List<Any?> = this[k] as? List<Any?> ?: emptyList()
@Suppress("UNCHECKED_CAST")
fun JObj.objs(k: String): List<JObj> = list(k).mapNotNull { it as? JObj }
@Suppress("UNCHECKED_CAST")
fun JObj.objOrNull(k: String): JObj? = this[k] as? JObj
