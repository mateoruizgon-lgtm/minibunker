package app.minibunker.ui.screens

import android.Manifest
import android.app.AlarmManager
import android.content.Intent
import android.os.Build
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.study.StudyController
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.FrostSheet
import app.minibunker.ui.frost.MenuOption
import app.minibunker.ui.theme.*
import app.minibunker.ui.tt.TimeDialog
import app.minibunker.ui.tt.appsSummary
import app.thinktwice.core.AppState
import app.thinktwice.core.Settings as TtSettings
import app.thinktwice.data.Codec
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import kotlinx.coroutines.launch
import java.text.DateFormat
import java.time.LocalDate
import java.util.Date

/** Hoja única de perfil: cuenta, apariencia, estudio, thinktwice, permisos y datos. */
@Composable
fun ProfileSheet(tt: AppState, ac: AcadState, returnFocus: androidx.compose.ui.focus.FocusRequester? = null, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val tick = LocalResumeTick.current
    val s = tt.settings
    var confirmLogout by remember { mutableStateOf(false) }
    var confirmDelete by remember { mutableStateOf(false) }
    var confirmWipe by remember { mutableStateOf(false) }
    var hourPicker by remember { mutableStateOf(false) }
    var durations by remember { mutableStateOf(false) }
    var importCandidate by remember { mutableStateOf<AppState?>(null) }
    var message by remember { mutableStateOf<String?>(null) }
    var busy by remember { mutableStateOf(false) }
    var name by remember { mutableStateOf(s.name.ifBlank { ac.account?.name.orEmpty() }) }
    val guardOn = remember(tick) { Perms.isGuardEnabled(ctx) }
    val usageOn = remember(tick) { Perms.hasUsageAccess(ctx) }
    val notifOn = remember(tick) { Perms.notificationsEnabled(ctx) }
    val exactOn = remember(tick) { Build.VERSION.SDK_INT < 31 || ctx.getSystemService(AlarmManager::class.java)?.canScheduleExactAlarms() == true }
    val notifLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { }
    fun set(f: (TtSettings) -> TtSettings) = Store.update { it.copy(settings = f(it.settings)) }

    val exporter = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("application/json")) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching { ctx.contentResolver.openOutputStream(uri)!!.use { it.write(Codec.encode(Store.state.value).toByteArray()) } }
            .onSuccess { nav.show("Copia exportada") }.onFailure { message = "No se pudo exportar: ${it.message}" }
    }
    val importer = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri ->
        if (uri == null) return@rememberLauncherForActivityResult
        runCatching { ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().toString(Charsets.UTF_8) } }
            .mapCatching { Codec.decode(it) }
            .onSuccess { importCandidate = it }
            .onFailure { message = it.message ?: "Archivo no válido." }
    }

    FrostSheet(onDismiss, "Perfil", returnFocus = returnFocus) {
        // ───── Cuenta ─────
        Group("Cuenta")
        val acc = ac.account
        ListGroup {
            if (acc != null) {
                ListRow(acc.email, ac.status.text() + if (ac.pending > 0) " · ${ac.pending} ${if (ac.pending == 1) "cambio pendiente" else "cambios pendientes"}" else "",
                    leading = { RowIcon(Icons.Rounded.AccountCircle) })
                if (ac.lastError != null) { RowDivider(); ListRow("Último error", ac.lastError, leading = { RowIcon(Icons.Rounded.ErrorOutline, tint = TT.Danger) }) }
                if (ac.lastSync > 0) { RowDivider(); ListRow("Última sincronización", DateFormat.getDateTimeInstance(DateFormat.MEDIUM, DateFormat.SHORT, Cal.es).format(Date(ac.lastSync)), leading = { RowIcon(Icons.Rounded.CloudDone) }) }
                RowDivider()
                ListRow("Sincronizar ahora", null, leading = { RowIcon(Icons.Rounded.Sync) }, onClick = { scope.launch { AcademicRepo.sync() } })
                RowDivider()
                ListRow("Cerrar sesión", "Tus datos siguen en tu cuenta", leading = { RowIcon(Icons.Rounded.Logout) }, onClick = { confirmLogout = true })
                RowDivider()
                ListRow("Eliminar cuenta", "Borra la cuenta y sus datos en todos tus dispositivos", leading = { RowIcon(Icons.Rounded.PersonRemove, tint = TT.Danger) },
                    titleColor = TT.Danger, onClick = { confirmDelete = true })
            } else {
                ListRow("Sin cuenta", "Tu agenda está guardada solo en este móvil", leading = { RowIcon(Icons.Rounded.PhoneAndroid) })
                RowDivider()
                ListRow("Iniciar sesión o crear cuenta", "Lo que tienes aquí se añadirá a la cuenta sin borrar nada", leading = { RowIcon(Icons.Rounded.Login) },
                    chevron = true, onClick = { onDismiss(); AcademicRepo.showAuth() })
            }
        }
        Spacer(Modifier.height(12.dp))
        LabeledField("Nombre", name, { name = it.take(40); val v = name; set { st -> st.copy(name = v) } }, help = "Para el saludo y tu perfil. No sale del móvil.")

        // ───── Apariencia ─────
        Group("Apariencia")
        val prefs = ac.prefs
        Segmented(listOf("Claro", "Oscuro", "Automático"), listOf("claro", "oscuro", "auto").indexOf(prefs.mode).coerceAtLeast(1),
            { AcademicRepo.setPrefs(prefs.copy(mode = listOf("claro", "oscuro", "auto")[it])) }, Modifier.fillMaxWidth())
        Spacer(Modifier.height(12.dp))
        FieldLabel("Color de acento")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            UiPrefs.ACCENTS.forEach { (k, l) ->
                val c = Palettes.of(TT.isDark, k).accent
                val on = prefs.accent == k
                Column(Modifier.width(64.dp).pressable(role = Role.RadioButton) { AcademicRepo.setPrefs(prefs.copy(accent = k)) }.semantics { selected = on; contentDescription = "Acento $l" },
                    horizontalAlignment = Alignment.CenterHorizontally) {
                    Box(Modifier.size(40.dp).clip(CircleShape).background(c).then(if (on) Modifier.border(3.dp, TT.Text, CircleShape) else Modifier), contentAlignment = Alignment.Center) {
                        if (on) Icon(Icons.Rounded.Check, null, tint = TT.OnAccent, modifier = Modifier.size(20.dp))
                    }
                    Text(l, style = Type.label, maxLines = 1)
                }
            }
        }
        Text("El modo y el color se sincronizan con tu cuenta, como en MIBUNKER.", style = Type.label, modifier = Modifier.padding(top = 6.dp))

        // ───── Estudio ─────
        Group("Estudio")
        val pp by StudyController.prefs.collectAsState()
        ListGroup {
            ListRow("Duraciones del temporizador", "${pp.focus} min · ${pp.short} de descanso · ${pp.long} de descanso largo", leading = { RowIcon(Icons.Rounded.Timer) },
                chevron = true, onClick = { durations = true })
        }

        // ───── thinktwice ─────
        Group("thinktwice")
        FieldLabel("Espera de la pausa consciente")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(5, 10, 15, 30, 60).forEach { w -> Chip("$w s", s.waitSeconds == w, { set { it.copy(waitSeconds = w) } }) }
        }
        Spacer(Modifier.height(12.dp))
        FieldLabel("Uso permitido al continuar")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            listOf(1, 5, 10, 15, 30).forEach { m -> Chip("$m min", s.allowedMinutes == m, { set { it.copy(allowedMinutes = m) } }) }
        }
        Spacer(Modifier.height(12.dp))
        ListGroup {
            ListRow("Apps con pausa", appsSummary(tt.pausedApps.size), leading = { RowIcon(Icons.Rounded.HourglassTop) }, chevron = true, onClick = { nav.sheet = SheetKind.Pause })
            RowDivider()
            ListRow("Frases de la pausa", "${tt.messages.size} frases", leading = { RowIcon(Icons.Rounded.FormatQuote) }, chevron = true, onClick = { onDismiss(); nav.push(Dest.Messages, Tab.TT) })
            RowDivider()
            ListRow("Plantillas de bloqueo", tt.templates.joinToString(", ") { it.name }, leading = { RowIcon(Icons.Rounded.Dashboard) }, chevron = true, onClick = { onDismiss(); nav.push(Dest.Templates, Tab.TT) })
            RowDivider()
            ListRow("Clasificar apps", "Útil, distractora o neutra", leading = { RowIcon(Icons.Rounded.Tune) }, chevron = true, onClick = { onDismiss(); nav.push(Dest.Classify, Tab.TT) })
            RowDivider()
            ListRow("Notificación de sesiones", if (notifOn) "Cuenta atrás en la notificación" else "Notificaciones desactivadas en Android",
                leading = { RowIcon(Icons.Rounded.Notifications) }, trailingSwitch = s.sessionNotifications, switchLabel = "Notificación de sesiones",
                onSwitch = { v -> set { it.copy(sessionNotifications = v) } })
            RowDivider()
            ListRow("Hora de avisos", "Recordatorio de retos", leading = { RowIcon(Icons.Rounded.Alarm) }, value = "%02d:00".format(s.reminderHour), chevron = true, onClick = { hourPicker = true })
            RowDivider()
            ListRow("Respuesta háptica", "Vibración breve al completar acciones", leading = { RowIcon(Icons.Rounded.Vibration) },
                trailingSwitch = s.haptics, switchLabel = "Respuesta háptica", onSwitch = { v -> set { it.copy(haptics = v) } })
        }
        Spacer(Modifier.height(12.dp))
        MenuField("Reducir movimiento", listOf<MenuOption<Boolean?>>(MenuOption(null, "Según el sistema"), MenuOption(true, "Activado"), MenuOption(false, "Desactivado")), s.reduceMotion) { v ->
            set { it.copy(reduceMotion = v) }
        }
        Spacer(Modifier.height(12.dp))
        SmallPill("Repetir la introducción de thinktwice", { onDismiss(); set { it.copy(onboardingDone = false) } }, Icons.Rounded.Replay)

        // ───── Permisos ─────
        Group("Permisos")
        Text("Estado real en este momento. Puedes revocarlos cuando quieras desde los ajustes de Android.", style = Type.secondary)
        Spacer(Modifier.height(8.dp))
        ListGroup {
            PermRow("Pausas, bloqueos y estudio protegido", if (guardOn) "Servicio de accesibilidad activo" else "Desactivado: no se pueden pausar apps", guardOn) { Perms.open(ctx, Perms.accessibilityIntent()) }
            RowDivider()
            PermRow("Estadísticas y retos de uso", if (usageOn) "Acceso a datos de uso concedido" else "Sin acceso: días sin medición", usageOn) { Perms.open(ctx, Perms.usageAccessIntent(ctx)) }
            RowDivider()
            PermRow("Notificaciones", if (notifOn) "Permitidas" else "Bloqueadas: sin aviso de fin de bloque", notifOn) {
                if (Build.VERSION.SDK_INT >= 33) notifLauncher.launch(Manifest.permission.POST_NOTIFICATIONS) else Perms.open(ctx, Perms.notificationSettingsIntent(ctx))
            }
            RowDivider()
            PermRow("Alarmas exactas", if (exactOn) "El fin del bloque suena a su hora" else "El aviso de fin puede retrasarse unos minutos", exactOn) {
                if (Build.VERSION.SDK_INT >= 31) Perms.open(ctx, Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM, android.net.Uri.parse("package:${ctx.packageName}")))
            }
            RowDivider()
            ListRow("Diagnóstico completo", "Accesibilidad, uso, batería y último evento", leading = { RowIcon(Icons.Rounded.HealthAndSafety) }, chevron = true,
                onClick = { onDismiss(); nav.push(Dest.Diagnostics, Tab.TT) })
        }

        // ───── Datos ─────
        Group("Datos")
        ListGroup {
            ListRow("Exportar copia de thinktwice", "JSON con reglas, ajustes, retos y registros", leading = { RowIcon(Icons.Rounded.Upload) }, chevron = true,
                onClick = { exporter.launch("minibunker-thinktwice-${LocalDate.now()}.json") })
            RowDivider()
            ListRow("Importar copia", "De minibunker o del thinktwice original. No toca tus datos académicos", leading = { RowIcon(Icons.Rounded.Download) }, chevron = true,
                onClick = { importer.launch(arrayOf("application/json", "text/plain", "*/*")) })
            RowDivider()
            ListRow("Borrar datos de thinktwice", "Solo en este móvil. No afecta a la agenda ni a los permisos", leading = { RowIcon(Icons.Rounded.DeleteForever, tint = TT.Danger) },
                titleColor = TT.Danger, onClick = { confirmWipe = true })
        }
        Text("Los tiempos de uso los conserva Android y se consultan en el dispositivo; no se exportan. Tu agenda está en tu cuenta de MIBUNKER.", style = Type.label, modifier = Modifier.padding(top = 8.dp, bottom = 8.dp))
    }

    if (durations) DurationsSheet { durations = false }
    if (hourPicker) TimeDialog(s.reminderHour * 60, { hourPicker = false }, "Hora de avisos") { v -> set { it.copy(reminderHour = v / 60) }; hourPicker = false }
    if (confirmLogout) ConfirmDialog("Cerrar sesión",
        if (ac.pending > 0) "Hay ${ac.pending} ${if (ac.pending == 1) "cambio" else "cambios"} sin sincronizar que se perderán. Conéctate y sincroniza antes si quieres conservarlos."
        else "Tus datos siguen guardados en tu cuenta. Para volver a verlos, inicia sesión con tu correo y contraseña. thinktwice y sus permisos no cambian.",
        "Cerrar sesión", onConfirm = { confirmLogout = false; onDismiss(); AcademicRepo.logout() }, onDismiss = { confirmLogout = false })
    if (confirmDelete) ConfirmDialog("Eliminar cuenta",
        "Se borrarán tu cuenta y todos sus datos en todos tus dispositivos: eventos, notas, horario, exámenes, hábitos y sesiones. No se puede deshacer. Necesitas conexión.",
        if (busy) "Eliminando…" else "Eliminar todo", onConfirm = {
            if (busy) return@ConfirmDialog
            busy = true
            scope.launch {
                try { AcademicRepo.deleteAccount(); confirmDelete = false; onDismiss() }
                catch (e: app.minibunker.cloud.NetworkException) { message = "Necesitas conexión a internet para eliminar la cuenta." }
                catch (e: Exception) { message = e.message ?: "Vuelve a iniciar sesión y prueba otra vez." }
                busy = false
            }
        }, onDismiss = { confirmDelete = false })
    if (confirmWipe) ConfirmDialog("¿Borrar datos de thinktwice?", "Se borrarán reglas, rutinas (también las vinculadas), sesiones, retos y registros de este móvil. La agenda no cambia. No se puede deshacer.", "Borrar",
        onConfirm = { Store.wipe(); confirmWipe = false; onDismiss() }, onDismiss = { confirmWipe = false })
    importCandidate?.let { cand ->
        ConfirmDialog("¿Reemplazar los datos de thinktwice?",
            "La copia contiene ${cand.routines.size} rutinas, ${cand.sessions.size} sesiones y ${cand.challenges.size} retos. Sustituirá los datos de thinktwice de este móvil; tus protecciones vinculadas a clases y eventos y tus datos académicos se conservan.",
            "Reemplazar", danger = false,
            onConfirm = {
                Store.update { cur ->
                    val ids = cand.routines.map { it.id }.toSet()
                    cand.copy(settings = cand.settings.copy(onboardingDone = true),
                        routines = cand.routines + cur.routines.filter { it.isLinked && it.id !in ids })
                }
                importCandidate = null; nav.show("Copia importada")
            }, onDismiss = { importCandidate = null })
    }
    message?.let { ConfirmDialog("No se pudo completar", it, "Entendido", danger = false, onConfirm = { message = null }, onDismiss = { message = null }) }
}

@Composable
private fun Group(title: String) {
    Text(title, style = Type.label.copy(color = TT.Text), modifier = Modifier.padding(top = 24.dp, bottom = 8.dp, start = 4.dp).semantics { heading() })
}

@Composable
private fun PermRow(title: String, status: String, ok: Boolean, onFix: () -> Unit) {
    ListRow(title, status, leading = { RowIcon(if (ok) Icons.Rounded.CheckCircle else Icons.Rounded.ErrorOutline, tint = if (ok) TT.Positive else TT.Danger) },
        chevron = !ok, onClick = if (!ok) onFix else null)
}
