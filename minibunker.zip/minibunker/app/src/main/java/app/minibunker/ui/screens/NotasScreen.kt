package app.minibunker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.SolidColor
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.text.input.KeyboardCapitalization
import androidx.compose.ui.text.style.TextDecoration
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.theme.*
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter

@Composable
fun NotasScreen(ac: AcadState) {
    val nav = LocalNav.current
    val a = ac.academic
    var section by rememberSaveable { mutableIntStateOf(0) }
    LaunchedEffect(nav.notesSection) { nav.notesSection?.let { section = it; nav.notesSection = null } }
    var filter by rememberSaveable { mutableIntStateOf(0) } // 0 todas, 1 fijadas, 2 con tareas
    var tag by rememberSaveable { mutableStateOf("") }
    var q by rememberSaveable { mutableStateOf("") }
    var newHabit by rememberSaveable { mutableStateOf("") }
    var delHabit by remember { mutableStateOf<Habit?>(null) }
    val ts = Cal.iso(LocalDate.now())

    TabScaffold(
        "Notas",
        actions = {
            if (section == 0) {
                SmallPill("Lista", { nav.push(Dest.NoteEditor(null, asList = true)) }, Icons.Rounded.Checklist)
                Spacer(Modifier.width(6.dp))
                SmallPill("Nota", { nav.push(Dest.NoteEditor(null)) }, Icons.Rounded.Add, tone = ButtonTone.Light)
            }
            Avatar(ac.account?.name.orEmpty()) { nav.profileOpen = true }
        },
        below = { Segmented(listOf("Notas", "Hábitos"), section, { section = it }, Modifier.fillMaxWidth()) },
    ) {
        if (section == 0) {
            val tags = a.notes.flatMap { it.tags }.groupingBy { it }.eachCount().toSortedMap()
            val list = a.notes.filter { n ->
                (filter != 1 || n.pinned) && (filter != 2 || n.items.isNotEmpty()) && (tag.isEmpty() || tag in n.tags) &&
                    (q.isBlank() || (n.title + " " + n.body + " " + n.items.joinToString(" ") { it.t } + " " + n.tags.joinToString(" ")).contains(q.trim(), true))
            }.sortedWith(compareByDescending<Note> { it.pinned }.thenByDescending { it.updated })
            item {
                Text("${a.notes.size} ${if (a.notes.size == 1) "nota" else "notas"} · ${Cal.pendingTasks(a).size} tareas pendientes", style = Type.secondary)
                Spacer(Modifier.height(12.dp))
                SearchField(q) { q = it }
                Spacer(Modifier.height(10.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    listOf("Todas", "Fijadas", "Con tareas").forEachIndexed { i, l -> Chip(l, filter == i, { filter = i }) }
                    tags.forEach { (t, n) -> Chip("#$t · $n", tag == t, { tag = if (tag == t) "" else t }) }
                }
                Spacer(Modifier.height(14.dp))
            }
            if (list.isEmpty()) item {
                if (a.notes.isEmpty()) EmptyState(Icons.Rounded.StickyNote2, "Sin notas", "Escribe apuntes, listas de tareas o lo que necesites recordar.", "Nueva nota") { nav.push(Dest.NoteEditor(null)) }
                else Text("No hay notas que coincidan con el filtro.", style = Type.secondary)
            } else list.forEach { n ->
                item(key = n.id) { NoteCard(n) { nav.push(Dest.NoteEditor(n.id)) }; Spacer(Modifier.height(Dim.related)) }
            }
        } else {
            val done = a.habits.count { it.done(ts) }
            item {
                Text(if (a.habits.isEmpty()) "Pequeñas rutinas que suman cada día" else "$done de ${a.habits.size} hechos hoy", style = Type.secondary)
                Spacer(Modifier.height(12.dp))
                if (a.habits.isNotEmpty()) Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
                    TTCard(Modifier.weight(1f), padding = 14.dp) { Text("Hoy", style = Type.label); Text("$done/${a.habits.size}", style = Type.cardFigure) }
                    TTCard(Modifier.weight(1f), padding = 14.dp) { Text("Mejor racha", style = Type.label); Text("${a.habits.maxOfOrNull { Cal.streak(it, ts) } ?: 0}", style = Type.cardFigure) }
                    TTCard(Modifier.weight(1f), padding = 14.dp) {
                        Text("30 días", style = Type.label)
                        Text("${Math.round(a.habits.sumOf { Cal.last30(it, ts) } * 100.0 / (a.habits.size * 30))} %", style = Type.cardFigure)
                    }
                }
                Spacer(Modifier.height(14.dp))
                Row(verticalAlignment = Alignment.Bottom) {
                    LabeledField("Nuevo hábito", newHabit, { newHabit = it.take(50) }, Modifier.weight(1f), placeholder = "Ej. Leer 20 minutos")
                    Spacer(Modifier.width(8.dp))
                    PillButton("Crear", { AcademicRepo.edit { Edits.addHabit(it, newHabit) }; nav.show("Hábito creado"); newHabit = "" }, enabled = newHabit.isNotBlank())
                }
                Text("Los hábitos se marcan a mano. Los retos de thinktwice tienen reglas propias medidas por el móvil (sesiones, rutinas o límites de uso).", style = Type.label, modifier = Modifier.padding(top = 8.dp))
                Spacer(Modifier.height(16.dp))
            }
            if (a.habits.isEmpty()) item { EmptyState(Icons.Rounded.TaskAlt, "Sin hábitos", "Escribe uno arriba para empezar.") }
            else a.habits.forEach { h -> item(key = h.id) { HabitCard(h, ts) { delHabit = h }; Spacer(Modifier.height(Dim.related)) } }
        }
    }
    delHabit?.let { h ->
        ConfirmDialog("Eliminar hábito", "Se borrará «${h.name}» con todo su historial.", "Eliminar",
            onConfirm = { AcademicRepo.edit { Edits.deleteHabit(it, h.id) }; delHabit = null; nav.show("Hábito eliminado") }, onDismiss = { delHabit = null })
    }
}

@Composable
private fun SearchField(q: String, onChange: (String) -> Unit) {
    Row(Modifier.fillMaxWidth().height(50.dp).clip(CircleShape).background(TT.Control).padding(horizontal = 16.dp), verticalAlignment = Alignment.CenterVertically) {
        Icon(Icons.Rounded.Search, null, tint = TT.TextSecondary, modifier = Modifier.size(20.dp))
        Spacer(Modifier.width(10.dp))
        Box(Modifier.weight(1f)) {
            if (q.isEmpty()) Text("Buscar notas", style = Type.body.copy(color = TT.TextSecondary))
            BasicTextField(q, onChange, singleLine = true, textStyle = Type.body, cursorBrush = SolidColor(TT.Accent),
                modifier = Modifier.fillMaxWidth().semantics { contentDescription = "Buscar notas" })
        }
        if (q.isNotEmpty()) Box(Modifier.size(Dim.touch).pressable { onChange("") }.semantics { contentDescription = "Borrar búsqueda" }, contentAlignment = Alignment.Center) {
            Icon(Icons.Rounded.Close, null, tint = TT.TextSecondary, modifier = Modifier.size(18.dp))
        }
    }
}

private fun toneBg(tone: String) = when (tone) { "light" -> Color(0xFFF4F1EA); "gray" -> Color(0xFF3A3D45); else -> null }

/** Tarjeta de nota con sus tareas marcables. */
@Composable
fun NoteCard(n: Note, onClick: () -> Unit) {
    val bg = toneBg(n.tone) ?: TT.Card
    val fg = if (n.tone == "light") Color(0xFF1B1C20) else if (n.tone == "gray") Color(0xFFF2F3F5) else TT.Text
    val fg2 = fg.copy(alpha = 0.66f)
    val done = n.items.count { it.done }
    Column(Modifier.fillMaxWidth().clip(RoundedCornerShape(Dim.cardRadius)).background(bg).pressable { onClick() }.padding(Dim.cardPad)) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(n.title.ifBlank { "Sin título" }, style = Type.cardTitle.copy(color = if (n.title.isBlank()) fg2 else fg), modifier = Modifier.weight(1f), maxLines = 2)
            if (n.pinned) Icon(Icons.Rounded.PushPin, "Fijada", tint = fg2, modifier = Modifier.size(16.dp))
        }
        if (n.body.isNotBlank()) Text(n.body, style = Type.secondary.copy(color = fg2), maxLines = 4, overflow = TextOverflow.Ellipsis, modifier = Modifier.padding(top = 4.dp))
        if (n.items.isNotEmpty()) {
            Spacer(Modifier.height(10.dp))
            Row(verticalAlignment = Alignment.CenterVertically) {
                LinearProgressIndicator(progress = { done / n.items.size.toFloat() }, modifier = Modifier.weight(1f).height(5.dp), color = TT.Positive, trackColor = fg.copy(alpha = 0.12f), drawStopIndicator = {})
                Spacer(Modifier.width(8.dp)); Text("$done/${n.items.size}", style = Type.label.copy(color = fg2, fontFeatureSettings = "tnum"))
            }
            n.items.take(5).forEach { it ->
                Row(Modifier.fillMaxWidth().heightIn(min = 44.dp).pressable(scaleDown = false, role = Role.Checkbox) { AcademicRepo.edit { a -> Edits.toggleNoteItem(a, n.id, it.id) } }
                    .semantics { toggleableState = androidx.compose.ui.state.ToggleableState(it.done); contentDescription = it.t }, verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(20.dp).clip(RoundedCornerShape(6.dp)).background(if (it.done) TT.Positive else Color.Transparent)
                        .border(1.5.dp, if (it.done) TT.Positive else fg2, RoundedCornerShape(6.dp)), contentAlignment = Alignment.Center) {
                        if (it.done) Icon(Icons.Rounded.Check, null, tint = Color.White, modifier = Modifier.size(14.dp))
                    }
                    Spacer(Modifier.width(10.dp))
                    Text(it.t, style = Type.body.copy(color = if (it.done) fg2 else fg, textDecoration = if (it.done) TextDecoration.LineThrough else null), maxLines = 2)
                }
            }
            if (n.items.size > 5) Text("y ${n.items.size - 5} más", style = Type.label.copy(color = fg2))
        }
        if (n.tags.isNotEmpty()) Text(n.tags.joinToString("  ") { "#$it" }, style = Type.label.copy(color = TT.AccentText), modifier = Modifier.padding(top = 8.dp))
        Text("Editada " + Instant.ofEpochMilli(n.updated).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("d MMM, HH:mm", Cal.es)),
            style = Type.label.copy(color = fg2), modifier = Modifier.padding(top = 6.dp))
    }
}

/** Hábito: marcar hoy, últimos 14 días marcables, racha y cumplimiento de 30 días. */
@Composable
private fun HabitCard(h: Habit, ts: String, onDelete: () -> Unit) {
    val nav = LocalNav.current
    val st = Cal.streak(h, ts)
    val col = hexColor(h.color)
    TTCard {
        Row(verticalAlignment = Alignment.CenterVertically) {
            CheckCircle(h.done(ts), col, "Hoy: ${h.name}") {
                val was = h.done(ts)
                AcademicRepo.edit { Edits.toggleHabit(it, h.id, ts) }
                if (!was) nav.show("¡Hecho! Racha de ${st + 1} ${if (st + 1 == 1) "día" else "días"}")
            }
            Column(Modifier.weight(1f)) {
                Text(h.name, style = Type.cardTitle, maxLines = 2)
                Text((if (st > 0) "Racha de $st ${if (st == 1) "día" else "días"}" else "Sin racha") + " · ${Cal.last30(h, ts)}/30 días", style = Type.secondary)
            }
            CircleIconButton(Icons.Rounded.Delete, "Eliminar hábito", onDelete, bg = TT.Card)
        }
        Spacer(Modifier.height(10.dp))
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            (13 downTo 0).forEach { i ->
                val d = Cal.addD(ts, -i.toLong()); val on = h.done(d)
                Box(
                    Modifier.weight(1f).aspectRatio(1f).padding(2.dp).clip(RoundedCornerShape(6.dp))
                        .background(if (on) col else TT.Control)
                        .pressable(scaleDown = false, role = Role.Checkbox) { AcademicRepo.edit { Edits.toggleHabit(it, h.id, d) } }
                        .semantics { contentDescription = "${Cal.shortDay(d)}: ${if (on) "hecho" else "sin hacer"}" },
                )
            }
        }
        Text("Últimos 14 días · toca un día para corregirlo", style = Type.label, modifier = Modifier.padding(top = 6.dp))
    }
}

/** Editor de nota o lista (pantalla de detalle; el teclado no tapa los campos). */
@Composable
fun NoteEditorScreen(ac: AcadState, id: String?, asList: Boolean) {
    val nav = LocalNav.current
    val orig = id?.let { x -> ac.academic.notes.firstOrNull { it.id == x } }
    val newId = rememberSaveable { newUid() }
    var title by rememberSaveable { mutableStateOf(orig?.title ?: "") }
    var body by rememberSaveable { mutableStateOf(orig?.body ?: "") }
    var items by remember { mutableStateOf(orig?.items ?: emptyList()) }
    var tags by rememberSaveable { mutableStateOf(orig?.tags?.joinToString(", ") ?: "") }
    var tone by rememberSaveable { mutableStateOf(orig?.tone ?: "dark") }
    var pinned by rememberSaveable { mutableStateOf(orig?.pinned ?: false) }
    var draft by rememberSaveable { mutableStateOf("") }
    var confirmDel by remember { mutableStateOf(false) }

    fun build(): Note {
        val its = (items + listOfNotNull(draft.trim().takeIf { it.isNotEmpty() }?.let { NoteItem(newUid(), it, false) })).filter { it.t.isNotBlank() }
        val tg = tags.split(",").map { it.trim().removePrefix("#").lowercase() }.filter { it.isNotEmpty() }.distinct()
        return Note(orig?.id ?: newId, title.trim(), body, its, tone, pinned, tg, System.currentTimeMillis())
    }
    fun save(): Boolean {
        val n = build()
        if (orig != null && n.copy(updated = orig.updated) == orig) return false
        if (n.isEmpty) { if (orig != null) { AcademicRepo.edit { Edits.deleteNote(it, orig.id) }; nav.show("Nota vacía eliminada") }; return true }
        AcademicRepo.edit { Edits.upsertNote(it, n) }
        nav.show(if (orig != null) "Nota guardada" else "Nota creada")
        return true
    }
    // Al salir con Atrás también se guarda (como al cerrar el editor en MIBUNKER).
    androidx.activity.compose.BackHandler { save(); nav.pop() }

    DetailScaffold(if (orig == null) (if (asList) "Nueva lista" else "Nueva nota") else "Editar nota", actions = {
        CircleIconButton(Icons.Rounded.PushPin, if (pinned) "Desfijar" else "Fijar", { pinned = !pinned }, bg = if (pinned) TT.Accent.copy(alpha = 0.3f) else TT.Control)
        CircleIconButton(Icons.Rounded.Check, "Guardar", { save(); nav.pop() }, bg = TT.Accent)
    }) {
        item {
            NoteInput(title, { title = it }, if (asList && orig == null) "Nombre de la lista" else "Título", Type.section)
            Spacer(Modifier.height(8.dp))
            NoteInput(body, { body = it }, "Escribe tu nota…", Type.body, single = false)
            Spacer(Modifier.height(16.dp))
            Text("Tareas", style = Type.label)
            items.forEachIndexed { i, it ->
                Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                    CheckCircle(it.done, TT.Positive, it.t.ifBlank { "Tarea" }) { items = items.mapIndexed { j, x -> if (j == i) x.copy(done = !x.done) else x } }
                    Box(Modifier.weight(1f)) { NoteInput(it.t, { v -> items = items.mapIndexed { j, x -> if (j == i) x.copy(t = v) else x } }, "Tarea", Type.body) }
                    Box(Modifier.size(Dim.touch).pressable { items = items.filterIndexed { j, _ -> j != i } }.semantics { contentDescription = "Quitar tarea" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, null, tint = TT.TextSecondary, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Row(Modifier.fillMaxWidth().heightIn(min = 48.dp), verticalAlignment = Alignment.CenterVertically) {
                Box(Modifier.size(Dim.touch), contentAlignment = Alignment.Center) { Icon(Icons.Rounded.Add, null, tint = TT.TextSecondary) }
                Box(Modifier.weight(1f)) {
                    NoteInput(draft, { draft = it }, "Añadir tarea (Intro)", Type.body, onDone = {
                        if (draft.isNotBlank()) { items = items + NoteItem(newUid(), draft.trim(), false); draft = "" }
                    })
                }
            }
            Spacer(Modifier.height(16.dp))
            LabeledField("Etiquetas", tags, { tags = it.take(200) }, placeholder = "Separadas por comas", help = "Sirven para filtrar las notas.")
            Spacer(Modifier.height(16.dp))
            FieldLabel("Fondo")
            Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                listOf("dark" to "Negro", "gray" to "Gris", "light" to "Blanco").forEach { (k, l) -> Chip(l, tone == k, { tone = k }) }
            }
            if (orig != null) {
                Spacer(Modifier.height(24.dp))
                PillButton("Eliminar nota", { confirmDel = true }, Modifier.fillMaxWidth(), tone = ButtonTone.Danger, icon = Icons.Rounded.Delete)
            }
            Spacer(Modifier.height(16.dp))
            PillButton("Guardar", { save(); nav.pop() }, Modifier.fillMaxWidth())
            Spacer(Modifier.imePadding())
        }
    }
    if (confirmDel && orig != null) ConfirmDialog("Eliminar nota", "Esta acción no se puede deshacer.", "Eliminar",
        onConfirm = { AcademicRepo.edit { Edits.deleteNote(it, orig.id) }; confirmDel = false; nav.show("Nota eliminada"); nav.pop() }, onDismiss = { confirmDel = false })
}

@Composable
private fun NoteInput(value: String, onChange: (String) -> Unit, placeholder: String, style: androidx.compose.ui.text.TextStyle, single: Boolean = true, onDone: (() -> Unit)? = null) {
    Box(Modifier.fillMaxWidth().padding(vertical = 8.dp)) {
        if (value.isEmpty()) Text(placeholder, style = style.copy(color = TT.TextSecondary))
        BasicTextField(value, onChange, singleLine = single, textStyle = style.copy(color = TT.Text), cursorBrush = SolidColor(TT.Accent),
            keyboardOptions = KeyboardOptions(capitalization = KeyboardCapitalization.Sentences, imeAction = if (onDone != null) ImeAction.Done else ImeAction.Default),
            keyboardActions = KeyboardActions(onDone = { onDone?.invoke() }),
            modifier = Modifier.fillMaxWidth().heightIn(min = if (single) 32.dp else 140.dp).semantics { contentDescription = placeholder })
    }
}
