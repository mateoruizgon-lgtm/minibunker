package app.minibunker.ui.tt

import androidx.compose.foundation.background
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowLeft
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.saveable.rememberSaveable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.contentDescription
import androidx.compose.ui.semantics.semantics
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.theme.*
import app.thinktwice.core.*
import app.thinktwice.data.Store
import app.thinktwice.system.Perms
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.Locale

private val es = Locale("es", "ES")

/** Pestaña thinktwice: nombre y logotipo originales, resumen de hoy y acceso a sus funciones. */
@Composable
fun ThinktwiceScreen(state: AppState) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val tick = LocalResumeTick.current
    val zone = ZoneId.systemDefault()
    var offset by rememberSaveable { mutableIntStateOf(0) }
    val date = LocalDate.now(zone).minusDays(offset.toLong())
    val usage by rememberDayUsage(date)
    val hasUsage = remember(tick) { Perms.hasUsageAccess(ctx) }
    val guardOn = remember(tick) { Perms.isGuardEnabled(ctx) }
    val now by produceState(System.currentTimeMillis()) { while (true) { value = System.currentTimeMillis(); delay(1000) } }
    val activeSessions = state.sessions.filter { it.isActive(now) }
    val activeRoutines = RuleEngine.restrictionsAt(state, now, zone).filter { it.kind == Restriction.Kind.ROUTINE }
    val needsGuard = state.pausedApps.isNotEmpty() || activeSessions.isNotEmpty() || state.routines.any { it.enabled }
    var confirmEnd by remember { mutableStateOf<BlockSession?>(null) }
    val haptic = rememberHaptic()

    TabScaffold(
        "thinktwice",
        leading = { Logo(22.dp, Modifier.semantics { contentDescription = "thinktwice" }) },
        actions = {
            CircleIconButton(Icons.Rounded.BarChart, "Estadísticas", { nav.push(Dest.Stats) })
            Avatar(state.settings.name) { nav.profileOpen = true }
        },
    ) {
        item {
            Column(Modifier.fillMaxWidth().padding(top = 12.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                val label = if (offset == 0) "Tiempo de uso hoy" else "Tiempo de uso · " + date.format(DateTimeFormatter.ofPattern("EEEE d MMM", es))
                Text(label, style = Type.secondary)
                Spacer(Modifier.height(4.dp))
                when (val u = usage) {
                    UsageResult.Loading -> Text("…", style = Type.hero)
                    is UsageResult.Done -> HeroDuration(u.usage?.values?.sum())
                }
                if (!hasUsage) Text("Sin permiso de uso: los días se muestran sin medición", style = Type.label.copy(color = TT.Danger), textAlign = TextAlign.Center)
                else if ((usage as? UsageResult.Done)?.usage == null) Text("Sin datos registrados para este día", style = Type.label)
                Spacer(Modifier.height(14.dp))
                Row(Modifier.clip(CircleShape).background(TT.Control), verticalAlignment = Alignment.CenterVertically) {
                    Box(Modifier.size(Dim.touch).pressable(enabled = offset < 29) { offset++ }.semantics { contentDescription = "Día anterior" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowLeft, null, tint = if (offset < 29) TT.Text else TT.TextSecondary)
                    }
                    Text(when (offset) { 0 -> "Hoy"; 1 -> "Ayer"; else -> date.format(DateTimeFormatter.ofPattern("d MMM", es)) },
                        style = Type.button.copy(fontSize = Type.secondary.fontSize), modifier = Modifier.widthIn(min = 64.dp), textAlign = TextAlign.Center)
                    Box(Modifier.size(Dim.touch).pressable(enabled = offset > 0) { offset-- }.semantics { contentDescription = "Día siguiente" }, contentAlignment = Alignment.Center) {
                        Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = if (offset > 0) TT.Text else TT.TextSecondary)
                    }
                }
                Spacer(Modifier.height(24.dp))
                Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    QuickAction(Icons.Rounded.HourglassTop, "Pausa consciente", { nav.sheet = SheetKind.Pause })
                    QuickAction(Icons.Rounded.Lock, "Bloquear ahora", { nav.sheet = SheetKind.Block })
                    QuickAction(Icons.Rounded.EventRepeat, "Rutinas", { nav.push(Dest.Routines) })
                    QuickAction(Icons.Rounded.Flag, "Retos", { nav.push(Dest.Challenges) })
                    QuickAction(Icons.Rounded.BarChart, "Estadísticas", { nav.push(Dest.Stats) })
                }
            }
        }
        if (needsGuard && !guardOn) item {
            Spacer(Modifier.height(Dim.section))
            Banner(BannerKind.Error, "Protección no operativa",
                "Tus pausas y bloqueos no pueden mostrarse hasta activar el servicio de minibunker en Accesibilidad.",
                "Revisar diagnóstico") { nav.push(Dest.Diagnostics) }
        }
        if (activeSessions.isNotEmpty() || activeRoutines.isNotEmpty()) {
            item { SectionHeader("Ahora") }
            items(activeSessions, key = { it.id }) { s ->
                ActiveCard(s.name, if (s.isStudy) "Bloque de estudio protegido" else "Bloqueo", s.packages, s.endMs - now, guardOn,
                    action = "Salida de emergencia", onAction = { confirmEnd = s })
                Spacer(Modifier.height(Dim.related))
            }
            items(activeRoutines, key = { "r" + it.id }) { r ->
                ActiveCard(r.name, "Rutina", r.packages, r.endMs - now, guardOn, onClick = { nav.push(Dest.RoutineEdit(r.id)) })
                Spacer(Modifier.height(Dim.related))
            }
        }
        item {
            SectionHeader("Productividad", "Desglose") { nav.push(Dest.Stats) }
            val pct = (usage as? UsageResult.Done)?.usage?.let { Productivity.percent(it, state.classes) }
            TTCard(onClick = { nav.push(Dest.Stats) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Ring(pct, size = 96.dp, stroke = 9.dp)
                    Spacer(Modifier.width(18.dp))
                    Column(Modifier.weight(1f)) {
                        Text(if (pct == null) "Sin datos suficientes" else "Uso clasificado como útil", style = Type.cardTitle)
                        Spacer(Modifier.height(4.dp))
                        Text(
                            if (pct == null) "Clasifica tus apps como útiles o distractoras para calcularlo."
                            else "100 × útil ÷ (útil + distractora). Neutras y sin clasificar no cuentan.",
                            style = Type.secondary,
                        )
                    }
                }
            }
        }
        item {
            SectionHeader("Próxima rutina", "Todas") { nav.push(Dest.Routines) }
            val next = RuleEngine.nextRoutineStart(state, now, zone)
            if (next == null) EmptyState(Icons.Rounded.EventRepeat, "Sin rutinas programadas", "Crea una rutina o vincula la protección a una clase desde la Agenda.", "Nueva rutina") { nav.push(Dest.RoutineEdit(null)) }
            else {
                val (r, w) = next
                val start = java.time.Instant.ofEpochMilli(w.first).atZone(zone)
                val day = when (start.toLocalDate()) { LocalDate.now(zone) -> "Hoy"; LocalDate.now(zone).plusDays(1) -> "Mañana"; else -> start.format(DateTimeFormatter.ofPattern("EEEE", es)).replaceFirstChar { it.uppercase() } }
                TTCard(onClick = { nav.push(Dest.RoutineEdit(r.id)) }) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        RowIcon(routineIcon(r.icon))
                        Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(r.name, style = Type.cardTitle)
                            Text("$day · ${Fmt.clock(r.startMin)} – ${Fmt.clock(r.endMin)}", style = Type.secondary)
                        }
                        AppStack(r.packages, 3)
                    }
                }
            }
        }
        item {
            SectionHeader("Actividad", "Ver todo") { nav.push(Dest.Stats) }
            val dayStart = date.atStartOfDay(zone).toInstant().toEpochMilli()
            val dayEnd = date.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
            val ev = state.events.filter { it.t in dayStart until dayEnd }
            TTCard(onClick = { nav.push(Dest.Stats) }) {
                Row(Modifier.fillMaxWidth()) {
                    Metric("${ev.count { it.type == EventType.PAUSE_SHOWN }}", "pausas", Modifier.weight(1f))
                    Metric("${ev.count { it.type == EventType.EXITED }}", "no continuaste", Modifier.weight(1f))
                    Metric("${ev.count { it.type == EventType.BLOCK_SHOWN }}", "intentos bloqueados", Modifier.weight(1f))
                }
                val top = (usage as? UsageResult.Done)?.usage?.entries?.sortedByDescending { it.value }?.take(3).orEmpty()
                if (top.isNotEmpty()) {
                    Spacer(Modifier.height(16.dp))
                    top.forEach { (pkg, ms) ->
                        Row(Modifier.fillMaxWidth().padding(vertical = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                            AppIcon(pkg, 32.dp); Spacer(Modifier.width(12.dp))
                            Text(appLabel(pkg), style = Type.bodyMedium, modifier = Modifier.weight(1f), maxLines = 1)
                            Text(Fmt.duration(ms), style = Type.tabular.copy(color = TT.TextSecondary))
                        }
                    }
                }
            }
        }
        item {
            SectionHeader("Más")
            ListGroup {
                ListRow("Historial de sesiones", null, leading = { RowIcon(Icons.Rounded.History) }, chevron = true, onClick = { nav.push(Dest.Sessions) })
                RowDivider()
                ListRow("Clasificar apps", "Útil, distractora o neutra", leading = { RowIcon(Icons.Rounded.Tune) }, chevron = true, onClick = { nav.push(Dest.Classify) })
                RowDivider()
                ListRow("Frases de la pausa", "${state.messages.size} frases", leading = { RowIcon(Icons.Rounded.FormatQuote) }, chevron = true, onClick = { nav.push(Dest.Messages) })
                RowDivider()
                ListRow("Plantillas de bloqueo", state.templates.joinToString(", ") { it.name }, leading = { RowIcon(Icons.Rounded.Dashboard) }, chevron = true, onClick = { nav.push(Dest.Templates) })
                RowDivider()
                ListRow("Diagnóstico", null, leading = { RowIcon(Icons.Rounded.HealthAndSafety) }, chevron = true, onClick = { nav.push(Dest.Diagnostics) })
                RowDivider()
                ListRow("Cómo funciona", null, leading = { RowIcon(Icons.Rounded.Info) }, chevron = true, onClick = { nav.push(Dest.About) })
            }
        }
    }

    confirmEnd?.let { s ->
        ConfirmDialog(
            "¿Terminar «${s.name}»?",
            if (s.isStudy) "Es la salida de emergencia: las apps quedarán disponibles y podrás seguir estudiando sin protección en este periodo. Quedará registrada."
            else "Es la salida de emergencia: las apps quedarán disponibles salvo que otra sesión o rutina siga vigente. Quedará registrada en tu historial.",
            "Terminar",
            onConfirm = {
                val t = System.currentTimeMillis()
                Store.update { st -> st.copy(sessions = st.sessions.map { if (it.id == s.id) it.copy(endedEarlyAtMs = t) else it }) }
                Store.log(EventType.SESSION_ENDED_EARLY, ref = s.id)
                app.minibunker.study.StudyController.refresh()
                confirmEnd = null; haptic(); nav.show("Protección terminada")
            },
            onDismiss = { confirmEnd = null },
        )
    }
}
