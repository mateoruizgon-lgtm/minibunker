package app.minibunker.study

import android.Manifest
import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import android.util.Log
import androidx.core.app.NotificationCompat
import androidx.core.app.NotificationManagerCompat
import androidx.core.content.ContextCompat
import app.minibunker.R
import app.minibunker.academic.*
import app.minibunker.json.*
import app.thinktwice.core.EventType
import app.thinktwice.data.Store
import app.thinktwice.system.GuardService
import app.thinktwice.system.Notifier
import app.thinktwice.system.Perms
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import java.io.File
import java.time.Instant
import java.time.ZoneId
import java.time.format.DateTimeFormatter
import java.util.concurrent.Executors

/** Resumen que se muestra al terminar: solo datos realmente registrados. */
data class StudySummary(
    val runId: String, val subject: String, val topic: String?, val planId: String?, val minutes: Int, val saved: Boolean,
    val protectedApps: Int, val pausesShown: Int, val continued: Int, val exited: Int, val blockedAttempts: Int, val emergencyUsed: Boolean,
)

/** Parámetros con los que se abre la hoja «Empezar a estudiar». */
data class StudyRequest(val subject: String = "", val planId: String? = null, val topic: String? = null)

/**
 * Controlador del temporizador: guarda el estado por marcas de tiempo, registra la sesión una sola vez
 * (por id), aplica la protección vinculada y mantiene la alarma y la notificación de minibunker.
 */
object StudyController {
    private const val FILE = "study.json"
    private const val CH_RUN = "study"
    private const val CH_DONE = "study_done"
    private const val ID_RUN = 20
    private const val ID_DONE = 21
    private val io = Executors.newSingleThreadExecutor()
    private lateinit var app: Context
    @Volatile private var ready = false

    private val _run = MutableStateFlow<StudyRun?>(null)
    val run: StateFlow<StudyRun?> get() = _run
    private val _prefs = MutableStateFlow(PomoPrefs())
    val prefs: StateFlow<PomoPrefs> get() = _prefs
    private val _summary = MutableStateFlow<StudySummary?>(null)
    val summary: StateFlow<StudySummary?> get() = _summary

    fun init(c: Context) {
        if (ready) return
        synchronized(this) {
            if (ready) return
            app = c.applicationContext
            runCatching {
                File(app.filesDir, FILE).takeIf { it.exists() }?.let { f ->
                    val o = Json.obj(f.readText())
                    _prefs.value = PomoPrefs.from(o.objOrNull("prefs")) ?: PomoPrefs()
                    _run.value = StudyRun.from(o.objOrNull("run"))
                }
            }.onFailure { Log.e("minibunker", "Estado de estudio ilegible", it) }
            createChannels()
            ready = true
        }
    }

    /** Tras reinicio, actualización o al abrir la app: recalcula todo desde las marcas de tiempo. */
    fun restore(c: Context) {
        init(c); Store.init(c); AcademicRepo.init(c)
        commit(_run.value?.let { StudyEngine.tick(it, now()) }, notifyPhaseEnd = true)
    }

    private fun now() = System.currentTimeMillis()

    // ───────────── Acciones ─────────────

    fun start(req: StudyRequest, prefs: PomoPrefs, protect: Boolean, packages: Set<String>) {
        _run.value?.let { finish(showSummary = false) }
        _prefs.value = prefs.copy(subject = req.subject)
        val r = StudyEngine.start(newUid(), req.subject, req.planId, req.topic, prefs, protect, packages, now())
        _summary.value = null
        commit(r)
    }

    fun toggle() { val r = _run.value ?: return; commit(if (r.running) StudyEngine.pause(r, now()) else StudyEngine.resume(r, now())) }
    fun pause() { _run.value?.let { commit(StudyEngine.pause(it, now())) } }
    fun resume() { _run.value?.let { commit(StudyEngine.resume(it, now())) } }
    fun reset() { _run.value?.let { commit(StudyEngine.reset(it)) } }
    fun setPhase(p: Phase) { _run.value?.let { commit(StudyEngine.setPhase(it, p, now())) } }
    fun tick() { _run.value?.let { r -> val t = StudyEngine.tick(r, now()); if (t != r) commit(t, notifyPhaseEnd = true) } }
    /** Reaplica el estado (p. ej. tras usar la salida de emergencia o conceder un permiso). */
    fun refresh() { _run.value?.let { commit(StudyEngine.tick(it, now()), notifyPhaseEnd = true) } }

    fun setPrefs(p: PomoPrefs) {
        _prefs.value = p
        _run.value?.let { commit(StudyEngine.changeDurations(it, p.copy(subject = it.subject))) } ?: persist()
    }

    /** Termina el periodo: registra lo estudiado (una vez) y prepara el resumen. */
    fun finish(showSummary: Boolean = true) {
        val r0 = _run.value ?: return
        val r = StudyEngine.finish(r0, now())
        val rec = StudyEngine.record(r)
        if (rec != null) saveRecord(rec)
        val st = Store.state.value
        val ev = st.events.filter { it.t >= r.startedAt }
        val pk = r.packages
        val summary = StudySummary(
            r.id, r.subjectLabel, r.topic, r.planId, rec?.mins ?: 0, rec != null, if (r.protect) pk.size else 0,
            ev.count { it.type == EventType.PAUSE_SHOWN }, ev.count { it.type == EventType.CONTINUED }, ev.count { it.type == EventType.EXITED },
            ev.count { it.type == EventType.BLOCK_SHOWN && (it.pkg == null || it.pkg in pk) }, StudyEngine.emergencyUsed(r, st.sessions),
        )
        commit(null)
        if (showSummary) _summary.value = summary
    }

    fun dismissSummary() { _summary.value = null }

    /** Marca como completado el tema trabajado (desde el resumen). */
    fun completeTopic(planId: String) = AcademicRepo.edit { Edits.setPlanDone(it, planId, true) }

    // ───────────── Núcleo ─────────────

    private fun saveRecord(rec: SessionRecord) {
        val date = Instant.ofEpochMilli(rec.startedAt).atZone(ZoneId.systemDefault()).toLocalDate().toString()
        AcademicRepo.edit { Edits.upsertSession(it, StudySession(rec.id, rec.subject, date, rec.startedAt, rec.mins)) }
    }

    @Synchronized
    private fun commit(r0: StudyRun?, notifyPhaseEnd: Boolean = false) {
        val prev = _run.value
        val t = now()
        var r = r0
        // Salida de emergencia usada desde thinktwice: se sigue estudiando sin volver a proteger.
        if (r != null && !r.protectionStopped && StudyEngine.emergencyUsed(r, Store.state.value.sessions)) r = r.copy(protectionStopped = true)
        // Un bloque de concentración terminado se registra al momento (mismo id → se actualiza, no se duplica).
        if (r != null && prev != null && r.id == prev.id && r.cycle > prev.cycle) {
            StudyEngine.record(r)?.let { saveRecord(it) }
            if (notifyPhaseEnd) postDone("¡Bien hecho! Toca descansar", "${r.subjectLabel} · ${r.cycle} ${if (r.cycle == 1) "bloque" else "bloques"} completados")
        } else if (r != null && prev != null && r.id == prev.id && notifyPhaseEnd && prev.phase != Phase.FOCUS && r.phase == Phase.FOCUS && prev.running) {
            postDone("Descanso terminado", "Cuando quieras, empieza otro bloque de ${r.subjectLabel}.")
        }
        _run.value = r
        Store.update { s -> s.copy(sessions = StudyEngine.reconcileProtection(r, s.sessions, t) { Store.newId() }) }
        GuardService.rulesChanged()
        Notifier.refresh(app)
        persist()
        scheduleAlarm(r)
        showOngoing(r)
    }

    private fun persist() {
        if (!ready) return
        val text = Json.write(linkedMapOf("prefs" to _prefs.value.toJson(), "run" to _run.value?.toJson()))
        io.execute {
            runCatching {
                val f = File(app.filesDir, FILE); val tmp = File(f.path + ".tmp")
                tmp.writeText(text); if (!tmp.renameTo(f)) { f.delete(); tmp.renameTo(f) }
            }.onFailure { Log.e("minibunker", "No se pudo guardar el estudio", it) }
        }
    }

    // ───────────── Alarma y notificaciones ─────────────

    private fun alarmIntent() = PendingIntent.getBroadcast(app, 3, Intent(app, StudyAlarmReceiver::class.java),
        PendingIntent.FLAG_IMMUTABLE or PendingIntent.FLAG_UPDATE_CURRENT)

    private fun scheduleAlarm(r: StudyRun?) {
        val am = app.getSystemService(AlarmManager::class.java) ?: return
        val pi = alarmIntent(); am.cancel(pi)
        if (r == null || !r.running) return
        val at = r.endAt + 300
        try {
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
            else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi)
        } catch (e: SecurityException) { am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, at, pi) }
    }

    private fun createChannels() {
        val nm = app.getSystemService(NotificationManager::class.java) ?: return
        nm.createNotificationChannel(NotificationChannel(CH_RUN, "Estudio en curso", NotificationManager.IMPORTANCE_LOW))
        nm.createNotificationChannel(NotificationChannel(CH_DONE, "Fin de bloque y descanso", NotificationManager.IMPORTANCE_HIGH))
    }

    private fun canPost() = Build.VERSION.SDK_INT < 33 ||
        ContextCompat.checkSelfPermission(app, Manifest.permission.POST_NOTIFICATIONS) == PackageManager.PERMISSION_GRANTED

    private fun showOngoing(r: StudyRun?) {
        val nm = NotificationManagerCompat.from(app)
        if (r == null || !canPost()) { nm.cancel(ID_RUN); return }
        val t = now()
        val op = Perms.isGuardEnabled(app)
        val head = if (r.phase == Phase.FOCUS) r.subjectLabel else r.phase.label
        val tail = StudyEngine.indicator(r, t, op).substringAfterLast(" · ")
        val b = NotificationCompat.Builder(app, CH_RUN)
            .setSmallIcon(R.drawable.ic_stat_mb)
            .setContentTitle("minibunker · " + if (r.phase == Phase.FOCUS) "Estudiando" else r.phase.label)
            .setSubText(r.topic ?: r.subjectLabel)
            .setOngoing(true).setOnlyAlertOnce(true).setSilent(true)
            .setCategory(NotificationCompat.CATEGORY_PROGRESS)
            .setContentIntent(Notifier.openApp(app))
        if (r.running) {
            val endTxt = Instant.ofEpochMilli(r.endAt).atZone(ZoneId.systemDefault()).format(DateTimeFormatter.ofPattern("HH:mm"))
            // Cuenta atrás del sistema: sigue avanzando con la pantalla bloqueada sin despertar la app.
            b.setWhen(r.endAt).setShowWhen(true).setUsesChronometer(true).setChronometerCountDown(true)
                .setContentText("$head · hasta las $endTxt · $tail")
        } else {
            b.setShowWhen(false).setContentText(StudyEngine.indicator(r, t, op))
        }
        try { nm.notify(ID_RUN, b.build()) } catch (_: SecurityException) {}
    }

    private fun postDone(title: String, text: String) {
        if (!canPost()) return
        val n = NotificationCompat.Builder(app, CH_DONE)
            .setSmallIcon(R.drawable.ic_stat_mb)
            .setContentTitle("minibunker · $title").setContentText(text)
            .setAutoCancel(true).setContentIntent(Notifier.openApp(app))
            .setPriority(NotificationCompat.PRIORITY_HIGH)
            .build()
        try { NotificationManagerCompat.from(app).notify(ID_DONE, n) } catch (_: SecurityException) {}
    }
}

/** Fin de bloque o de descanso con la app cerrada o la pantalla bloqueada. */
class StudyAlarmReceiver : BroadcastReceiver() {
    override fun onReceive(c: Context, i: Intent) { StudyController.restore(c) }
}
