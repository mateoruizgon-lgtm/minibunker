package app.minibunker.ui.frost

import androidx.activity.compose.BackHandler
import androidx.compose.animation.core.Animatable
import androidx.compose.animation.core.FastOutSlowInEasing
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.Orientation
import androidx.compose.foundation.gestures.draggable
import androidx.compose.foundation.gestures.rememberDraggableState
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.Check
import androidx.compose.material.icons.rounded.Close
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.runtime.snapshots.Snapshot
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.draw.drawWithContent
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.*
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.drawscope.clipPath
import androidx.compose.ui.graphics.drawscope.translate
import androidx.compose.ui.graphics.layer.GraphicsLayer
import androidx.compose.ui.graphics.layer.drawLayer
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.layout.positionInRoot
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.IntOffset
import androidx.compose.ui.unit.IntSize
import androidx.compose.ui.unit.dp
import androidx.compose.ui.zIndex
import app.minibunker.ui.components.PillButton
import app.minibunker.ui.components.ButtonTone
import app.minibunker.ui.components.pressable
import app.minibunker.ui.theme.*
import kotlinx.coroutines.delay
import kotlinx.coroutines.launch
import kotlin.math.roundToInt

/* ═════════════════════════ Fondo muestreado ═════════════════════════
 * La pantalla se graba en una capa gráfica (GraphicsLayer) que se dibuja normalmente y que,
 * además, las superficies translúcidas vuelven a dibujar desenfocada y recortada a su forma.
 * Orden de composición: 1) pantalla de fondo, 2) desenfoque recortado, 3) contenido nítido encima.
 */
class Backdrop(val layer: GraphicsLayer) {
    var origin by mutableStateOf(Offset.Zero)
    /** Se incrementa cada vez que el fondo se vuelve a dibujar, para refrescar las superficies. */
    var version by mutableIntStateOf(0)
}

val LocalBackdrop = staticCompositionLocalOf<Backdrop?> { null }

@Composable
fun rememberBackdrop(): Backdrop { val l = rememberGraphicsLayer(); return remember(l) { Backdrop(l) } }

/** Graba el contenido en la capa del fondo y lo dibuja. */
fun Modifier.backdropSource(b: Backdrop): Modifier = this
    .onGloballyPositioned { b.origin = it.positionInRoot() }
    .drawWithContent {
        b.layer.record { this@drawWithContent.drawContent() }
        drawLayer(b.layer)
        // Sin observar la lectura: si no, el propio fondo se invalidaría a sí mismo en bucle.
        Snapshot.withoutReadObservation { b.version++ }
    }

/**
 * Superficie translúcida compartida: desenfoque real del contenido posterior (Android 12+),
 * tinte translúcido, borde fino. En equipos sin desenfoque fluido usa una superficie más opaca del mismo tono.
 */
@Composable
fun Modifier.frosted(shape: Shape, blur: Dp = 28.dp, tint: Color = TT.Glass, border: Boolean = true): Modifier {
    val b = LocalBackdrop.current
    val capable = LocalBlurCapable.current && b != null
    val blurLayer = rememberGraphicsLayer()
    var pos by remember { mutableStateOf(Offset.Zero) }
    val opaque = TT.GlassOpaque
    val borderColor = TT.GlassBorder
    return this
        .onGloballyPositioned { pos = it.positionInRoot() }
        .drawBehind {
            val outline = shape.createOutline(size, layoutDirection, this)
            val path = Path().apply { addOutline(outline) }
            if (capable && b != null && size.width >= 1f && size.height >= 1f) {
                @Suppress("UNUSED_VARIABLE") val v = b.version // lectura: redibuja cuando cambia el fondo
                val r = blur.toPx()
                blurLayer.renderEffect = BlurEffect(r, r, TileMode.Clamp)
                blurLayer.record(size = IntSize(size.width.roundToInt(), size.height.roundToInt())) {
                    translate(b.origin.x - pos.x, b.origin.y - pos.y) { drawLayer(b.layer) }
                }
                clipPath(path) { drawLayer(blurLayer) }
                drawPath(path, tint)
            } else {
                drawPath(path, opaque)
            }
            if (border) drawOutline(outline, borderColor, style = Stroke(1.dp.toPx()))
        }
}

/* ═════════════════════════ Capa superpuesta (portal) ═════════════════════════
 * Hojas y menús se dibujan por encima de la pantalla (y fuera de la capa del fondo) aunque
 * se declaren dentro de cada pantalla, que conserva su estado.
 */
class OverlayEntry(val key: Any, val modal: Boolean) {
    var content: State<@Composable () -> Unit>? = null
    var visible by mutableStateOf(true)
}

class OverlayHost {
    val entries = mutableStateListOf<OverlayEntry>()
    val hasModal get() = entries.any { it.modal }
    fun remove(e: OverlayEntry) { entries.remove(e) }
}

val LocalOverlay = staticCompositionLocalOf { OverlayHost() }

@Composable
fun OverlayLayer(host: OverlayHost) {
    host.entries.forEachIndexed { i, e ->
        key(e.key) { Box(Modifier.zIndex(i.toFloat())) { e.content?.value?.invoke() } }
    }
}

@Composable
private fun rememberOverlay(modal: Boolean, content: @Composable (OverlayEntry) -> Unit): OverlayEntry {
    val host = LocalOverlay.current
    val entry = remember { OverlayEntry(Any(), modal) }
    val latest = rememberUpdatedState<@Composable () -> Unit> { content(entry) }
    DisposableEffect(entry) {
        entry.content = latest
        entry.visible = true
        if (entry !in host.entries) host.entries.add(entry)
        onDispose { entry.visible = false } // la propia hoja se retira al terminar su animación de salida
    }
    return entry
}

/* ═════════════════════════ Hoja inferior ═════════════════════════ */

/**
 * Hoja translúcida para formularios: tirador, título, campos desplazables y acción principal
 * accesible con el teclado abierto. Se abre al declararla y se cierra al dejar de declararla.
 */
@Composable
fun FrostSheet(
    onDismiss: () -> Unit,
    title: String,
    primary: String? = null,
    primaryEnabled: Boolean = true,
    onPrimary: (() -> Unit)? = null,
    primaryTone: ButtonTone = ButtonTone.Light,
    returnFocus: FocusRequester? = null,
    footer: (@Composable ColumnScope.() -> Unit)? = null,
    scrollable: Boolean = true,
    content: @Composable ColumnScope.() -> Unit,
) {
    val dismiss by rememberUpdatedState(onDismiss)
    rememberOverlay(modal = true) { entry ->
        SheetFrame(entry, title, { dismiss() }, primary, primaryEnabled, onPrimary, primaryTone, returnFocus, footer, scrollable, content)
    }
}

@Composable
private fun SheetFrame(
    entry: OverlayEntry, title: String, onDismiss: () -> Unit,
    primary: String?, primaryEnabled: Boolean, onPrimary: (() -> Unit)?, primaryTone: ButtonTone,
    returnFocus: FocusRequester?, footer: (@Composable ColumnScope.() -> Unit)?, scrollable: Boolean,
    content: @Composable ColumnScope.() -> Unit,
) {
    val host = LocalOverlay.current
    val reduce = LocalReduceMotion.current
    val progress = remember { Animatable(0f) }
    val drag = remember { Animatable(0f) }
    val scope = rememberCoroutineScope()
    val density = LocalDensity.current
    val isTop = host.entries.lastOrNull { it.modal && it.visible } === entry

    LaunchedEffect(entry.visible) {
        if (entry.visible) {
            if (reduce) progress.snapTo(1f) else progress.animateTo(1f, tween(Motion.sheet, easing = FastOutSlowInEasing))
        } else {
            if (reduce) progress.snapTo(0f) else progress.animateTo(0f, tween(Motion.sheet, easing = FastOutSlowInEasing))
            host.remove(entry)
            // Devuelve el foco al control que abrió la hoja.
            delay(16); runCatching { returnFocus?.requestFocus() }
        }
    }
    BackHandler(enabled = entry.visible && isTop) { onDismiss() }

    BoxWithConstraints(Modifier.fillMaxSize()) {
        val maxH = maxHeight * 0.92f
        // Exterior oscurecido: aparece a la vez que sube la hoja. Tocarlo la cierra.
        Box(
            Modifier.fillMaxSize()
                .graphicsLayer { alpha = progress.value }
                .background(TT.Scrim)
                .then(if (entry.visible) Modifier.clickable(remember { MutableInteractionSource() }, null) { onDismiss() } else Modifier)
                .clearAndSetSemantics { },
        )
        var sheetH by remember { mutableIntStateOf(0) }
        val shape = RoundedCornerShape(topStart = Dim.sheetRadius, topEnd = Dim.sheetRadius)
        Column(
            Modifier.align(Alignment.BottomCenter).fillMaxWidth().heightIn(max = maxH)
                .onGloballyPositioned { sheetH = it.size.height }
                .offset { IntOffset(0, ((1f - progress.value) * (sheetH.takeIf { it > 0 } ?: with(density) { maxH.roundToPx() })).roundToInt() + drag.value.roundToInt()) }
                .frosted(shape, blur = 36.dp)
                .clip(shape)
                .clickable(remember { MutableInteractionSource() }, null) {} // no deja pasar toques al exterior
                .semantics { paneTitle = title; isTraversalGroup = true }
                .imePadding(),
        ) {
            // Tirador: arrastrar hacia abajo cierra la hoja.
            Box(
                Modifier.fillMaxWidth().height(28.dp)
                    .draggable(
                        rememberDraggableState { d -> scope.launch { drag.snapTo((drag.value + d).coerceAtLeast(0f)) } },
                        Orientation.Vertical,
                        onDragStopped = { v ->
                            if (drag.value > sheetH * 0.28f || v > 1800f) onDismiss()
                            scope.launch { drag.animateTo(0f, tween(180)) }
                        },
                    ),
                contentAlignment = Alignment.Center,
            ) { Box(Modifier.size(36.dp, 4.dp).clip(CircleShape).background(TT.TextSecondary.copy(alpha = 0.45f))) }
            Row(Modifier.fillMaxWidth().padding(start = Dim.screenH, end = 8.dp, bottom = 6.dp), verticalAlignment = Alignment.CenterVertically) {
                Text(title, style = Type.section, modifier = Modifier.weight(1f).semantics { heading() })
                Box(
                    Modifier.size(Dim.touch).pressable { onDismiss() }.semantics { contentDescription = "Cerrar"; role = Role.Button },
                    contentAlignment = Alignment.Center,
                ) {
                    Box(Modifier.size(34.dp).clip(CircleShape).background(TT.Control), contentAlignment = Alignment.Center) {
                        Icon(Icons.Rounded.Close, null, tint = TT.Text, modifier = Modifier.size(18.dp))
                    }
                }
            }
            Column(
                Modifier.weight(1f, fill = false)
                    .then(if (scrollable) Modifier.verticalScroll(rememberScrollState()) else Modifier)
                    .padding(horizontal = Dim.screenH),
                content = content,
            )
            if (footer != null) Column(Modifier.padding(horizontal = Dim.screenH), content = footer)
            if (primary != null && onPrimary != null) {
                PillButton(primary, onPrimary, enabled = primaryEnabled, tone = primaryTone,
                    modifier = Modifier.fillMaxWidth().padding(start = Dim.screenH, end = Dim.screenH, top = 12.dp, bottom = 14.dp).navigationBarsPadding())
            } else Spacer(Modifier.navigationBarsPadding().height(16.dp))
        }
    }
}

/* ═════════════════════════ Menú anclado ═════════════════════════ */

data class MenuOption<T>(val value: T, val label: String, val detail: String? = null)

/**
 * Lista corta anclada al control que la abre (en lugar de una hoja).
 * [anchor] son los límites del control en la raíz (ver Modifier.anchorBounds).
 */
@Composable
fun <T> FrostMenu(anchor: Rect, options: List<MenuOption<T>>, selected: T?, onDismiss: () -> Unit, onSelect: (T) -> Unit) {
    val dismiss by rememberUpdatedState(onDismiss)
    val select by rememberUpdatedState(onSelect)
    rememberOverlay(modal = false) { entry -> MenuFrame(entry, anchor, options, selected, { dismiss() }, { select(it) }) }
}

@Composable
private fun <T> MenuFrame(entry: OverlayEntry, anchor: Rect, options: List<MenuOption<T>>, selected: T?, onDismiss: () -> Unit, onSelect: (T) -> Unit) {
    val host = LocalOverlay.current
    val reduce = LocalReduceMotion.current
    val p = remember { Animatable(0f) }
    LaunchedEffect(entry.visible) {
        if (entry.visible) { if (reduce) p.snapTo(1f) else p.animateTo(1f, tween(160)) }
        else { if (reduce) p.snapTo(0f) else p.animateTo(0f, tween(120)); host.remove(entry) }
    }
    BackHandler(enabled = entry.visible) { onDismiss() }
    val density = LocalDensity.current
    BoxWithConstraints(Modifier.fillMaxSize()) {
        Box(Modifier.fillMaxSize().then(if (entry.visible) Modifier.clickable(remember { MutableInteractionSource() }, null) { onDismiss() } else Modifier))
        val screenH = with(density) { maxHeight.toPx() }
        val screenW = with(density) { maxWidth.toPx() }
        val itemH = with(density) { 52.dp.toPx() }
        val estH = (options.size * itemH + with(density) { 16.dp.toPx() }).coerceAtMost(screenH * 0.6f)
        val below = anchor.bottom + estH < screenH - with(density) { 90.dp.toPx() }
        val w = maxOf(anchor.width, with(density) { 220.dp.toPx() }).coerceAtMost(screenW - with(density) { 32.dp.toPx() })
        val x = anchor.left.coerceIn(with(density) { 16.dp.toPx() }, screenW - w - with(density) { 16.dp.toPx() })
        val y = if (below) anchor.bottom + with(density) { 6.dp.toPx() } else anchor.top - estH - with(density) { 6.dp.toPx() }
        val shape = RoundedCornerShape(Dim.cardRadius)
        Column(
            Modifier.offset { IntOffset(x.roundToInt(), y.roundToInt()) }
                .width(with(density) { w.toDp() })
                .heightIn(max = with(density) { (screenH * 0.6f).toDp() })
                .graphicsLayer {
                    alpha = p.value; val s = 0.96f + 0.04f * p.value; scaleX = s; scaleY = s
                    transformOrigin = TransformOrigin(0.5f, if (below) 0f else 1f)
                }
                .shadow(16.dp, shape, ambientColor = Color.Black.copy(alpha = 0.3f), spotColor = Color.Black.copy(alpha = 0.3f))
                .frosted(shape)
                .clip(shape)
                .verticalScroll(rememberScrollState())
                .padding(vertical = 8.dp)
                .semantics { paneTitle = "Opciones" },
        ) {
            options.forEach { o ->
                val sel = o.value == selected
                Row(
                    Modifier.fillMaxWidth().heightIn(min = 52.dp)
                        .pressable(scaleDown = false, role = Role.RadioButton) { onSelect(o.value); onDismiss() }
                        .semantics { this.selected = sel }
                        .padding(horizontal = 16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                ) {
                    Column(Modifier.weight(1f)) {
                        Text(o.label, style = Type.bodyMedium.copy(color = if (sel) TT.AccentText else TT.Text))
                        if (o.detail != null) Text(o.detail, style = Type.label)
                    }
                    if (sel) Icon(Icons.Rounded.Check, null, tint = TT.AccentText, modifier = Modifier.size(20.dp))
                }
            }
        }
    }
}

/** Guarda los límites del elemento en la raíz (para anclar menús). */
fun Modifier.anchorBounds(onBounds: (Rect) -> Unit): Modifier = this.onGloballyPositioned { onBounds(it.boundsInRoot()) }

/* ═════════════════════════ Desvanecido bajo la cabecera ═════════════════════════ */

/**
 * Desvanece suavemente el contenido que sale por arriba en los primeros [zone] dp bajo la cabecera
 * fija. El título y los controles de la cabecera quedan fuera y siguen nítidos; el texto que aún se
 * lee (por debajo de la zona) no se toca. Solo se aplica cuando hay contenido desplazado.
 */
@Composable
fun Modifier.fadeTop(active: Boolean, zone: Dp = Dim.fadeZone): Modifier {
    val a by animateFloatAsState(if (active) 1f else 0f, ttTween(Motion.tab), label = "fade")
    return this
        .graphicsLayer { compositingStrategy = CompositingStrategy.Offscreen }
        .drawWithContent {
            drawContent()
            if (a > 0f) {
                val h = zone.toPx()
                drawRect(
                    Brush.verticalGradient(0f to Color.Black.copy(alpha = 1f - a), 1f to Color.Black, startY = 0f, endY = h),
                    size = androidx.compose.ui.geometry.Size(size.width, h), blendMode = BlendMode.DstIn,
                )
            }
        }
}
