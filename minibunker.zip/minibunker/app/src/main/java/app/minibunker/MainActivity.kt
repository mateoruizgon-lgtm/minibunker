package app.minibunker

import android.app.Application
import android.content.res.Configuration
import android.graphics.Color
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.SystemBarStyle
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import app.minibunker.academic.AcademicRepo
import app.minibunker.link.Links
import app.minibunker.study.StudyController
import app.minibunker.study.StudyEngine
import app.minibunker.ui.AppRoot
import app.minibunker.ui.theme.MinibunkerTheme
import app.minibunker.ui.theme.ThemeState
import app.minibunker.ui.theme.Themes
import app.thinktwice.data.Store
import app.thinktwice.system.GuardService
import app.thinktwice.system.Notifier
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.flow.distinctUntilChangedBy
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.distinctUntilChanged
import kotlinx.coroutines.launch

class MinibunkerApp : Application() {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)

    override fun onCreate() {
        super.onCreate()
        Store.init(this)
        Notifier.createChannels(this)
        AcademicRepo.init(this)
        StudyController.init(this)
        Themes.refresh(this, AcademicRepo.state.value.prefs)

        // thinktwice: cada cambio de reglas recalcula notificaciones y la decisión de la app en primer plano.
        scope.launch {
            Store.state.distinctUntilChangedBy { Triple(it.sessions, it.routines, it.routineSkips) to (it.pausedApps to it.settings.sessionNotifications) }
                .collect { Notifier.refresh(this@MinibunkerApp); GuardService.rulesChanged() }
        }
        scope.launch {
            Store.state.distinctUntilChangedBy { it.challenges to it.settings.reminderHour }
                .collect { Notifier.scheduleReminder(this@MinibunkerApp) }
        }
        // Protección vinculada: al mover, editar o borrar una clase o un evento (aquí o desde otro
        // dispositivo) su regla se actualiza sin duplicarse.
        scope.launch {
            AcademicRepo.state.map { it.academic }.distinctUntilChanged { a, b -> a.raw == b.raw }.collect { a ->
                val cur = Store.state.value.routines
                val next = Links.reconcile(a, cur)
                if (next != cur) Store.update { it.copy(routines = Links.reconcile(a, it.routines)) }
            }
        }
        // Apariencia sincronizada con la cuenta.
        scope.launch {
            AcademicRepo.state.map { it.prefs }.distinctUntilChanged { a, b -> a.mode == b.mode && a.accent == b.accent }
                .collect { Themes.refresh(this@MinibunkerApp, it) }
        }
        // Salida de emergencia usada sobre la protección del estudio: el estudio sigue sin volver a proteger.
        scope.launch {
            Store.state.distinctUntilChangedBy { s -> s.sessions.filter { it.isStudy }.map { it.id to it.endedEarlyAtMs } }.collect { s ->
                val r = StudyController.run.value ?: return@collect
                if (!r.protectionStopped && StudyEngine.emergencyUsed(r, s.sessions)) StudyController.refresh()
            }
        }
        // Estado del temporizador tras cierre o reinicio (marcas de tiempo).
        StudyController.restore(this)
    }
}

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        applyBars(ThemeState.palette.dark)
        super.onCreate(savedInstanceState)
        setContent {
            val tt by Store.state.collectAsState()
            val ac by AcademicRepo.state.collectAsState()
            val dark = ThemeState.palette.dark
            LaunchedEffect(dark) { applyBars(dark) }
            MinibunkerTheme(tt.settings.reduceMotion) { AppRoot(tt, ac) }
        }
    }

    /** Iconos de las barras del sistema legibles en modo claro y oscuro; contenido de borde a borde. */
    private fun applyBars(dark: Boolean) {
        val style = if (dark) SystemBarStyle.dark(Color.TRANSPARENT) else SystemBarStyle.light(Color.TRANSPARENT, Color.TRANSPARENT)
        enableEdgeToEdge(statusBarStyle = style, navigationBarStyle = style)
    }

    override fun onConfigurationChanged(newConfig: Configuration) {
        super.onConfigurationChanged(newConfig)
        // Modo automático: sigue al sistema sin recrear la actividad.
        Themes.refresh(this, AcademicRepo.state.value.prefs)
    }
}
