package app.minibunker.ui.screens

import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.study.*
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.FrostSheet
import app.minibunker.ui.frost.MenuOption
import app.minibunker.ui.theme.*
import app.minibunker.ui.tt.appsSummary
import app.thinktwice.core.AppState
import app.thinktwice.system.Perms
import java.time.LocalDate

/**
 * Hoja única «Empezar a estudiar» (desde Hoy, un tema del plan o un evento de estudio).
 * Si vienes de un tema, la asignatura y el tema llegan ya seleccionados.
 */
@Composable
fun StartStudySheet(tt: AppState, ac: AcadState, req: StudyRequest, returnFocus: androidx.compose.ui.focus.FocusRequester? = null, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val a = ac.academic
    val run by StudyController.run.collectAsState()
    val prefs by StudyController.prefs.collectAsState()
    var subject by remember { mutableStateOf(req.subject) }
    var planId by remember { mutableStateOf(req.planId) }
    var topic by remember { mutableStateOf(req.topic) }
    var focus by remember { mutableStateOf(prefs.focus) }
    var short by remember { mutableStateOf(prefs.short) }
    var protect by remember { mutableStateOf(false) }
    var apps by remember { mutableStateOf(tt.templates.firstOrNull { it.id == "t_study" }?.packages?.takeIf { it.isNotEmpty() }
        ?: tt.templates.firstOrNull { it.packages.isNotEmpty() }?.packages ?: tt.pausedApps) }
    val tick = LocalResumeTick.current
    val guardOn = remember(tick) { Perms.isGuardEnabled(ctx) }

    fun start(withProtection: Boolean) {
        StudyController.start(StudyRequest(subject, planId, topic), prefs.copy(focus = focus, short = short), withProtection && apps.isNotEmpty(), apps)
        onDismiss()
        nav.push(Dest.StudySession, Tab.ESTUDIO)
    }

    val r = run
    if (r != null) {
        // Ya hay un periodo de estudio en curso: volver a él o terminarlo y empezar otro.
        FrostSheet(onDismiss, "Ya estás estudiando", primary = "Volver a la sesión", onPrimary = { onDismiss(); nav.push(Dest.StudySession, Tab.ESTUDIO) },
            footer = { PillButton("Terminar y empezar otro", { StudyController.finish(showSummary = false) }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary) }) {
            Text("${r.subjectLabel}${r.topic?.let { " · $it" } ?: ""}: ${StudyEngine.indicator(r, System.currentTimeMillis(), guardOn)}", style = Type.body.copy(color = TT.TextSecondary))
        }
        return
    }

    val missingPerm = protect && !guardOn
    FrostSheet(
        onDismiss, "Empezar a estudiar", returnFocus = returnFocus,
        primary = if (missingPerm) null else "Empezar", primaryEnabled = !protect || apps.isNotEmpty(), onPrimary = { start(protect) },
        footer = {
            if (missingPerm) {
            Spacer(Modifier.height(12.dp))
            Banner(BannerKind.Error, "Falta el permiso de protección", "Sin el servicio de minibunker en Accesibilidad no se pueden pausar las apps.")
            Spacer(Modifier.height(10.dp))
            PillButton("Estudiar sin protección", { start(false) }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            PillButton("Revisar permiso", { Perms.open(ctx, Perms.accessibilityIntent()) }, Modifier.fillMaxWidth().navigationBarsPadding().padding(bottom = 12.dp), tone = ButtonTone.Secondary)
            }
        },
    ) {
        val subjects = Cal.allSubjects(a)
        MenuField("Asignatura", listOf(MenuOption("", "General")) + (subjects + listOfNotNull(subject.takeIf { it.isNotEmpty() && it !in subjects })).map { MenuOption(it, it) }, subject) {
            if (it != subject) { subject = it; planId = null; topic = null }
        }
        val topics = a.plans.filter { it.subject == subject && (!it.done || it.id == planId) }.sortedBy { it.date }
        if (topics.isNotEmpty() || topic != null) {
            Spacer(Modifier.height(14.dp))
            FieldLabel("Tema")
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                Chip("Sin tema", topic == null, { topic = null; planId = null })
                topic?.takeIf { topics.none { p -> p.id == planId } }?.let { t -> Chip(t, true, {}) }
                topics.forEach { p -> Chip(p.title, p.id == planId, { planId = p.id; topic = p.title }) }
            }
        }
        Spacer(Modifier.height(16.dp))
        FieldLabel("Duración")
        Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
            (listOf(25, 45, 50) + listOf(focus)).distinct().sorted().forEach { m -> Chip("$m min", focus == m, { focus = m }) }
        }
        Spacer(Modifier.height(8.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(12.dp)) {
            Stepper("Concentración", focus, 1, 180, Modifier.weight(1f), step = 5) { focus = it }
            Stepper("Descanso", short, 1, 60, Modifier.weight(1f)) { short = it }
        }
        Text("Descanso largo de ${prefs.long} min tras cuatro bloques.", style = Type.label, modifier = Modifier.padding(top = 6.dp))
        Spacer(Modifier.height(18.dp))
        ProtectionChooser(tt, "Proteger este bloque", "Pausa las apps elegidas mientras te concentras; en los descansos quedan libres",
            protect, { protect = it }, apps, { apps = it })
    }
}

/** Temporizador con sus controles (en la pestaña Estudio y en la pantalla de la sesión). */
@Composable
fun TimerPanel(r: StudyRun, compact: Boolean, onOpen: (() -> Unit)? = null) {
    val ctx = LocalContext.current
    val now by rememberNow(true)
    val tick = LocalResumeTick.current
    val op = remember(tick) { Perms.isGuardEnabled(ctx) }
    // Si el bloque termina con la app abierta, se cierra la fase (sin esperar a la alarma).
    LaunchedEffect(now >= r.endAt && r.running) { if (r.running && now >= r.endAt) StudyController.tick() }
    val left = r.remainingMs(now)
    val total = r.totalMs().coerceAtLeast(1)
    val frac by animateFloatAsState((1f - left.toFloat() / total).coerceIn(0f, 1f), ttTween(if (r.running) 1000 else Motion.value), label = "timer")
    val s = (left + 999) / 1000
    val accent = TT.Accent; val track = TT.Control
    TTCard(onClick = onOpen) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Column(Modifier.weight(1f)) {
                Text(r.phase.label + if (r.phase == Phase.FOCUS) " · bloque ${r.cycle + 1}" else "", style = Type.label)
                Text(r.subjectLabel + (r.topic?.let { " · $it" } ?: ""), style = Type.cardTitle, maxLines = 2)
            }
            if (compact && onOpen != null) SmallPill("Abrir", onOpen, Icons.Rounded.OpenInFull)
        }
        Spacer(Modifier.height(10.dp))
        Box(Modifier.fillMaxWidth().height(if (compact) 150.dp else 250.dp), contentAlignment = Alignment.Center) {
            Canvas(Modifier.size(if (compact) 150.dp else 250.dp)) {
                val sw = (if (compact) 8 else 12).dp.toPx()
                val tl = Offset(sw / 2, sw / 2); val sz = Size(size.width - sw, size.height - sw)
                drawArc(track, 0f, 360f, false, tl, sz, style = Stroke(sw))
                drawArc(accent, -90f, 360f * frac, false, tl, sz, style = Stroke(sw, cap = StrokeCap.Round))
            }
            // Cifras de ancho estable (números tabulares); se actualizan cada segundo.
            Text("%d:%02d".format(s / 60, s % 60), style = if (compact) Type.cardFigure.copy(fontSize = Type.screenTitle.fontSize) else Type.timer,
                modifier = Modifier.semantics { contentDescription = "Quedan ${s / 60} minutos y ${s % 60} segundos" })
        }
        Spacer(Modifier.height(10.dp))
        Text(StudyEngine.indicator(r, now, op), style = Type.secondary.copy(color = TT.Text), textAlign = TextAlign.Center,
            modifier = Modifier.fillMaxWidth().semantics { liveRegion = LiveRegionMode.Polite })
        Spacer(Modifier.height(14.dp))
        Row(horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
            PillButton(if (r.running) "Pausar" else if (r.leftMs < r.totalMs()) "Continuar" else if (r.phase == Phase.FOCUS) "Empezar bloque" else "Empezar descanso",
                { StudyController.toggle() }, Modifier.weight(1f), icon = if (r.running) Icons.Rounded.Pause else Icons.Rounded.PlayArrow)
            PillButton("Terminar", { StudyController.finish() }, Modifier.weight(1f), tone = ButtonTone.Secondary, icon = Icons.Rounded.Stop)
        }
    }
}

/** Pantalla de la sesión en curso («Volver a la sesión»). */
@Composable
fun StudySessionScreen(tt: AppState, ac: AcadState) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val run by StudyController.run.collectAsState()
    val r = run
    var durations by remember { mutableStateOf(false) }
    // Al terminar, la sesión se cierra y se muestra el resumen.
    LaunchedEffect(r == null) { if (r == null) nav.pop() }
    DetailScaffold("Sesión de estudio", actions = { CircleIconButton(Icons.Rounded.Timer, "Duraciones", { durations = true }) }) {
        if (r == null) return@DetailScaffold
        item {
            Segmented(Phase.entries.map { it.label }, r.phase.ordinal, { StudyController.setPhase(Phase.entries[it]) }, Modifier.fillMaxWidth())
            Spacer(Modifier.height(14.dp))
            TimerPanel(r, compact = false)
            Spacer(Modifier.height(10.dp))
            SmallPill("Reiniciar fase", { StudyController.reset() }, Icons.Rounded.Refresh)
        }
        item {
            SectionHeader("Protección")
            val tick = LocalResumeTick.current
            val op = remember(tick) { Perms.isGuardEnabled(ctx) }
            when {
                !r.protect || r.packages.isEmpty() -> Text("Este bloque no está protegido. Puedes activarlo al empezar el próximo.", style = Type.secondary)
                r.protectionStopped -> Banner(BannerKind.Info, "Protección terminada", "Usaste la salida de emergencia. Puedes seguir estudiando; las apps quedan libres en este periodo.")
                !op -> Banner(BannerKind.Error, "Protección no operativa", "Activa el servicio de minibunker en Accesibilidad para que las apps se pausen.", "Revisar permiso") { Perms.open(ctx, Perms.accessibilityIntent()) }
                else -> TTCard {
                    Text(if (r.protecting) "Activa hasta el fin del bloque" else "Suspendida (pausa o descanso)", style = Type.cardTitle)
                    Text(appsSummary(r.packages.size) + " · al reanudar se aplica por el tiempo que queda", style = Type.secondary)
                    Spacer(Modifier.height(10.dp)); AppStack(r.packages, 8)
                }
            }
        }
        item {
            SectionHeader("Hoy")
            val a = ac.academic
            Text("${Cal.fmtDur(Cal.minutesOn(a, Cal.iso(LocalDate.now())))} estudiados hoy · esta sesión: ${Cal.fmtDur((r.effectiveFocusMs(System.currentTimeMillis()) / 60_000).toInt())}", style = Type.secondary)
        }
    }
    if (durations) DurationsSheet { durations = false }
}

/** Resumen al terminar: tema trabajado, tiempo efectivo guardado y decisiones de pausa registradas. */
@Composable
fun StudySummarySheet(s: StudySummary, onDismiss: () -> Unit) {
    val nav = LocalNav.current
    val ac by AcademicRepo.state.collectAsState()
    val plan = s.planId?.let { id -> ac.academic.plans.firstOrNull { it.id == id } }
    FrostSheet(onDismiss, "Sesión terminada", primary = "Cerrar", onPrimary = onDismiss) {
        Text(s.subject + (s.topic?.let { " · $it" } ?: ""), style = Type.cardTitle)
        Spacer(Modifier.height(6.dp))
        Text(if (s.saved) Cal.fmtDur(s.minutes) else "0 min", style = Type.hero)
        Text(if (s.saved) "de concentración efectiva guardados en ${s.subject}" else "Menos de un minuto: no se guarda", style = Type.secondary)
        Spacer(Modifier.height(16.dp))
        if (s.protectedApps > 0 || s.pausesShown + s.continued + s.exited + s.blockedAttempts > 0) {
            ListGroup {
                if (s.protectedApps > 0) { ListRow("Apps protegidas", null, leading = { RowIcon(Icons.Rounded.Shield) }, value = "${s.protectedApps}"); RowDivider() }
                ListRow("Intentos durante el bloqueo", null, leading = { RowIcon(Icons.Rounded.Lock) }, value = "${s.blockedAttempts}")
                RowDivider()
                ListRow("Pausas mostradas", null, leading = { RowIcon(Icons.Rounded.HourglassTop) }, value = "${s.pausesShown}")
                RowDivider()
                ListRow("Decidiste no continuar", null, leading = { RowIcon(Icons.Rounded.DoNotTouch, tint = TT.Positive) }, value = "${s.exited}")
                RowDivider()
                ListRow("Continuaste", null, leading = { RowIcon(Icons.Rounded.Login) }, value = "${s.continued}")
            }
            if (s.emergencyUsed) Text("Usaste la salida de emergencia de la protección.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
            Text("Solo se muestran decisiones registradas mientras estudiabas; el tiempo bloqueado no se cuenta como tiempo estudiado.", style = Type.label, modifier = Modifier.padding(top = 8.dp))
        } else Text("No se registró ninguna pausa ni intento de abrir apps durante la sesión.", style = Type.secondary)
        if (plan != null) {
            Spacer(Modifier.height(16.dp))
            if (plan.done) Banner(BannerKind.Ok, "Tema completado", plan.title)
            else PillButton("Marcar «${plan.title}» como completado", { StudyController.completeTopic(plan.id); nav.show("¡Tema completado!") },
                Modifier.fillMaxWidth(), tone = ButtonTone.Secondary, icon = Icons.Rounded.Check)
        }
    }
}
