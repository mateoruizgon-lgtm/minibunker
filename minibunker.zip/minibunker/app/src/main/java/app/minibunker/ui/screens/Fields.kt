package app.minibunker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.ui.LocalNav
import app.minibunker.ui.components.*
import app.minibunker.ui.frost.*
import app.minibunker.ui.theme.*
import app.minibunker.ui.tt.AppPickerSheet
import app.minibunker.ui.tt.TimeDialog
import app.minibunker.ui.tt.appsSummary
import app.thinktwice.core.AppState
import app.thinktwice.system.Perms
import java.time.Instant
import java.time.LocalDate
import java.time.ZoneOffset

/** Etiqueta de campo, siempre visible (no solo marcador). */
@Composable
fun FieldLabel(text: String) { Text(text, style = Type.label.copy(color = TT.Text)); Spacer(Modifier.height(6.dp)) }

/** Botón con aspecto de campo que muestra un valor y abre un selector. */
@Composable
fun ValueField(label: String, value: String, modifier: Modifier = Modifier, placeholder: Boolean = false, icon: androidx.compose.ui.graphics.vector.ImageVector? = null,
               onBounds: ((Rect) -> Unit)? = null, onClick: () -> Unit) {
    Column(modifier) {
        FieldLabel(label)
        Row(
            Modifier.fillMaxWidth().heightIn(min = 54.dp).clip(RoundedCornerShape(16.dp)).background(TT.Control)
                .then(if (onBounds != null) Modifier.anchorBounds(onBounds) else Modifier)
                .pressable(scaleDown = false) { onClick() }
                .semantics(mergeDescendants = true) { contentDescription = "$label: $value" }
                .padding(horizontal = 16.dp),
            verticalAlignment = Alignment.CenterVertically,
        ) {
            Text(value, style = Type.body.copy(color = if (placeholder) TT.TextSecondary else TT.Text), modifier = Modifier.weight(1f), maxLines = 1)
            Icon(icon ?: Icons.Rounded.ExpandMore, null, tint = TT.TextSecondary, modifier = Modifier.size(20.dp))
        }
    }
}

/** Campo con lista corta: abre un menú anclado al propio campo. */
@Composable
fun <T> MenuField(label: String, options: List<MenuOption<T>>, selected: T, modifier: Modifier = Modifier, onSelect: (T) -> Unit) {
    var bounds by remember { mutableStateOf(Rect.Zero) }
    var open by remember { mutableStateOf(false) }
    ValueField(label, options.firstOrNull { it.value == selected }?.label ?: "—", modifier, onBounds = { bounds = it }) { open = true }
    if (open) FrostMenu(bounds, options, selected, { open = false }, onSelect)
}

/** Fecha "AAAA-MM-DD" con selector de calendario en la hoja translúcida. */
@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DateField(label: String, value: String, modifier: Modifier = Modifier, allowEmpty: Boolean = false, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    val d = Cal.parse(value)
    ValueField(label, d?.let { Cal.cap(Cal.DIAS[Cal.jsDay(it)]).take(3) + " ${it.dayOfMonth} ${Cal.shortMonth(it)} ${it.year}" } ?: "Sin fecha", modifier,
        placeholder = d == null, icon = Icons.Rounded.CalendarToday) { open = true }
    if (open) {
        val st = rememberDatePickerState(initialSelectedDateMillis = (d ?: LocalDate.now()).atStartOfDay().toInstant(ZoneOffset.UTC).toEpochMilli())
        FrostSheet({ open = false }, label, primary = "Aceptar", onPrimary = {
            st.selectedDateMillis?.let { onChange(Instant.ofEpochMilli(it).atZone(ZoneOffset.UTC).toLocalDate().toString()) }
            open = false
        }, footer = {
            if (allowEmpty && d != null) { Spacer(Modifier.height(8.dp)); PillButton("Quitar fecha", { onChange(""); open = false }, Modifier.fillMaxWidth(), tone = ButtonTone.Secondary) }
        }) {
            DatePicker(st, showModeToggle = false, title = null, headline = null,
                colors = DatePickerDefaults.colors(
                    containerColor = Color.Transparent, selectedDayContainerColor = TT.Accent, selectedDayContentColor = TT.OnAccent,
                    todayDateBorderColor = TT.Accent, todayContentColor = TT.AccentText, dayContentColor = TT.Text, weekdayContentColor = TT.TextSecondary,
                    navigationContentColor = TT.Text, yearContentColor = TT.Text, selectedYearContainerColor = TT.Accent, selectedYearContentColor = TT.OnAccent,
                    subheadContentColor = TT.TextSecondary, currentYearContentColor = TT.AccentText,
                ))
        }
    }
}

/** Hora "HH:mm" (vacía = sin hora) con selector en la hoja translúcida. */
@Composable
fun TimeField(label: String, value: String, modifier: Modifier = Modifier, allowEmpty: Boolean = true, onChange: (String) -> Unit) {
    var open by remember { mutableStateOf(false) }
    ValueField(label, value.ifEmpty { "Sin hora" }, modifier, placeholder = value.isEmpty(), icon = Icons.Rounded.Schedule) { open = true }
    if (open) TimeDialog(if (value.isEmpty()) 9 * 60 else Cal.toMin(value), { open = false }, label) { m -> onChange(Cal.fmMin(m)); open = false }
    if (allowEmpty && value.isNotEmpty()) Text("Quitar hora", style = Type.label.copy(color = TT.AccentText),
        modifier = Modifier.padding(top = 4.dp).clip(CircleShape).pressable { onChange("") }.padding(horizontal = 4.dp, vertical = 10.dp))
}

/** Hoy / Mañana / Otro día (como MIBUNKER). */
@Composable
fun DayChooser(value: String, onChange: (String) -> Unit) {
    val today = Cal.iso(LocalDate.now()); val tomorrow = Cal.addD(today, 1)
    var other by remember { mutableStateOf(value != today && value != tomorrow) }
    FieldLabel("Día")
    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        Chip("Hoy", !other && value == today, { other = false; onChange(today) })
        Chip("Mañana", !other && value == tomorrow, { other = false; onChange(tomorrow) })
        Chip("Otro día", other, { other = true })
    }
    if (other) { Spacer(Modifier.height(10.dp)); DateField("Fecha", value) { onChange(it) } }
}

/** Paleta de colores de MIBUNKER (con opción «sin color»). */
@Composable
fun ColorChooser(value: String, allowNone: Boolean = true, onChange: (String) -> Unit) {
    FieldLabel("Color")
    Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        if (allowNone) ColorSwatch(null, value.isEmpty()) { onChange("") }
        PALETTE.forEach { c -> ColorSwatch(c, value == c) { onChange(c) } }
    }
}

@Composable
private fun ColorSwatch(hex: String?, selected: Boolean, onClick: () -> Unit) {
    Box(
        Modifier.size(Dim.touch).pressable(role = Role.RadioButton) { onClick() }
            .semantics { contentDescription = hex?.let { "Color $it" } ?: "Sin color"; this.selected = selected },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(34.dp).clip(CircleShape).background(hex?.let { hexColor(it) } ?: TT.Control)
                .then(if (selected) Modifier.border(3.dp, TT.Text, CircleShape) else Modifier),
            contentAlignment = Alignment.Center,
        ) { if (hex == null) Icon(Icons.Rounded.Block, null, tint = TT.TextSecondary, modifier = Modifier.size(18.dp)) }
    }
}

/**
 * Opción voluntaria «Vincular protección» (horario y eventos) o «Proteger este bloque» (estudio):
 * interruptor, apps elegidas en la propia hoja o recuperadas de una plantilla de thinktwice,
 * y aviso real si falta el permiso.
 */
@Composable
fun ProtectionChooser(
    tt: AppState, title: String, subtitle: String, enabled: Boolean, onEnabled: (Boolean) -> Unit,
    apps: Set<String>, onApps: (Set<String>) -> Unit, showTemplates: Boolean = true, unavailableReason: String? = null,
) {
    val ctx = LocalContext.current
    val tick = app.minibunker.ui.LocalResumeTick.current
    val guardOn = remember(tick) { Perms.isGuardEnabled(ctx) }
    var picking by remember { mutableStateOf(false) }
    ListGroup {
        ListRow(title, unavailableReason ?: subtitle, leading = { RowIcon(Icons.Rounded.Shield, tint = if (enabled) TT.AccentText else TT.Text) },
            trailingSwitch = if (unavailableReason == null) enabled else null, onSwitch = onEnabled, switchLabel = title)
        if (enabled && unavailableReason == null) {
            RowDivider()
            ListRow("Apps", if (apps.isEmpty()) "Elige al menos una" else appsSummary(apps.size), leading = { RowIcon(Icons.Rounded.Apps) },
                chevron = true, onClick = { picking = true })
        }
    }
    if (enabled && unavailableReason == null) {
        if (apps.isNotEmpty()) { Spacer(Modifier.height(10.dp)); AppStack(apps, 8) }
        if (showTemplates && tt.templates.any { it.packages.isNotEmpty() }) {
            Spacer(Modifier.height(12.dp))
            Text("Recuperar de una plantilla de thinktwice", style = Type.label)
            Spacer(Modifier.height(6.dp))
            Row(Modifier.horizontalScroll(rememberScrollState()), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                tt.templates.filter { it.packages.isNotEmpty() }.forEach { t -> Chip("${t.name} · ${t.packages.size}", apps == t.packages, { onApps(t.packages) }) }
            }
        }
        if (!guardOn) {
            Spacer(Modifier.height(12.dp))
            Banner(BannerKind.Error, "Falta el permiso de protección",
                "Sin el servicio de minibunker en Accesibilidad la regla se guarda, pero las apps no se pausarán.",
                "Revisar permiso") { Perms.open(ctx, Perms.accessibilityIntent()) }
        }
    }
    if (picking) AppPickerSheet("Apps a proteger", apps, { picking = false }) { onApps(it); picking = false }
}
