package app.minibunker.study

import app.minibunker.json.*
import app.thinktwice.core.BlockSession

enum class Phase(val label: String) { FOCUS("Concentración"), SHORT("Descanso corto"), LONG("Descanso largo") }

/** Duraciones del Pomodoro (MIBUNKER: 25 / 5 / 15, descanso largo tras cuatro bloques). */
data class PomoPrefs(val focus: Int = 25, val short: Int = 5, val long: Int = 15, val subject: String = "") {
    fun minutes(p: Phase) = when (p) { Phase.FOCUS -> focus; Phase.SHORT -> short; Phase.LONG -> long }
    fun toJson(): JObj = linkedMapOf("focus" to focus, "short" to short, "long" to long, "subject" to subject)
    companion object {
        fun from(o: JObj?) = o?.let { PomoPrefs(it.int("focus", 25).coerceIn(1, 180), it.int("short", 5).coerceIn(1, 180), it.int("long", 15).coerceIn(1, 180), it.str("subject")) }
    }
}

/**
 * Un periodo de estudio en curso (puede abarcar varios bloques y descansos).
 * Todo se guarda como marcas de tiempo: el tiempo restante se calcula, no se cuenta en memoria.
 */
data class StudyRun(
    /** Identificador del periodo y de su registro de sesión: se actualiza, nunca se duplica. */
    val id: String,
    val subject: String,
    val planId: String? = null,
    val topic: String? = null,
    val prefs: PomoPrefs,
    val phase: Phase = Phase.FOCUS,
    /** Bloques de concentración completos. */
    val cycle: Int = 0,
    val running: Boolean = false,
    /** Fin previsto de la fase en curso (si [running]). */
    val endAt: Long = 0,
    /** Tiempo restante de la fase (si está en pausa). */
    val leftMs: Long = prefs.minutes(phase) * 60_000L,
    /** Concentración efectiva ya acumulada (segmentos terminados). */
    val focusMs: Long = 0,
    /** Inicio del segmento de concentración en marcha. */
    val segStart: Long? = null,
    val startedAt: Long,
    val protect: Boolean = false,
    val packages: Set<String> = emptySet(),
    /** Se usó la salida de emergencia: el estudio sigue, pero sin volver a proteger. */
    val protectionStopped: Boolean = false,
) {
    val subjectLabel get() = subject.ifEmpty { "General" }
    val link get() = "study:$id"
    fun totalMs() = prefs.minutes(phase) * 60_000L
    fun remainingMs(now: Long) = if (running) (endAt - now).coerceAtLeast(0) else leftMs
    /** Concentración efectiva hasta [now], incluido el segmento en marcha. */
    fun effectiveFocusMs(now: Long) = focusMs + (if (running && phase == Phase.FOCUS && segStart != null) (minOf(now, endAt) - segStart).coerceAtLeast(0) else 0)
    val protectionWanted get() = protect && packages.isNotEmpty() && !protectionStopped
    val protecting get() = protectionWanted && running && phase == Phase.FOCUS

    fun toJson(): JObj = linkedMapOf(
        "id" to id, "subject" to subject, "planId" to planId, "topic" to topic, "prefs" to prefs.toJson(), "phase" to phase.name,
        "cycle" to cycle, "running" to running, "endAt" to endAt, "leftMs" to leftMs, "focusMs" to focusMs, "segStart" to segStart,
        "startedAt" to startedAt, "protect" to protect, "packages" to packages.toList(), "protectionStopped" to protectionStopped,
    )
    companion object {
        fun from(o: JObj?): StudyRun? {
            if (o == null || o.str("id").isEmpty()) return null
            val prefs = PomoPrefs.from(o.objOrNull("prefs")) ?: PomoPrefs()
            return StudyRun(o.str("id"), o.str("subject"), o.strOrNull("planId"), o.strOrNull("topic"), prefs,
                runCatching { Phase.valueOf(o.str("phase")) }.getOrDefault(Phase.FOCUS), o.int("cycle"), o.bool("running"),
                o.long("endAt"), o.long("leftMs"), o.long("focusMs"), o.num("segStart")?.toLong(), o.long("startedAt"),
                o.bool("protect"), o.list("packages").mapNotNull { it as? String }.toSet(), o.bool("protectionStopped"))
        }
    }
}

/** Lo que hay que registrar como sesión de estudio (mismo id siempre → sin duplicados). */
data class SessionRecord(val id: String, val subject: String, val startedAt: Long, val mins: Int)

/**
 * Transiciones del temporizador (lógica pura). Cada una devuelve el nuevo estado; el controlador
 * se encarga de guardar, registrar la sesión y aplicar la protección deseada.
 */
object StudyEngine {

    fun start(id: String, subject: String, planId: String?, topic: String?, prefs: PomoPrefs, protect: Boolean, packages: Set<String>, now: Long) =
        StudyRun(id, subject, planId, topic, prefs, Phase.FOCUS, 0, true, now + prefs.focus * 60_000L, prefs.focus * 60_000L, 0, now, now, protect, packages)

    fun pause(r: StudyRun, now: Long): StudyRun {
        if (!r.running) return r
        val t = tick(r, now); if (!t.running) return t
        return t.copy(running = false, leftMs = (t.endAt - now).coerceAtLeast(0), focusMs = t.effectiveFocusMs(now), segStart = null)
    }

    /** Reanudar o empezar la fase actual (también el descanso). */
    fun resume(r: StudyRun, now: Long): StudyRun {
        if (r.running) return r
        val left = if (r.leftMs <= 0) r.totalMs() else r.leftMs
        return r.copy(running = true, endAt = now + left, leftMs = left, segStart = if (r.phase == Phase.FOCUS) now else null)
    }

    /** Si la fase en marcha ya terminó, la cierra: tras concentración toca descanso (largo cada 4). */
    fun tick(r: StudyRun, now: Long): StudyRun {
        if (!r.running || now < r.endAt) return r
        return if (r.phase == Phase.FOCUS) {
            val focus = r.focusMs + (r.endAt - (r.segStart ?: r.endAt)).coerceAtLeast(0)
            val cycle = r.cycle + 1
            val next = if (cycle % 4 == 0) Phase.LONG else Phase.SHORT
            r.copy(phase = next, cycle = cycle, running = false, focusMs = focus, segStart = null, leftMs = r.prefs.minutes(next) * 60_000L)
        } else r.copy(phase = Phase.FOCUS, running = false, segStart = null, leftMs = r.prefs.focus * 60_000L)
    }

    /** Elegir fase a mano (sin contar lo que llevaba la fase en marcha si era concentración). */
    fun setPhase(r: StudyRun, p: Phase, now: Long): StudyRun {
        val t = pause(r, now)
        return t.copy(phase = p, running = false, leftMs = t.prefs.minutes(p) * 60_000L)
    }

    /** Reiniciar la fase actual: el segmento en marcha no se cuenta (como «Reiniciar» en MIBUNKER). */
    fun reset(r: StudyRun): StudyRun = r.copy(running = false, segStart = null, leftMs = r.totalMs())

    fun changeDurations(r: StudyRun, prefs: PomoPrefs): StudyRun =
        if (r.running) r.copy(prefs = prefs) else r.copy(prefs = prefs, leftMs = if (r.leftMs == r.totalMs()) prefs.minutes(r.phase) * 60_000L else r.leftMs)

    /** Termina el periodo: devuelve el estado final con la concentración efectiva acumulada. */
    fun finish(r: StudyRun, now: Long): StudyRun {
        val t = tick(r, now)
        return t.copy(running = false, focusMs = t.effectiveFocusMs(now), segStart = null)
    }

    /** Registro a guardar: solo si hay al menos un minuto efectivo (igual que MIBUNKER). */
    fun record(r: StudyRun): SessionRecord? {
        val mins = Math.round(r.focusMs / 60_000.0).toInt()
        if (r.focusMs < 60_000L || mins < 1) return null
        return SessionRecord(r.id, r.subjectLabel, r.startedAt, mins)
    }

    /**
     * Estado deseado de la protección vinculada, aplicado sobre las sesiones de bloqueo de thinktwice.
     * Idempotente: puede llamarse tras cada cambio, al volver a la app o tras reiniciar el móvil.
     *  - Concentración en marcha → una sola sesión activa hasta el fin del bloque.
     *  - Pausa, descanso, fin o salida de emergencia → se suspende solo la sesión de este estudio.
     * Las rutinas y otros bloqueos no se tocan: si también están vigentes, siguen hasta su propio fin.
     */
    fun reconcileProtection(r: StudyRun?, sessions: List<BlockSession>, now: Long, newId: () -> String): List<BlockSession> {
        val link = r?.link
        val mine = if (link == null) emptyList() else sessions.filter { it.link == link }
        val others = sessions.filter { it.isStudy && it.link != link && it.isActive(now) }
        var out = sessions
        // Un estudio que ya no existe no debe dejar protecciones activas.
        others.forEach { o -> out = out.map { if (it.id == o.id) it.copy(suspendedAtMs = now) else it } }
        if (r == null) return out
        val active = mine.filter { it.isActive(now) }
        if (r.protecting) {
            val want = r.endAt
            val keep = active.firstOrNull { it.endMs == want && it.packages == r.packages }
            out = out.map { s -> if (s.link == link && s.isActive(now) && s !== keep) s.copy(suspendedAtMs = now) else s }
            if (keep == null) out = out + BlockSession(newId(), "Estudio · ${r.subjectLabel}", r.packages, now, want, link = link)
        } else {
            out = out.map { s -> if (s.link == link && s.isActive(now)) s.copy(suspendedAtMs = now) else s }
        }
        return out
    }

    /** ¿Se usó la salida de emergencia en la protección de este estudio? */
    fun emergencyUsed(r: StudyRun, sessions: List<BlockSession>) = sessions.any { it.link == r.link && it.endedEarlyAtMs != null }

    /** Texto del indicador: «Geografía · 24:59 · 2 apps protegidas». */
    fun indicator(r: StudyRun, now: Long, protectionOperative: Boolean): String {
        val left = r.remainingMs(now)
        val s = (left + 999) / 1000
        val clock = "%d:%02d".format(s / 60, s % 60)
        val head = if (r.phase == Phase.FOCUS) r.subjectLabel else r.phase.label
        val tail = when {
            r.phase != Phase.FOCUS -> "protección en pausa"
            !r.protect || r.packages.isEmpty() -> "sin protección"
            r.protectionStopped -> "protección terminada"
            !r.running -> "en pausa"
            !protectionOperative -> "protección no operativa"
            r.packages.size == 1 -> "1 app protegida"
            else -> "${r.packages.size} apps protegidas"
        }
        return "$head · $clock · $tail"
    }
}
