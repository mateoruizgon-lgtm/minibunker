package app.minibunker.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.rounded.KeyboardArrowRight
import androidx.compose.material.icons.rounded.*
import androidx.compose.material3.Icon
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.focus.FocusRequester
import androidx.compose.ui.focus.focusRequester
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.semantics.*
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import app.minibunker.academic.*
import app.minibunker.study.StudyController
import app.minibunker.study.StudyEngine
import app.minibunker.study.StudyRequest
import app.minibunker.ui.*
import app.minibunker.ui.components.*
import app.minibunker.ui.theme.*
import app.minibunker.ui.tt.UsageResult
import app.minibunker.ui.tt.rememberDayUsage
import app.thinktwice.core.AppState
import app.thinktwice.core.EventType
import app.thinktwice.core.Fmt
import app.thinktwice.system.Perms
import kotlinx.coroutines.delay
import java.time.LocalDate
import java.time.LocalTime

/** Reloj de la interfaz (cada segundo si hay temporizador, cada 30 s si no). */
@Composable
fun rememberNow(fast: Boolean): State<Long> = produceState(System.currentTimeMillis(), fast) {
    while (true) { value = System.currentTimeMillis(); delay(if (fast) 1000 else 30_000) }
}

private sealed interface Hero {
    data object Study : Hero
    data object Empty : Hero
    data class InClass(val c: ClassEntry, val next: ClassEntry?) : Hero
    data class NextClass(val c: ClassEntry) : Hero
    data class NextEvent(val item: Cal.DayItem) : Hero
    data class StudyTask(val p: PlanItem) : Hero
    data class FreeDay(val count: Int, val tomorrow: ClassEntry?) : Hero
}

@Composable
fun HoyScreen(tt: AppState, ac: AcadState) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val a = ac.academic
    val run by StudyController.run.collectAsState()
    val now by rememberNow(run != null)
    val today = LocalDate.now()
    val ts = Cal.iso(today)
    val mm = LocalTime.now().let { it.hour * 60 + it.minute }
    val cls = Cal.classesOn(a, today)
    val items = Cal.dayItems(a, ts)
    val tasks = a.plans.filter { (!it.done && it.date <= ts) || (it.done && it.date == ts) }.sortedBy { it.date }
    val name = (ac.account?.name ?: tt.settings.name).trim().split(" ").firstOrNull().orEmpty()
    val addFocus = remember { FocusRequester() }
    val studyFocus = remember { FocusRequester() }

    val hero: Hero = when {
        run != null -> Hero.Study
        a.isEmpty -> Hero.Empty
        else -> {
            val cur = cls.firstOrNull { Cal.toMin(it.start) <= mm && mm < Cal.toMin(it.end) }
            val nxt = cls.firstOrNull { Cal.toMin(it.start) > mm }
            val nextEv = items.firstOrNull { it.time.isNotEmpty() && Cal.toMin(it.time) >= mm }
            val task = tasks.firstOrNull { !it.done }
            when {
                cur != null -> Hero.InClass(cur, nxt)
                nxt != null && (nextEv == null || Cal.toMin(nxt.start) <= Cal.toMin(nextEv.time)) -> Hero.NextClass(nxt)
                nextEv != null -> Hero.NextEvent(nextEv)
                task != null -> Hero.StudyTask(task)
                else -> Hero.FreeDay(items.size, Cal.classesOn(a, today.plusDays(1)).firstOrNull())
            }
        }
    }

    TabScaffold(
        "Hoy",
        leading = { MbWordmark() },
        actions = {
            SmallPill("Añadir", { nav.lastOpener = addFocus; nav.addDate = ts; nav.add = AddKind.EVENT }, Icons.Rounded.Add, tone = ButtonTone.Light,
                modifier = Modifier.focusRequester(addFocus))
            Avatar(name) { nav.profileOpen = true }
        },
    ) {
        item {
            val hour = LocalTime.now().hour
            Text(Cal.longDate(today), style = Type.secondary, modifier = Modifier.padding(top = 4.dp))
            Text((if (hour < 14) "Buenos días" else if (hour < 21) "Buenas tardes" else "Buenas noches") + if (name.isNotEmpty()) ", $name" else "",
                style = Type.screenTitle, modifier = Modifier.padding(bottom = 16.dp).semantics { heading() })
            HeroCard(hero, a, run, now, mm, studyFocus, tt)
        }
        item {
            Spacer(Modifier.height(Dim.related))
            Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
                StatTile("Estudio hoy", Cal.fmtDur(Cal.minutesOn(a, ts)), Modifier.weight(1f)) { nav.select(Tab.ESTUDIO) }
                StatTile("Media", Cal.fmtN(Cal.overall(a)), Modifier.weight(1f)) { nav.studySection = 2; nav.select(Tab.ESTUDIO) }
                StatTile("Hábitos", if (a.habits.isEmpty()) "—" else "${a.habits.count { it.done(ts) }} de ${a.habits.size}", Modifier.weight(1f)) { nav.notesSection = 1; nav.select(Tab.NOTAS) }
            }
        }
        // ───── Tu día ─────
        item { SectionHeader("Tu día", "Agenda") { nav.agendaDay = ts; nav.agendaSection = 0; nav.select(Tab.AGENDA) } }
        item {
            if (items.isEmpty() && tasks.isEmpty() && a.habits.isEmpty()) {
                EmptyState(Icons.Rounded.WbSunny, "Nada para hoy", "Pulsa «Añadir» para apuntar un evento, un examen, una nota o un hábito.")
            } else ListGroup {
                var first = true
                items.forEach { it ->
                    if (!first) RowDivider(); first = false
                    DayItemRow(it, a)
                }
                tasks.forEach { p ->
                    if (!first) RowDivider(); first = false
                    PlanRow(p, a, showDate = true)
                }
                a.habits.forEach { h ->
                    if (!first) RowDivider(); first = false
                    val on = h.done(ts); val st = Cal.streak(h, ts)
                    CheckRow(h.name, if (st > 0) "Racha de $st ${if (st == 1) "día" else "días"}" else "Márcalo cuando lo hagas", on, hexColor(h.color), "Hábito") {
                        AcademicRepo.edit { Edits.toggleHabit(it, h.id, ts) }
                        if (!on) nav.show("¡Hecho! Racha de ${st + 1} ${if (st + 1 == 1) "día" else "días"}")
                    }
                }
            }
        }
        // ───── Uso del móvil (thinktwice, compacto) ─────
        item {
            SectionHeader("Uso del móvil", "thinktwice") { nav.select(Tab.TT) }
            val usage by rememberDayUsage(today)
            val tick = LocalResumeTick.current
            val hasUsage = remember(tick) { Perms.hasUsageAccess(ctx) }
            val dayStart = today.atStartOfDay(java.time.ZoneId.systemDefault()).toInstant().toEpochMilli()
            val ev = tt.events.filter { it.t >= dayStart }
            TTCard(onClick = { nav.select(Tab.TT) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text("Tiempo de uso hoy", style = Type.label)
                        when (val u = usage) {
                            UsageResult.Loading -> Text("…", style = Type.cardFigure)
                            is UsageResult.Done -> HeroDuration(u.usage?.values?.sum(), style = Type.cardFigure)
                        }
                        Text(if (!hasUsage) "Sin permiso de uso" else if ((usage as? UsageResult.Done)?.usage == null) "Sin medición hoy" else "Medido por Android",
                            style = Type.label.copy(color = if (!hasUsage) TT.Danger else TT.TextSecondary))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("${ev.count { it.type == EventType.PAUSE_SHOWN }} pausas", style = Type.secondary.copy(color = TT.Text))
                        Text("${ev.count { it.type == EventType.EXITED }} no continuaste", style = Type.label)
                        Text("${ev.count { it.type == EventType.BLOCK_SHOWN }} intentos bloqueados", style = Type.label)
                    }
                }
            }
        }
        // ───── Próximo examen y próximos días ─────
        val nx = Cal.nextExams(a, ts).firstOrNull()
        if (nx != null) item {
            SectionHeader("Próximo examen")
            val pl = Cal.planOf(a, nx.id); val pd = pl.count { it.done }
            TTCard(onClick = { nav.studySection = 1; nav.select(Tab.ESTUDIO) }) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    DateBox(nx.date)
                    Spacer(Modifier.width(14.dp))
                    Column(Modifier.weight(1f)) {
                        Text(nx.subject + if (nx.title.isNotEmpty()) " · ${nx.title}" else "", style = Type.cardTitle, maxLines = 2)
                        Text(Cal.rel(nx.date) + if (pl.isNotEmpty()) " · plan $pd de ${pl.size}" else " · sin plan de estudio", style = Type.secondary)
                    }
                    Icon(Icons.AutoMirrored.Rounded.KeyboardArrowRight, null, tint = TT.TextSecondary)
                }
            }
        }
        val upcoming = (1..10).flatMap { j -> val d = Cal.addD(ts, j.toLong()); Cal.dayItems(a, d).map { d to it } }
            .filterNot { (_, it) -> it is Cal.DayItem.Exam && it.g.id == nx?.id }.take(4)
        if (upcoming.isNotEmpty()) item {
            SectionHeader("Próximos días")
            ListGroup {
                upcoming.forEachIndexed { i, (d, it) ->
                    if (i > 0) RowDivider()
                    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).pressable(scaleDown = false) { nav.agendaDay = d; nav.agendaSection = 0; nav.select(Tab.AGENDA) }
                        .padding(horizontal = 16.dp, vertical = 10.dp), verticalAlignment = Alignment.CenterVertically) {
                        DateBox(d, small = true); Spacer(Modifier.width(14.dp))
                        Column(Modifier.weight(1f)) {
                            Text(it.title, style = Type.bodyMedium, maxLines = 1, overflow = TextOverflow.Ellipsis)
                            Text(Cal.rel(d) + if (it.time.isNotEmpty()) " · ${it.time}" else "", style = Type.secondary)
                        }
                    }
                }
            }
        }
        val pinned = a.notes.filter { it.pinned }.take(2)
        if (pinned.isNotEmpty()) item {
            SectionHeader("Notas fijadas", "Ver todas") { nav.notesSection = 0; nav.select(Tab.NOTAS) }
            pinned.forEach { n -> NoteCard(n) { nav.push(Dest.NoteEditor(n.id), Tab.NOTAS) }; Spacer(Modifier.height(Dim.related)) }
        }
    }
}

@Composable
private fun HeroCard(hero: Hero, a: Academic, run: app.minibunker.study.StudyRun?, now: Long, mm: Int, studyFocus: FocusRequester, tt: AppState) {
    val nav = LocalNav.current
    val ctx = LocalContext.current
    val tint = when (hero) {
        is Hero.InClass -> hexColor(hero.c.color); is Hero.NextClass -> hexColor(hero.c.color)
        is Hero.StudyTask -> hexColor(Cal.subjColor(a, hero.p.subject)); Hero.Study -> hexColor(Cal.subjColor(a, run?.subject ?: ""), TT.Accent)
        else -> TT.Accent
    }
    val shape = RoundedCornerShape(Dim.cardRadius)
    Column(
        Modifier.fillMaxWidth().clip(shape)
            .background(Brush.linearGradient(listOf(tint.copy(alpha = if (TT.isDark) 0.42f else 0.30f), TT.Card)))
            .padding(Dim.cardPad),
    ) {
        when (hero) {
            Hero.Study -> {
                val r = run!!
                val op = remember(LocalResumeTick.current) { Perms.isGuardEnabled(ctx) }
                Text(if (r.phase == app.minibunker.study.Phase.FOCUS) "Estudiando ahora" else r.phase.label, style = Type.label.copy(color = TT.Text))
                Text(r.subjectLabel + (r.topic?.let { " · $it" } ?: ""), style = Type.section, maxLines = 2)
                val left = r.remainingMs(now); val s = (left + 999) / 1000
                Text("%d:%02d".format(s / 60, s % 60), style = Type.timer.copy(fontSize = Type.hero.fontSize), modifier = Modifier.semantics { contentDescription = "Quedan ${s / 60} minutos ${s % 60} segundos" })
                Text(StudyEngine.indicator(r, now, op), style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                PillButton("Volver a la sesión", { nav.push(Dest.StudySession, Tab.ESTUDIO) }, Modifier.fillMaxWidth(), icon = Icons.Rounded.PlayArrow)
            }
            Hero.Empty -> {
                Text("Tu agenda está vacía", style = Type.section)
                Text("Empieza por tu horario de clases o ponte a estudiar ya: el temporizador funciona sin nada más.", style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(Dim.related)) {
                    PillButton("Crear horario", { nav.agendaSection = 1; nav.select(Tab.AGENDA) }, Modifier.weight(1f), tone = ButtonTone.Secondary)
                    PillButton("Iniciar estudio", { nav.lastOpener = studyFocus; nav.startStudy() }, Modifier.weight(1f).focusRequester(studyFocus))
                }
            }
            is Hero.InClass -> {
                val len = Cal.toMin(hero.c.end) - Cal.toMin(hero.c.start); val left = Cal.toMin(hero.c.end) - mm
                Row { Text("Ahora en clase", style = Type.label.copy(color = TT.Text), modifier = Modifier.weight(1f)); Text("quedan ${Cal.fmtDur(left)}", style = Type.label.copy(color = TT.Text)) }
                Text(hero.c.subject, style = Type.section)
                Text("${hero.c.start} – ${hero.c.end}" + listOf(hero.c.teacher, hero.c.room).filter { it.isNotEmpty() }.joinToString("") { " · $it" }, style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(10.dp))
                LinearProgressIndicator(progress = { ((len - left).toFloat() / len).coerceIn(0f, 1f) }, modifier = Modifier.fillMaxWidth().height(6.dp),
                    color = TT.Text, trackColor = TT.Text.copy(alpha = 0.18f), drawStopIndicator = {})
                Spacer(Modifier.height(8.dp))
                Text(hero.next?.let { "Después: ${it.subject} · ${it.start}" } ?: "Es tu última clase de hoy", style = Type.label.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                StudyButton(studyFocus) { nav.startStudy(StudyRequest(hero.c.subject)) }
            }
            is Hero.NextClass -> {
                Row { Text("Siguiente clase", style = Type.label.copy(color = TT.Text), modifier = Modifier.weight(1f)); Text("a las ${hero.c.start}", style = Type.label.copy(color = TT.Text)) }
                Text(hero.c.subject, style = Type.section)
                Text("${hero.c.start} – ${hero.c.end}" + listOf(hero.c.teacher, hero.c.room).filter { it.isNotEmpty() }.joinToString("") { " · $it" }, style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                StudyButton(studyFocus) { nav.startStudy() }
            }
            is Hero.NextEvent -> {
                Row { Text("Próximo compromiso", style = Type.label.copy(color = TT.Text), modifier = Modifier.weight(1f)); Text("a las ${hero.item.time}", style = Type.label.copy(color = TT.Text)) }
                Text(hero.item.title, style = Type.section, maxLines = 2)
                val isStudyEvent = (hero.item as? Cal.DayItem.Ev)?.e?.cat == "estudio"
                Spacer(Modifier.height(14.dp))
                StudyButton(studyFocus) { nav.startStudy(if (isStudyEvent) StudyRequest(topic = hero.item.title) else StudyRequest()) }
            }
            is Hero.StudyTask -> {
                val late = hero.p.date < Cal.iso(LocalDate.now())
                Text(if (late) "Tarea de estudio atrasada" else "Tu tarea de estudio de hoy", style = Type.label.copy(color = TT.Text))
                Text(hero.p.title, style = Type.section, maxLines = 2)
                Text(hero.p.subject + " · plan de estudio", style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                StudyButton(studyFocus) { nav.startStudy(StudyRequest(hero.p.subject, hero.p.id, hero.p.title)) }
            }
            is Hero.FreeDay -> {
                Text(if (Cal.classesOn(a, LocalDate.now()).isNotEmpty()) "Clases terminadas" else "Hoy no hay clase", style = Type.label.copy(color = TT.Text))
                Text(if (hero.count > 0) "${hero.count} ${if (hero.count == 1) "cosa" else "cosas"} en tu día" else "Día libre", style = Type.section)
                Text(hero.tomorrow?.let { "Mañana empiezas a las ${it.start} con ${it.subject}" } ?: "Mañana tampoco tienes clase", style = Type.secondary.copy(color = TT.Text))
                Spacer(Modifier.height(14.dp))
                StudyButton(studyFocus) { nav.startStudy() }
            }
        }
    }
}

@Composable
private fun StudyButton(fr: FocusRequester, onClick: () -> Unit) {
    val nav = LocalNav.current
    PillButton("Empezar a estudiar", { nav.lastOpener = fr; onClick() }, Modifier.fillMaxWidth().focusRequester(fr), icon = Icons.Rounded.PlayArrow)
}

@Composable
private fun StatTile(label: String, value: String, modifier: Modifier, onClick: () -> Unit) {
    TTCard(modifier, onClick = onClick, padding = 14.dp) {
        Text(label, style = Type.label, maxLines = 1)
        Text(value, style = Type.cardTitle.copy(fontFeatureSettings = "tnum"), maxLines = 1, overflow = TextOverflow.Ellipsis)
    }
}

/** Caja con día y mes. */
@Composable
fun DateBox(date: String, small: Boolean = false) {
    val d = Cal.parse(date) ?: return
    Column(Modifier.size(if (small) 44.dp else 52.dp).clip(RoundedCornerShape(14.dp)).background(TT.Control),
        horizontalAlignment = Alignment.CenterHorizontally, verticalArrangement = Arrangement.Center) {
        Text("${d.dayOfMonth}", style = Type.cardTitle.copy(fontFeatureSettings = "tnum"))
        Text(Cal.shortMonth(d), style = Type.label)
    }
}

/** Fila de evento o examen del día: abre su hoja de edición (el examen es el mismo examen). */
@Composable
fun DayItemRow(it: Cal.DayItem, a: Academic) {
    val nav = LocalNav.current
    val color = when (it) { is Cal.DayItem.Ev -> it.e.color.takeIf { c -> c.isNotEmpty() }?.let { c -> hexColor(c) } ?: TT.Accent; is Cal.DayItem.Exam -> TT.Warm }
    Row(
        Modifier.fillMaxWidth().heightIn(min = 64.dp)
            .pressable(scaleDown = false) { when (it) { is Cal.DayItem.Ev -> nav.openEvent = it.e.id; is Cal.DayItem.Exam -> nav.openExam = it.g.id } }
            .padding(horizontal = 16.dp, vertical = 10.dp),
        verticalAlignment = Alignment.CenterVertically,
    ) {
        Text(it.time.ifEmpty { "Día" }, style = Type.label.copy(color = TT.Text, fontFeatureSettings = "tnum"), modifier = Modifier.width(46.dp))
        Box(Modifier.width(4.dp).height(34.dp).clip(CircleShape).background(color))
        Spacer(Modifier.width(12.dp))
        Column(Modifier.weight(1f)) {
            Text(it.title, style = Type.bodyMedium, maxLines = 2, overflow = TextOverflow.Ellipsis)
            Text(when (it) {
                is Cal.DayItem.Ev -> "Evento" + (if (it.e.end.isNotEmpty()) " · hasta ${it.e.end}" else "") + (if (it.e.repeat != "none") " · " + REPEATS.first { r -> r.first == it.e.repeat }.second.lowercase() else "")
                is Cal.DayItem.Exam -> "Examen" + (it.g.score?.let { s -> " · nota ${Cal.fmtN(s)}/${Cal.fmtN(it.g.max)}" } ?: "")
            }, style = Type.secondary)
        }
    }
}

/** Tarea de un plan: marcar como hecha y empezar a estudiarla. */
@Composable
fun PlanRow(p: PlanItem, a: Academic, showDate: Boolean = true, showSubject: Boolean = true) {
    val nav = LocalNav.current
    val today = Cal.iso(LocalDate.now())
    val late = !p.done && p.date < today
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(start = 4.dp, end = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        CheckCircle(p.done, hexColor(Cal.subjColor(a, p.subject)), "Hecho: ${p.title}") {
            AcademicRepo.edit { Edits.setPlanDone(it, p.id, !p.done) }
            if (!p.done) nav.show("¡Tema completado!")
        }
        Column(Modifier.weight(1f).padding(vertical = 10.dp)) {
            Text(p.title, style = Type.bodyMedium.copy(color = if (p.done) TT.TextSecondary else TT.Text,
                textDecoration = if (p.done) androidx.compose.ui.text.style.TextDecoration.LineThrough else null), maxLines = 2)
            Text(listOfNotNull(if (showSubject) p.subject else null, if (late) "Atrasado · ${Cal.shortDay(p.date)}" else if (showDate) Cal.shortDay(p.date) else null,
                if (p.review) "repaso" else null).joinToString(" · "), style = Type.secondary.copy(color = if (late) TT.Danger else TT.TextSecondary))
        }
        if (!p.done) Box(
            Modifier.size(Dim.touch).pressable { nav.startStudy(StudyRequest(p.subject, p.id, p.title)) }
                .semantics { contentDescription = "Empezar a estudiar ${p.title}"; role = Role.Button },
            contentAlignment = Alignment.Center,
        ) {
            Box(Modifier.size(36.dp).clip(CircleShape).background(TT.Accent), contentAlignment = Alignment.Center) {
                Icon(Icons.Rounded.PlayArrow, null, tint = TT.OnAccent, modifier = Modifier.size(20.dp))
            }
        }
    }
}

@Composable
fun CheckCircle(on: Boolean, color: Color, label: String, onToggle: () -> Unit) {
    Box(
        Modifier.size(Dim.touch).pressable(role = Role.Checkbox) { onToggle() }
            .semantics { contentDescription = label; stateDescription = if (on) "Hecho" else "Pendiente"; toggleableState = androidx.compose.ui.state.ToggleableState(on) },
        contentAlignment = Alignment.Center,
    ) {
        Box(
            Modifier.size(26.dp).clip(CircleShape).background(if (on) color else Color.Transparent)
                .then(if (!on) Modifier.background(TT.Control, CircleShape) else Modifier),
            contentAlignment = Alignment.Center,
        ) { if (on) Icon(Icons.Rounded.Check, null, tint = if (color.luminance() > 0.5f) Color.Black else Color.White, modifier = Modifier.size(16.dp)) }
    }
}

private fun Color.luminance() = 0.2126f * red + 0.7152f * green + 0.0722f * blue

@Composable
fun CheckRow(title: String, subtitle: String, on: Boolean, color: Color, kind: String, onToggle: () -> Unit) {
    Row(Modifier.fillMaxWidth().heightIn(min = 64.dp).padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
        CheckCircle(on, color, "$kind: $title", onToggle)
        Column(Modifier.weight(1f).padding(vertical = 10.dp, horizontal = 4.dp)) {
            Text(title, style = Type.bodyMedium.copy(color = if (on) TT.TextSecondary else TT.Text), maxLines = 2)
            Text(subtitle, style = Type.secondary)
        }
    }
}
