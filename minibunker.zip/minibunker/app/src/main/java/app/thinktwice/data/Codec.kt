package app.thinktwice.data

import app.thinktwice.core.*
import org.json.JSONArray
import org.json.JSONObject

/**
 * Serialización JSON del estado. Se usa para el almacenamiento local y para exportar/importar.
 * La lectura valida tipos y rangos; si algo no cuadra lanza [IllegalArgumentException]
 * y el estado actual no se toca.
 */
object Codec {
    const val FORMAT = "thinktwice-backup"
    /** 2 = minibunker (rutinas y sesiones vinculadas). Se aceptan copias 1 del thinktwice original. */
    const val VERSION = 2

    fun encode(s: AppState): String = JSONObject().apply {
        put("format", FORMAT); put("version", VERSION)
        put("settings", JSONObject().apply {
            val x = s.settings
            put("name", x.name); put("waitSeconds", x.waitSeconds); put("allowedMinutes", x.allowedMinutes)
            put("haptics", x.haptics); put("sessionNotifications", x.sessionNotifications)
            put("reduceMotion", x.reduceMotion?.let { if (it) "on" else "off" } ?: "system")
            put("reminderHour", x.reminderHour); put("onboardingDone", x.onboardingDone)
        })
        put("pausedApps", JSONArray(s.pausedApps.toList()))
        put("messages", JSONArray(s.messages.map { JSONObject().put("id", it.id).put("text", it.text).put("builtIn", it.builtIn) }))
        put("templates", JSONArray(s.templates.map {
            JSONObject().put("id", it.id).put("name", it.name).put("packages", JSONArray(it.packages.toList()))
                .put("durationMin", it.durationMin).put("icon", it.icon)
        }))
        put("sessions", JSONArray(s.sessions.map {
            JSONObject().put("id", it.id).put("name", it.name).put("packages", JSONArray(it.packages.toList()))
                .put("startMs", it.startMs).put("endMs", it.endMs).put("endedEarlyAtMs", it.endedEarlyAtMs ?: JSONObject.NULL)
                .put("link", it.link ?: JSONObject.NULL).put("suspendedAtMs", it.suspendedAtMs ?: JSONObject.NULL)
        }))
        put("routines", JSONArray(s.routines.map {
            JSONObject().put("id", it.id).put("name", it.name).put("packages", JSONArray(it.packages.toList()))
                .put("startMin", it.startMin).put("endMin", it.endMin).put("days", JSONArray(it.days.toList()))
                .put("enabled", it.enabled).put("icon", it.icon)
                .put("link", it.link ?: JSONObject.NULL).put("schedule", it.schedule.name)
                .put("anchorDay", it.anchorDay ?: JSONObject.NULL)
        }))
        put("routineSkips", JSONObject(s.routineSkips.mapValues { it.value }))
        put("challenges", JSONArray(s.challenges.map { c ->
            JSONObject().put("id", c.id).put("kind", c.kind.name).put("durationDays", c.durationDays)
                .put("startEpochDay", c.startEpochDay).put("routineId", c.routineId ?: JSONObject.NULL)
                .put("goalMinutes", c.goalMinutes ?: JSONObject.NULL)
                .put("manual", JSONObject(c.manual.mapKeys { it.key.toString() }))
                .put("reminder", c.reminder).put("archived", c.archived)
        }))
        put("classes", JSONObject(s.classes.mapValues { it.value.name }))
        put("events", JSONArray(s.events.map { e ->
            JSONObject().put("t", e.t).put("type", e.type.name).put("pkg", e.pkg ?: JSONObject.NULL).put("ref", e.ref ?: JSONObject.NULL)
        }))
        put("allowances", JSONObject(s.allowances.mapValues { it.value }))
    }.toString()

    fun decode(text: String): AppState {
        val o = try { JSONObject(text) } catch (e: Exception) { throw IllegalArgumentException("El archivo no es JSON válido.") }
        require(o.optString("format") == FORMAT) { "El archivo no es una copia de thinktwice ni de minibunker." }
        require(o.optInt("version", 0) in 1..VERSION) { "Versión de copia no compatible." }
        val st = o.getJSONObject("settings")
        val settings = Settings(
            name = st.optString("name", "").take(40),
            waitSeconds = st.optInt("waitSeconds", 15).also { require(it in 3..300) { "Espera fuera de rango." } },
            allowedMinutes = st.optInt("allowedMinutes", 5).also { require(it in 1..240) { "Intervalo fuera de rango." } },
            haptics = st.optBoolean("haptics", true),
            sessionNotifications = st.optBoolean("sessionNotifications", true),
            reduceMotion = when (st.optString("reduceMotion", "system")) { "on" -> true; "off" -> false; else -> null },
            reminderHour = st.optInt("reminderHour", 20).coerceIn(0, 23),
            onboardingDone = st.optBoolean("onboardingDone", true),
        )
        return AppState(
            settings = settings,
            pausedApps = o.optJSONArray("pausedApps").strings().toSet(),
            messages = o.optJSONArray("messages").objects().map {
                PauseMessage(it.getString("id"), it.getString("text").take(160), it.optBoolean("builtIn"))
            }.ifEmpty { Defaults.messages },
            templates = o.optJSONArray("templates").objects().map {
                BlockTemplate(it.getString("id"), it.getString("name"), it.optJSONArray("packages").strings().toSet(),
                    it.getInt("durationMin").also { d -> require(d in 1..24 * 60) { "Duración de plantilla no válida." } },
                    it.optString("icon", "focus"))
            },
            sessions = o.optJSONArray("sessions").objects().map {
                BlockSession(it.getString("id"), it.getString("name"), it.optJSONArray("packages").strings().toSet(),
                    it.getLong("startMs"), it.getLong("endMs"),
                    if (it.isNull("endedEarlyAtMs")) null else it.getLong("endedEarlyAtMs"),
                    link = it.optNullableString("link"),
                    suspendedAtMs = if (it.isNull("suspendedAtMs")) null else it.getLong("suspendedAtMs"))
                    .also { s -> require(s.endMs > s.startMs) { "Sesión con horas no válidas." } }
            },
            routines = o.optJSONArray("routines").objects().map {
                Routine(it.getString("id"), it.getString("name"), it.optJSONArray("packages").strings().toSet(),
                    it.getInt("startMin").also { v -> require(v in 0..1439) { "Hora de rutina no válida." } },
                    it.getInt("endMin").also { v -> require(v in 0..1439) { "Hora de rutina no válida." } },
                    it.optJSONArray("days").ints().filter { d -> d in 1..7 }.toSet(),
                    it.optBoolean("enabled"), it.optString("icon", "routine"),
                    link = it.optNullableString("link"),
                    schedule = runCatching { Schedule.valueOf(it.optString("schedule", "WEEKLY")) }.getOrDefault(Schedule.WEEKLY),
                    anchorDay = if (it.isNull("anchorDay")) null else it.getLong("anchorDay"))
                    .also { r -> require(r.schedule == Schedule.WEEKLY || r.anchorDay != null) { "Rutina sin fecha." } }
            },
            routineSkips = o.optJSONObject("routineSkips").longs(),
            challenges = o.optJSONArray("challenges").objects().map { c ->
                Challenge(c.getString("id"), ChallengeKind.valueOf(c.getString("kind")),
                    c.getInt("durationDays").also { require(it in setOf(1, 2, 7, 21, 30)) { "Duración de reto no válida." } },
                    c.getLong("startEpochDay"),
                    if (c.isNull("routineId")) null else c.optString("routineId"),
                    if (c.isNull("goalMinutes")) null else c.optInt("goalMinutes"),
                    c.optJSONObject("manual")?.let { m -> m.keys().asSequence().associate { k -> k.toLong() to m.getBoolean(k) } } ?: emptyMap(),
                    c.optBoolean("reminder"), c.optBoolean("archived"))
            },
            classes = o.optJSONObject("classes")?.let { m ->
                m.keys().asSequence().mapNotNull { k -> runCatching { k to AppClass.valueOf(m.getString(k)) }.getOrNull() }.toMap()
            } ?: emptyMap(),
            events = o.optJSONArray("events").objects().mapNotNull { e ->
                runCatching {
                    LogEvent(e.getLong("t"), EventType.valueOf(e.getString("type")),
                        if (e.isNull("pkg")) null else e.optString("pkg"), if (e.isNull("ref")) null else e.optString("ref"))
                }.getOrNull()
            },
            allowances = o.optJSONObject("allowances").longs(),
        )
    }

    /** isNull() también es true para claves ausentes (copias de la versión 1). */
    private fun JSONObject.optNullableString(k: String): String? = if (isNull(k)) null else optString(k)
    private fun JSONArray?.strings(): List<String> = if (this == null) emptyList() else (0 until length()).map { getString(it) }
    private fun JSONArray?.ints(): List<Int> = if (this == null) emptyList() else (0 until length()).map { getInt(it) }
    private fun JSONArray?.objects(): List<JSONObject> = if (this == null) emptyList() else (0 until length()).map { getJSONObject(it) }
    private fun JSONObject?.longs(): Map<String, Long> =
        if (this == null) emptyMap() else keys().asSequence().associateWith { getLong(it) }
}
