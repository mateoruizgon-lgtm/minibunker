package app.thinktwice.core

/**
 * Modelo de datos de thinktwice. Todo se guarda localmente (ver data/Store.kt).
 * Este paquete no depende de Android para poder probarse en la JVM.
 */

enum class AppClass { USEFUL, DISTRACTING, NEUTRAL }

data class Settings(
    val name: String = "",
    val waitSeconds: Int = 15,
    val allowedMinutes: Int = 5,
    val haptics: Boolean = true,
    val sessionNotifications: Boolean = true,
    /** null = seguir la preferencia del sistema; true/false = forzar. */
    val reduceMotion: Boolean? = null,
    val reminderHour: Int = 20,
    val onboardingDone: Boolean = false,
)

data class PauseMessage(val id: String, val text: String, val builtIn: Boolean)

data class BlockTemplate(
    val id: String,
    val name: String,
    val packages: Set<String>,
    val durationMin: Int,
    val icon: String = "focus",
)

data class BlockSession(
    val id: String,
    val name: String,
    val packages: Set<String>,
    val startMs: Long,
    val endMs: Long,
    /** Si se terminó antes de tiempo con la salida de emergencia. */
    val endedEarlyAtMs: Long? = null,
    /**
     * minibunker: origen de la sesión. "study:<idSesiónEstudio>" para la protección vinculada a un
     * bloque de estudio; null para un bloqueo normal de thinktwice.
     */
    val link: String? = null,
    /**
     * minibunker: instante en que la protección de un bloque de estudio quedó suspendida por pausa,
     * descanso o fin del estudio. No es una salida de emergencia ni cuenta como sesión completada.
     */
    val suspendedAtMs: Long? = null,
) {
    fun isActive(now: Long) = endedEarlyAtMs == null && suspendedAtMs == null && now in startMs until endMs
    fun effectiveEnd() = endedEarlyAtMs ?: suspendedAtMs ?: endMs
    fun completed(now: Long) = endedEarlyAtMs == null && suspendedAtMs == null && now >= endMs
    val isStudy get() = link?.startsWith("study:") == true
}

/** Calendario de una rutina. WEEKLY es el comportamiento original de thinktwice. */
enum class Schedule { WEEKLY, ONCE, MONTHLY, YEARLY }

data class Routine(
    val id: String,
    val name: String,
    val packages: Set<String>,
    /** Minutos desde medianoche, hora local. */
    val startMin: Int,
    val endMin: Int,
    /** Días ISO: 1 = lunes … 7 = domingo. Día en que EMPIEZA la franja. */
    val days: Set<Int>,
    val enabled: Boolean,
    val icon: String = "routine",
    /**
     * minibunker: elemento académico que generó esta regla ("class:<id>" o "event:<id>").
     * Una regla vinculada se actualiza al mover, editar o borrar su clase o evento, sin duplicarse.
     */
    val link: String? = null,
    val schedule: Schedule = Schedule.WEEKLY,
    /** Primer día (epochDay) en que puede aplicarse; obligatorio para ONCE, MONTHLY y YEARLY. */
    val anchorDay: Long? = null,
) {
    val isLinked get() = link != null
}

enum class ChallengeKind { ROUTINE, DAILY_SESSION, USAGE_GOAL }

data class Challenge(
    val id: String,
    val kind: ChallengeKind,
    /** 1 (24 h), 2 (48 h), 7, 21 o 30 días. */
    val durationDays: Int,
    /** Día de inicio (epochDay, zona local). */
    val startEpochDay: Long,
    val routineId: String? = null,
    val goalMinutes: Int? = null,
    /** Confirmaciones manuales por día (epochDay → cumplido). */
    val manual: Map<Long, Boolean> = emptyMap(),
    val reminder: Boolean = false,
    val archived: Boolean = false,
)

enum class EventType { PAUSE_SHOWN, CONTINUED, EXITED, BLOCK_SHOWN, SESSION_ENDED_EARLY, ROUTINE_SKIPPED }

data class LogEvent(val t: Long, val type: EventType, val pkg: String? = null, val ref: String? = null)

data class AppState(
    val settings: Settings = Settings(),
    /** Aplicaciones con pausa consciente. */
    val pausedApps: Set<String> = emptySet(),
    val messages: List<PauseMessage> = Defaults.messages,
    val templates: List<BlockTemplate> = Defaults.templates,
    val sessions: List<BlockSession> = emptyList(),
    val routines: List<Routine> = emptyList(),
    /** routineId → instante hasta el que la rutina queda suspendida (salida de emergencia). */
    val routineSkips: Map<String, Long> = emptyMap(),
    val challenges: List<Challenge> = emptyList(),
    val classes: Map<String, AppClass> = emptyMap(),
    val events: List<LogEvent> = emptyList(),
    /** package → instante hasta el que se permite el uso tras una pausa. */
    val allowances: Map<String, Long> = emptyMap(),
) {
    /** Todas las apps que el usuario ha decidido controlar de alguna forma. */
    fun controlledApps(): Set<String> =
        pausedApps + sessions.flatMap { it.packages } + routines.flatMap { it.packages } +
            templates.flatMap { it.packages }
}

object Defaults {
    val messages = listOf(
        PauseMessage("m1", "¿Quieres entrar o lo estás haciendo por costumbre?", true),
        PauseMessage("m2", "Piensa dos veces. Tu tiempo también cuenta.", true),
        PauseMessage("m3", "¿Qué venías a hacer aquí?", true),
        PauseMessage("m4", "Puedes decidir volver a lo que estabas haciendo.", true),
    )
    val templates = listOf(
        BlockTemplate("t_focus", "Concentración", emptySet(), 45, "focus"),
        BlockTemplate("t_study", "Estudiar", emptySet(), 60, "study"),
        BlockTemplate("t_work", "Trabajo", emptySet(), 120, "work"),
        BlockTemplate("t_sleep", "Dormir", emptySet(), 480, "sleep"),
    )
    /** Ejemplos de rutina: se ofrecen para copiar, nunca se activan solos. */
    val routineExamples = listOf(
        Routine("ex_morning", "Mañana", emptySet(), 7 * 60, 9 * 60, setOf(1, 2, 3, 4, 5), false, "morning"),
        Routine("ex_study", "Estudio", emptySet(), 17 * 60, 19 * 60, setOf(1, 2, 3, 4), false, "study"),
        Routine("ex_work", "Trabajo", emptySet(), 9 * 60, 14 * 60, setOf(1, 2, 3, 4, 5), false, "work"),
        Routine("ex_night", "Noche", emptySet(), 23 * 60, 7 * 60, setOf(1, 2, 3, 4, 5, 6, 7), false, "sleep"),
    )
    const val MAX_EVENTS = 6000
    const val EVENT_RETENTION_DAYS = 120L
}
