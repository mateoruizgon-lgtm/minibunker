package app.thinktwice.system

import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.graphics.Bitmap
import android.graphics.Canvas
import android.provider.Settings
import android.telecom.TelecomManager
import android.util.LruCache
import android.view.inputmethod.InputMethodManager
import androidx.core.graphics.drawable.toBitmap

data class InstalledApp(val pkg: String, val label: String)

/**
 * Lista de apps con icono de inicio. Usa la declaración <queries> del manifiesto, sin
 * QUERY_ALL_PACKAGES. Las apps esenciales nunca se pueden seleccionar.
 */
object Apps {
    @Volatile private var cache: List<InstalledApp>? = null
    private val labels = HashMap<String, String>()
    private val icons = LruCache<String, Bitmap>(120)
    @Volatile private var essentials: Set<String>? = null

    fun launchable(context: Context, refresh: Boolean = false): List<InstalledApp> {
        if (!refresh) cache?.let { return it }
        val pm = context.packageManager
        val intent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val ess = essentialPackages(context)
        val list = pm.queryIntentActivities(intent, 0)
            .map { it.activityInfo.packageName to it.loadLabel(pm).toString() }
            .distinctBy { it.first }
            .filter { it.first !in ess }
            .map { InstalledApp(it.first, it.second) }
            .sortedBy { it.label.lowercase() }
        synchronized(labels) { list.forEach { labels[it.pkg] = it.label } }
        cache = list
        return list
    }

    fun label(context: Context, pkg: String): String {
        synchronized(labels) { labels[pkg]?.let { return it } }
        return try {
            val pm = context.packageManager
            pm.getApplicationLabel(pm.getApplicationInfo(pkg, 0)).toString().also { synchronized(labels) { labels[pkg] = it } }
        } catch (e: PackageManager.NameNotFoundException) { pkg.substringAfterLast('.') }
    }

    fun icon(context: Context, pkg: String, sizePx: Int): Bitmap? {
        val key = "$pkg@$sizePx"
        icons.get(key)?.let { return it }
        return try {
            val d = context.packageManager.getApplicationIcon(pkg)
            d.toBitmap(sizePx, sizePx, Bitmap.Config.ARGB_8888).also { icons.put(key, it) }
        } catch (e: Exception) { null }
    }

    /**
     * Paquetes que thinktwice nunca intercepta: la propia app, la interfaz del sistema,
     * Ajustes (para poder revocar permisos), teléfono y llamadas de emergencia, el lanzador
     * y los teclados.
     */
    fun essentialPackages(context: Context): Set<String> {
        essentials?.let { return it }
        val pm = context.packageManager
        val set = mutableSetOf(
            context.packageName, "android", "com.android.systemui", "com.android.settings",
            "com.android.phone", "com.android.server.telecom", "com.android.emergency",
            "com.google.android.dialer", "com.android.dialer", "com.samsung.android.dialer",
            "com.android.permissioncontroller", "com.google.android.permissioncontroller",
            "com.android.packageinstaller", "com.google.android.packageinstaller",
        )
        runCatching { (context.getSystemService(TelecomManager::class.java))?.defaultDialerPackage?.let { set += it } }
        runCatching {
            pm.queryIntentActivities(Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME), 0)
                .forEach { set += it.activityInfo.packageName }
        }
        runCatching {
            context.getSystemService(InputMethodManager::class.java).enabledInputMethodList.forEach { set += it.packageName }
        }
        runCatching { pm.resolveActivity(Intent(Settings.ACTION_SETTINGS), 0)?.activityInfo?.packageName?.let { set += it } }
        essentials = set
        return set
    }

    fun resetEssentials() { essentials = null }
}
