package app.thinktwice.core

import java.time.LocalDate

/** Uso de un día: package → milisegundos en primer plano. null = sin datos para ese día. */
typealias DayUsage = Map<String, Long>

object Productivity {
    /**
     * Indicador de uso clasificado:
     *   útiles / (útiles + distractoras) × 100
     * Las apps neutras y las no clasificadas se excluyen del cálculo.
     * Devuelve null si el denominador es 0 ("Sin datos suficientes").
     */
    fun percent(usage: DayUsage, classes: Map<String, AppClass>): Int? {
        var useful = 0L
        var distracting = 0L
        usage.forEach { (pkg, ms) ->
            when (classes[pkg]) {
                AppClass.USEFUL -> useful += ms
                AppClass.DISTRACTING -> distracting += ms
                else -> Unit
            }
        }
        val den = useful + distracting
        if (den <= 0L) return null
        return Math.round(useful * 100.0 / den).toInt()
    }

    /** Resumen de varios días: se suman los tiempos y luego se calcula (no media de porcentajes). */
    fun percentAggregated(days: List<DayUsage>, classes: Map<String, AppClass>): Int? =
        percent(sum(days), classes)

    fun sum(days: List<DayUsage>): DayUsage {
        val out = HashMap<String, Long>()
        days.forEach { d -> d.forEach { (k, v) -> out[k] = (out[k] ?: 0L) + v } }
        return out
    }

    fun distractingMs(usage: DayUsage, classes: Map<String, AppClass>): Long =
        usage.filterKeys { classes[it] == AppClass.DISTRACTING }.values.sum()
}

enum class DayStatus { MET_MEASURED, MET_MANUAL, MISSED_MEASURED, MISSED_MANUAL, PENDING, NO_DATA }

/** Fuentes de datos que necesita la evaluación de retos (inyectadas para poder probarla). */
interface ChallengeInputs {
    /** Uso del día o null si no hay datos (sin permiso o fuera del historial del sistema). */
    fun usage(day: LocalDate): DayUsage?
    val state: AppState
    val zone: java.time.ZoneId
}

object Challenges {

    fun days(c: Challenge): List<LocalDate> =
        (0 until c.durationDays).map { LocalDate.ofEpochDay(c.startEpochDay + it) }

    fun ruleText(c: Challenge, routineName: String?): String = when (c.kind) {
        ChallengeKind.ROUTINE -> "Cumplir la rutina «${routineName ?: "eliminada"}» sin usar la salida de emergencia"
        ChallengeKind.DAILY_SESSION -> "Completar al menos una sesión de bloqueo cada día"
        ChallengeKind.USAGE_GOAL -> "Usar apps distractoras ${c.goalMinutes ?: 0} min o menos al día"
    }

    fun evaluate(c: Challenge, day: LocalDate, today: LocalDate, inputs: ChallengeInputs): DayStatus {
        if (day.isAfter(today)) return DayStatus.PENDING
        val measured = measure(c, day, today, inputs)
        if (measured != null) return if (measured) DayStatus.MET_MEASURED else DayStatus.MISSED_MEASURED
        c.manual[day.toEpochDay()]?.let { return if (it) DayStatus.MET_MANUAL else DayStatus.MISSED_MANUAL }
        return if (day == today) DayStatus.PENDING else DayStatus.NO_DATA
    }

    /** true/false si se puede medir; null si no hay datos suficientes. */
    private fun measure(c: Challenge, day: LocalDate, today: LocalDate, inp: ChallengeInputs): Boolean? {
        val zone = inp.zone
        val dayStart = day.atStartOfDay(zone).toInstant().toEpochMilli()
        val dayEnd = day.plusDays(1).atStartOfDay(zone).toInstant().toEpochMilli()
        return when (c.kind) {
            ChallengeKind.DAILY_SESSION -> {
                val done = inp.state.sessions.any { it.endedEarlyAtMs == null && it.suspendedAtMs == null && it.endMs in dayStart until dayEnd }
                when {
                    done -> true
                    day == today -> null // aún puede cumplirse
                    else -> false
                }
            }
            ChallengeKind.USAGE_GOAL -> {
                if (day == today) return null
                val u = inp.usage(day) ?: return null
                if (u.isEmpty()) return null
                Productivity.distractingMs(u, inp.state.classes) <= (c.goalMinutes ?: 0) * 60_000L
            }
            ChallengeKind.ROUTINE -> {
                val r = inp.state.routines.firstOrNull { it.id == c.routineId } ?: return null
                val w = RuleEngine.windowStartingOn(r, day, zone) ?: return null // no tocaba ese día
                val skipped = inp.state.events.any {
                    it.type == EventType.ROUTINE_SKIPPED && it.ref == r.id && it.t in w.first until w.second
                }
                when {
                    skipped -> false
                    w.second <= System.currentTimeMillis() -> true
                    else -> null
                }
            }
        }
    }
}

object Fmt {
    /** Separa un tiempo en partes cifra/unidad para mostrarlas con distinto tamaño. */
    fun durationParts(ms: Long): List<Pair<String, String>> {
        val totalMin = ms / 60_000
        val h = totalMin / 60
        val m = totalMin % 60
        return when {
            h > 0 && m > 0 -> listOf("$h" to "h", "$m" to "min")
            h > 0 -> listOf("$h" to "h")
            else -> listOf("$m" to "min")
        }
    }

    fun duration(ms: Long): String = durationParts(ms).joinToString(" ") { "${it.first} ${it.second}" }

    fun clock(min: Int): String = "%02d:%02d".format(min / 60, min % 60)

    fun countdown(ms: Long): String {
        val s = (ms.coerceAtLeast(0) + 999) / 1000
        val h = s / 3600
        val m = (s % 3600) / 60
        val sec = s % 60
        return if (h > 0) "%d:%02d:%02d".format(h, m, sec) else "%d:%02d".format(m, sec)
    }

    private val dayLetters = mapOf(1 to "L", 2 to "M", 3 to "X", 4 to "J", 5 to "V", 6 to "S", 7 to "D")
    fun days(days: Set<Int>): String = when {
        days.size == 7 -> "Todos los días"
        days == setOf(1, 2, 3, 4, 5) -> "Lunes a viernes"
        days == setOf(6, 7) -> "Fines de semana"
        days.isEmpty() -> "Sin días"
        else -> days.sorted().joinToString(" ") { dayLetters[it]!! }
    }
    fun dayLetter(d: Int) = dayLetters[d]!!
}
