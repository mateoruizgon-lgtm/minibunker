package app.thinktwice

import app.thinktwice.core.*
import app.thinktwice.data.Codec
import org.junit.Assert.*
import org.junit.Test

/** Copias: el formato de minibunker conserva lo nuevo y acepta copias del thinktwice original (versión 1). */
class CompatTest {
    @Test fun linkedRulesAndStudySessionsRoundTrip() {
        val s = AppState(
            routines = listOf(Routine("r", "Clase · Geo", setOf("a.b"), 600, 660, setOf(1), true, "study", link = "class:c1"),
                Routine("e", "Biblioteca", setOf("a.b"), 1020, 1140, emptySet(), true, link = "event:e1", schedule = Schedule.ONCE, anchorDay = 20410)),
            sessions = listOf(BlockSession("s", "Estudio · Geo", setOf("a.b"), 1000, 5000, link = "study:x", suspendedAtMs = 2000)),
        )
        assertEquals(s, Codec.decode(Codec.encode(s)))
    }

    @Test fun importsOriginalThinktwiceBackup() {
        // Copia tal como la exporta el thinktwice original (versión 1, sin campos nuevos).
        val v1 = """{"format":"thinktwice-backup","version":1,"settings":{"name":"Ana","waitSeconds":30,"allowedMinutes":10,"haptics":true,"sessionNotifications":true,"reduceMotion":"system","reminderHour":21,"onboardingDone":true},
            "pausedApps":["com.instagram.android"],"messages":[{"id":"m1","text":"¿Seguro?","builtIn":false}],"templates":[],
            "sessions":[{"id":"s1","name":"Foco","packages":["com.instagram.android"],"startMs":1,"endMs":2,"endedEarlyAtMs":null}],
            "routines":[{"id":"r1","name":"Noche","packages":["com.instagram.android"],"startMin":1380,"endMin":420,"days":[1,2,3],"enabled":true,"icon":"sleep"}],
            "routineSkips":{},"challenges":[],"classes":{"com.instagram.android":"DISTRACTING"},"events":[],"allowances":{}}"""
        val st = Codec.decode(v1)
        assertEquals(30, st.settings.waitSeconds)
        val r = st.routines.single()
        assertEquals(Schedule.WEEKLY, r.schedule); assertNull(r.link); assertNull(r.anchorDay)
        assertNull(st.sessions.single().link); assertNull(st.sessions.single().suspendedAtMs)
        assertEquals(AppClass.DISTRACTING, st.classes["com.instagram.android"])
    }
}
