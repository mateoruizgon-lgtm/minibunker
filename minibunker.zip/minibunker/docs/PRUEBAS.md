# Pruebas: qué está verificado y qué queda pendiente

## Resumen honesto
El proyecto se generó en un entorno **sin Android SDK y sin acceso a internet**. Por eso:

- ✅ **Se ha ejecutado**: toda la lógica pura (motor de reglas, protección vinculada, temporizador, sincronización sin conexión, cálculos académicos, copias de thinktwice) compilada con Kotlin 2.0.21 y probada en la JVM: **42 pruebas, 0 fallos**.
- ✅ **Se ha revisado con el compilador**: todo el código Kotlin pasó por el compilador real. **No hay errores de sintaxis.** Los errores restantes son referencias a Android y Compose, que no estaban disponibles. Se revisaron uno a uno los que no se explicaban por eso, y se corrigió un fallo real: el orden de parámetros de `Avatar`.
- ❌ **No se ha compilado con Gradle ni ejecutado en un móvil**. **Nada se ha comprobado todavía en un móvil real.** La primera compilación en Android Studio puede señalar algún ajuste menor de API de Compose. El error indica la línea exacta.

## Pruebas automáticas (`./gradlew testDebugUnitTest`)

| Prueba | Qué comprueba |
|---|---|
| `SyncTest.existingAccountIsReadAsIs` | Una cuenta con datos de la web se lee igual (formato `{items, updated}`). |
| `SyncTest.offlineEditProducesSingleChangeAfterSync` | Editar un examen dos veces sin conexión deja **un** cambio; al volver la red hay **una** escritura; reintentar no duplica nada. |
| `SyncTest.concurrentWriteFromOtherDeviceIsMergedNotLost` | Si otro dispositivo escribe entre la lectura y la escritura, se fusiona y no se pierde nada. |
| `SyncTest.deleteOnlyRemovesThatItem` / `guestDataIsAddedToAccount…` / `localEditDuringPushStaysPending` | Borrados por elemento, datos usados sin cuenta añadidos sin borrar y cambios hechos durante un envío. |
| `SyncTest.jsonRoundTripKeepsWebShape` / `legacyNoteToneMigratesLikeWeb` | Formato y migraciones iguales que la web. |
| `AcademicTest` | Medias ponderadas, «¿Qué nota necesito?», reparto del plan con día de repaso, repeticiones de eventos, examen en el calendario, generador de jornada y clases perdidas, asignar huecos sin cambiar ids, renombrar asignatura en cascada, borrar examen con su plan. |
| `AcademicTest.classLinkFollowsTheClass` | Una clase protegida bloquea en su franja, **se mueve con la clase** sin duplicarse y desaparece al borrarla. |
| `AcademicTest.oneOffEventProtectsOnlyThatDate` | Un evento aislado protege solo esa fecha; sin horas, la regla se desactiva sin perder las apps. |
| `StudyTest.indicatorText` | «Geografía · 24:59 · 2 apps protegidas» y sus variantes (sin protección, no operativa). |
| `StudyTest.pauseSuspendsOnlyLinkedProtection…` | Pausar suspende solo la protección del bloque; reanudar la aplica por el tiempo restante; reaplicar no duplica. |
| `StudyTest.breakRemovesProtectionAndTimeIsCountedOnce` | Bloque terminado con la pantalla bloqueada, descanso sin protección, **una** sesión de 25 min. |
| `StudyTest.studyOverlappingNightRoutineKeepsRoutineEnd` | Estudio solapado con rutina nocturna: al terminar el estudio la rutina sigue hasta las 07:00. |
| `StudyTest.emergencyExitLetsStudyContinue…` / `blockBeatsPauseAllowance` / `longBreakAfterFourBlocks` / `lessThanAMinuteIsNotSaved` | Salida de emergencia, prioridad del bloqueo sobre el intervalo concedido, descanso largo tras 4 bloques y mínimo de 1 min. |
| `RuleEngineTest` (de thinktwice) | Medianoche, solapes, salida de emergencia de rutina, pausa e intervalo, horario de verano, productividad, retos. |
| `CodecTest` + `CompatTest` | Exportar/importar con validación; reglas y sesiones vinculadas; **importa una copia del thinktwice original (v1)**. |

## Recorridos del encargo (pendientes en un móvil real)

Marca cada punto al comprobarlo. Entre paréntesis, la parte ya cubierta por pruebas automáticas.

### 1. Cuenta existente, horario, examen sin conexión y un único cambio
- [ ] Iniciar sesión con una cuenta de MIBUNKER ya poblada. Aparecen horario, exámenes, notas, hábitos y sesiones.
- [ ] Agenda › Horario muestra la cuadrícula semanal con los colores de la web.
- [ ] Modo avión → editar un examen (p. ej. la nota). Perfil muestra «Sin conexión · 1 cambio pendiente».
- [ ] Quitar el modo avión → «Sincronizado con tu cuenta». En la web aparece el cambio **una vez** y nada más ha cambiado. *(lógica: `offlineEditProducesSingleChangeAfterSync`)*

### 2. Examen de Geografía → plan → bloque protegido desde un tema
- [ ] Añadir › Examen «Geografía» con fecha. Estudio › Planes › Crear plan con varios temas y repaso.
- [ ] ▶ en un tema → la hoja llega con **Geografía y el tema ya seleccionados**.
- [ ] Activar «Proteger este bloque», elegir apps o una plantilla → **Empezar**. El indicador dice «Geografía · 24:59 · N apps protegidas».
- [ ] Abrir una app protegida → pantalla de bloqueo con motivo «Estudio · Geografía», tiempo restante y hora de fin.
- [ ] Bloquear la pantalla y esperar al fin del bloque → suena el aviso «¡Bien hecho! Toca descansar». Al volver, el temporizador está en descanso.
- [ ] Empezar el descanso → las apps quedan libres. **Terminar** → resumen con el tema, el tiempo y las decisiones registradas → «Marcar como completado».
- [ ] Estudio › Esta semana: **una** sesión de Geografía. *(lógica: `breakRemovesProtectionAndTimeIsCountedOnce`)*

### 3. Bloque de estudio solapado con rutina nocturna
- [ ] Rutinas › ejemplo «Noche» con una app, activada; empezar un bloque protegido con la misma app poco antes de su inicio.
- [ ] Terminar el estudio dentro de la franja nocturna → la app sigue bloqueada con motivo «Noche» hasta su hora de fin. *(lógica: `studyOverlappingNightRoutineKeepsRoutineEnd`)*

### 4. Permisos denegados o revocados
- [ ] Sin accesibilidad: la hoja de estudio con protección ofrece **«Estudiar sin protección»** y **«Revisar permiso»**. Estudiar funciona; el indicador dice «protección no operativa».
- [ ] Revocar el acceso a uso con la app abierta → thinktwice y Hoy muestran «Sin permiso de uso» y los días **sin medición** (nunca «0 min»). Los retos de uso muestran «sin datos».
- [ ] Revocar notificaciones → Perfil › Permisos lo indica; el estudio sigue funcionando.

### 5. Superficies translúcidas, teclado y movimiento
Para cada caso (abrir Perfil, crear un horario, añadir un evento e iniciar un periodo de estudio):
- [ ] El desenfoque deja percibir el color del contenido de detrás (Android 12+). En Android 8–11 se ve una superficie opaca del mismo tono.
- [ ] Los campos y textos de la hoja se ven nítidos.
- [ ] Al abrir, la hoja sube en unos 290 ms mientras aparece el oscurecido. Al cerrar, la transición se invierte. En Perfil, «Añadir» y «Empezar a estudiar», el foco vuelve al control que la abrió (las demás hojas no restauran el foco de forma explícita).
- [ ] Con el teclado abierto, el botón principal de la hoja sigue visible y la cápsula se oculta.
- [ ] Con «Quitar animaciones» de Android o Perfil › Reducir movimiento: sin animaciones de desplazamiento.
- [ ] La cápsula: una tarjeta azul o una asignatura de color se percibe a través de ella al desplazar; iconos y etiquetas nítidos; el último elemento de cada lista se puede leer y pulsar.
- [ ] Al desplazar, el contenido que sale por arriba se desvanece bajo la cabecera.

### Comprobaciones generales
- [ ] Compilación: `./gradlew assembleDebug` y `./gradlew testDebugUnitTest`.
- [ ] Pantalla pequeña (≈ 5", 360 × 640 dp): las cinco etiquetas de la cápsula se leen; la cuadrícula del horario cabe con 5–6 días.
- [ ] Texto del sistema al máximo, TalkBack (cápsula, hojas, calendario, temporizador), contraste y objetivos táctiles ≥ 48 dp.
- [ ] Modo claro, oscuro y automático; cambiar el acento en el móvil y verlo en la web (y al revés).
- [ ] Reinicio del móvil con un bloque protegido en curso: se recuperan la notificación, la protección y el tiempo restante.
- [ ] Rotación durante la pausa consciente: la cuenta atrás no se reinicia.
- [ ] Importar la copia de un thinktwice original: se conservan los datos académicos.
- [ ] Batería: una noche con rutinas y pausas activas.
