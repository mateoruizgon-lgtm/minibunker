# Datos, cuenta y sincronización

## Qué se guarda y dónde

| Datos | Dónde | Se sincroniza |
|---|---|---|
| Horario, jornada, asignaturas, eventos, exámenes, planes, sesiones de estudio, notas y hábitos | Cuenta de MIBUNKER (Firestore) + copia local `academic.json` | Sí, con la cuenta |
| Modo claro/oscuro/automático y color de acento | Documento `prefs` de la cuenta (igual que la web) | Sí |
| Duraciones del Pomodoro, periodo de estudio en curso | `study.json` en el móvil | No (como en la web, que las guardaba en el navegador) |
| Reglas, rutinas (también las vinculadas), sesiones de bloqueo, retos, frases, clasificación de apps, decisiones de pausa | `thinktwice-state.json` en el móvil | No: pertenecen al dispositivo |
| Tiempo de uso por app | Lo guarda Android; se consulta en el dispositivo | No |

`allowBackup="false"` y reglas de extracción vacías: nada sale del móvil por copias automáticas.

## Compatibilidad con la web de MIBUNKER
- Mismas rutas: `users/{uid}/data/{parte}`, cada una con un campo `json` (cadena) que contiene `{"items": [...], "updated": ms}`; `meta` = `{v:1, tt:1, created}` y `prefs` = `{accent, mode, updated}`.
- Mismos campos y saneado que las funciones `mig*` del `index.html`: notas con `tv: 2` (conversión de tonos antiguos), `day` del horario 0–6 con domingo = 0, examen con `score/max/weight` numéricos o `null`, hábitos con `days: {"AAAA-MM-DD": 1}`, etc.
- Un examen con fecha aparece en el calendario como **el mismo examen** (no se copia a eventos).
- Identificadores con la misma forma que `uid()` de la web.
- Borrar la cuenta elimina los mismos documentos que la web y después la cuenta.

## Cambios sin conexión
El núcleo (`SyncCore`, lógica pura con pruebas) mantiene:
- **base**: la última copia conocida de cada parte en la cuenta;
- **pendiente**: una cola de cambios por elemento (alta, edición o borrado por `id`).

La vista que ves es siempre base + pendiente, así que los cambios son inmediatos aunque no haya red. Al sincronizar, para cada parte con cambios:
1. se lee la versión actual del servidor (con su `updateTime`);
2. se aplican encima **solo** los cambios pendientes de esa parte, por `id`;
3. se escribe con la condición `currentDocument.updateTime` (o `exists=false` si aún no existía). Si otro dispositivo escribió en medio, se repite la lectura y la fusión.

Consecuencias:
- No se borra nada que no hayas borrado tú: lo que otro dispositivo añadió mientras estabas sin red se conserva.
- No se duplican acciones: aplicar el mismo cambio dos veces da lo mismo, y editar varias veces un elemento sin red deja un único cambio pendiente (el último).
- Si dos dispositivos editan **el mismo elemento** sin red, gana el último que sincroniza (nivel de elemento, como la web).
- Cerrar sesión con cambios pendientes avisa de cuántos se perderían.

La app sincroniza al abrirse, tras cada cambio (con medio segundo de espera), cada minuto mientras está a la vista y cuando vuelve la red.

## Copias de thinktwice
- **Exportar**: JSON con reglas, ajustes, retos y registros de thinktwice (formato `thinktwice-backup`, versión 2).
- **Importar**: acepta copias de minibunker y del **thinktwice original** (versión 1). Se valida antes de pedir confirmación. Sustituye los datos de thinktwice del móvil y conserva las protecciones vinculadas a clases y eventos. **No toca los datos académicos.**
- **Borrar datos de thinktwice**: solo en este móvil y con confirmación; no afecta a la agenda ni a los permisos de Android.
