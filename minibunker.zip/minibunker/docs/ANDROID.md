# Integración con Android (thinktwice dentro de minibunker)

El motor de thinktwice (`app.thinktwice.core`, `data`, `system`) se reutiliza tal cual con dos ampliaciones: rutinas **vinculadas** a una clase o a un evento (`Routine.link`, `schedule`, `anchorDay`) y sesiones de bloqueo **vinculadas a un bloque de estudio** (`BlockSession.link = "study:<id>"`, `suspendedAtMs`). En lo que sigue, «thinktwice» es ese motor; la app instalada se llama minibunker y el servicio de accesibilidad aparece como «minibunker».

## Mecanismo de intervención
Android no ofrece a una app normal una API para bloquear otras apps. thinktwice usa la única vía soportada sin ser administrador del dispositivo: un **servicio de accesibilidad** (`GuardService`) configurado de forma mínima:

- Solo recibe `TYPE_WINDOW_STATE_CHANGED` y solo lee `event.packageName`.
- `canRetrieveWindowContent="false"`: no puede leer texto, mensajes ni contenido de pantalla.
- `isAccessibilityTool="false"`: no se presenta como herramienta para personas con discapacidad.
- Antes de abrir el ajuste se muestra una explicación y se pide aceptación (divulgación destacada).

Cuando la app en primer plano cambia, `RuleEngine.decide()` devuelve `Allow`, `Pause` o `Block` y, si procede, se abre `InterventionActivity` encima (tarea propia, fuera de Recientes).

**Distribución:** Google Play exige declarar el uso de la API de accesibilidad, una divulgación destacada y consentimiento. Este proyecto incluye ambos textos, pero publicarlo en Play requiere completar el formulario de la consola y su revisión. Para uso personal (instalación directa) no hace falta.

### Restricción del sistema vs. intervención de thinktwice
Todas las pausas, sesiones y rutinas son **intervenciones de thinktwice**: dependen de que el servicio esté activo y se pueden terminar con la salida de emergencia o desactivando el servicio. La interfaz lo dice explícitamente y nunca presenta una sesión como protegida si el servicio no está operativo («Protección no operativa»).

Nunca se interceptan: minibunker, la interfaz del sistema, Ajustes, el controlador de permisos, el instalador, el teléfono/marcador por defecto (llamadas de emergencia), los teclados y el lanzador.

## Política de pausas
- Se evalúa solo cuando **cambia** la app en primer plano (no en cada ventana interna) → sin intervenciones duplicadas.
- «Continuar» (habilitado al terminar la espera, 15 s por defecto) concede un **intervalo permitido** (5 min por defecto) guardado como marca de tiempo.
- Salir y volver a entrar dentro del intervalo **no** repite la pausa.
- Al terminar el intervalo, si la app sigue en primer plano se vuelve a mostrar la pausa (una única comprobación programada para ese instante, no un sondeo continuo). Si no está en primer plano, se mostrará al abrirla.
- Salir sin continuar (botón, Atrás o Inicio) se registra como «no continuar» y la siguiente apertura empieza una pausa nueva.
- Si llegan eventos repetidos mientras la pausa está visible, se reutiliza la pantalla y su cuenta atrás (no se reinicia).
- Un bloqueo tiene prioridad sobre una pausa.

## Sesiones y rutinas
- Estado calculado siempre desde marcas de tiempo guardadas (`startMs`/`endMs`, franjas de rutina): sobrevive al cierre de la app y a reinicios.
- Rutinas en hora local de pared, evaluadas con la zona vigente; si `fin ≤ inicio` la franja cruza la medianoche y pertenece al día en que empieza. Se usan `ZonedDateTime` para respetar cambios de horario de verano.
- Solapes: `RuleEngine.freeAt()` encadena restricciones; si termina una sesión y sigue una rutina (o dos rutinas son contiguas), la app no se libera.
- Salida de emergencia: termina una sesión (`endedEarlyAtMs`) o suspende una rutina hasta el final de la franja actual (`routineSkips`). Queda registrada.
- `SystemEventsReceiver` recalcula notificaciones, recordatorios y la decisión actual tras reinicio, actualización, cambio de hora y cambio de zona.

## Estadísticas
`UsageStatsManager.queryEvents` (ACTIVITY_RESUMED/PAUSED/STOPPED) por día local. Se excluyen el lanzador, teclados y la propia app. Android conserva un historial de eventos limitado (depende de la versión y del fabricante); los días sin registros se muestran como «sin datos», nunca como 0.

Productividad = útiles ÷ (útiles + distractoras) × 100; neutras y no clasificadas excluidas; semanal/mensual con tiempos acumulados; denominador 0 → «Sin datos suficientes». Las comparaciones usan días completos equivalentes e indican las fechas.

## Limitaciones conocidas
- El ahorro de batería de algunos fabricantes puede detener servicios de accesibilidad; Diagnóstico muestra si está activado y si está en ejecución, y la hora del último evento recibido.
- La pantalla de intervención aparece tras el cambio de app: la app de destino puede verse durante una fracción de segundo.
- No se detecta el gesto de desplazamiento (scroll), solo la app en primer plano y el tiempo de uso.
- thinktwice no impide desinstalarse ni revocar permisos.
- Las notificaciones usan la cuenta atrás estándar de Android. No existe Dynamic Island en Android y no se simula.

## Estudio protegido (minibunker)
- «Proteger este bloque» crea una `BlockSession` con `link = "study:<id>"` que dura lo que queda del bloque de concentración. Se calcula como **estado deseado** (`StudyEngine.reconcileProtection`): se puede reaplicar tras cada cambio, al volver a la app o tras reiniciar sin crear sesiones duplicadas.
- Pausa, descanso o fin del estudio → la sesión vinculada se marca `suspendedAtMs` (no es salida de emergencia ni cuenta como sesión completada). Al reanudar se crea otra por el tiempo restante.
- La salida de emergencia (`endedEarlyAtMs`) sobre esa sesión deja seguir estudiando sin volver a proteger ese periodo.
- Rutinas y otros bloqueos no se tocan: si una rutina nocturna se solapa con el estudio, `freeAt()` mantiene la app pausada hasta el fin de la rutina.
- El temporizador guarda marcas de tiempo (`study.json`); una alarma (exacta si Android lo permite) cierra el bloque con la pantalla bloqueada y la notificación usa la cuenta atrás del sistema.
- El tiempo estudiado se registra una sola vez por periodo: la sesión académica usa el id del periodo y se actualiza (no se duplica). Una hora planificada o bloqueada nunca se suma por sí sola.

## Protección vinculada a la agenda
- «Vincular protección» en una clase crea una rutina semanal de ese día y franja; en un evento, una rutina de esa fecha (`ONCE`) o de sus repeticiones (diaria, semanal, mensual, anual).
- `Links.reconcile` se ejecuta cada vez que cambian los datos académicos (también si cambian desde otro dispositivo): mueve la regla con su elemento, la elimina si se borra y la desactiva (sin perder las apps) si deja de tener franja. Nunca hay dos reglas para el mismo elemento.
- Las apps y permisos son del dispositivo: estas reglas no se suben a la cuenta.
